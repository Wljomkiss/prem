<?php if ( ! defined( 'ABSPATH' ) ) { die; } // Cannot access pages directly.
// ===============================================================================================
// -----------------------------------------------------------------------------------------------
// FRAMEWORK SETTINGS
// -----------------------------------------------------------------------------------------------
// ===============================================================================================
$settings = array(
  'menu_title'    => 'Theme Options',
  'menu_type'     => 'menu',
  'menu_slug'     => 'nrg_premium-options',
  'ajax_save'     => true,
  'show_reset_all'  => true,
  'framework_title' => 'NRGPremium',
);

/*
* Get Theme Data Style
*/
$nrg_premium_style = wp_get_theme();

// ===============================================================================================
// -----------------------------------------------------------------------------------------------
// FRAMEWORK OPTIONS
// -----------------------------------------------------------------------------------------------
// ===============================================================================================
$options = array();

// ----------------------------------------
// General option section
// ----------------------------------------
$options[] = array(
  'name'        => 'general',
  'title'       => 'General',
  'icon'        => 'fa fa-cog',
  'fields'      => array(
    array(
		'type'    => 'subheading',
		'content' => 'Other settings',
    ),
    array(
    	'id'         => 'site_logo',
    	'type'       => 'upload',
    	'title'      => 'Site Logo',
    	'desc'       => 'Upload any media using the WordPress Native Uploader.',
    ),
    array(
      'id'         => 'site_logo_2',
      'type'       => 'upload',
      'title'      => 'Site Logo white',
      'desc'       => 'Upload any media using the WordPress Native Uploader.',
    ),
    array(
		'id'         => 'favicon',
		'type'       => 'upload',
		'title'      => 'Favicon',
		'desc'       => 'Upload any media using the WordPress Native Uploader.',
    ),
    array(
      'id'       => 'font_style',
      'type'     => 'select',
      'title'    => esc_html__( 'Font style', 'nrg_premium' ),
      'options'  => array(
        'font_style_1' => 'Font style 1',
        'font_style_2' => 'Font style 2',
        'font_style_3' => 'Font style 3',
        'font_style_4' => 'Font style 4',
        'font_style_5' => 'Font style 5',
        'font_style_6' => 'Font style 6',
        'font_style_7' => 'Font style 7',
        'font_style_8' => 'Font style 8',
      ),
      'default' => 'font_style_1'
    ),
    array(
      'id'       => 'border_style',
      'type'     => 'select',
      'title'    => esc_html__( 'Border style', 'nrg_premium' ),
      'options'  => array(
        'no_border'   => 'No border',
        'border_style'  => 'Border style',
        'border_style_grey' => 'Border style grey border',
        'frame_style' => 'Frame style',
      ),
      'default' => 'no_border'
    ),
    array(
      'id'       => 'port_link',
      'type'     => 'select',
      'title'    => esc_html__( 'Choose page for Portfolio detail link', 'nrg_premium' ),
      'options'  => nrg_premium_param_values( 'pages', array('post_type' => 'page', 'numberposts' => -1 ), 'DESC' ),
    ),
  )
);

// ----------------------------------------
// Header option section
// ----------------------------------------
$options[] = array(
  'name'        => 'header',
  'title'       => 'Header',
  'icon'        => 'fa fa-star',
  'fields'      => array(
        array(
          'id'     => 'header_layout',
          'type'     => 'image_select',
          'title'    => esc_html__( 'Header layout', 'nrg_premium' ),
          'subtitle' => esc_html__( 'Select header layout. Note that naked headers are applicable to Pages only.', 'nrg_premium' ),
          'options'  => array(
            '1' => plugins_url( 'img/header_type_1.jpg', __FILE__ ),
            '2' => plugins_url( 'img/header_type_2.jpg', __FILE__ ),
            '3' => plugins_url( 'img/header_type_3.jpg', __FILE__ ),
            '4' => plugins_url( 'img/header_type_4.jpg', __FILE__ ),
            '5' => plugins_url( 'img/header_type_5.jpg', __FILE__ ),
            '6' => plugins_url( 'img/header_type_6.jpg', __FILE__ ),
            '7' => plugins_url( 'img/header_type_7.jpg', __FILE__ ),
            '8' => plugins_url( 'img/header_type_8.jpg', __FILE__ ),
            '9' => plugins_url( 'img/header_type_9.jpg', __FILE__ ),
            '10' => plugins_url( 'img/header_type_10.jpg', __FILE__ ),
            '11' => plugins_url( 'img/header_type_11.jpg', __FILE__ ),
            '12' => plugins_url( 'img/header_type_12.jpg', __FILE__ ),
          ),
          'default' => '1'
        ),
        array(
          'id'      => 'work_time', 
          'type'    => 'text',
          'title'   => 'Work  time',
          'default' => '',
          'dependency' => array( 'header_layout_7', '==', 'true' ),
        ),
        array(
          'id'    => 'header_transparent',
          'type'    => 'select',
          'title'   => 'Header transparent',
          'options' => array(
            'no'  => 'No',
            'yes' => 'Yes',
            ),
          'default' => 'no',
          // 'dependency'   => array( 'header_layout', 'any', '1,2' ),
        ),
        array(
          'id'    => 'header_scroll_bg',
          'type'    => 'select',
          'title'   => 'Header scroll bg',
          'options' => array(
            'disable' => 'disable',
            'enable'  => 'enable',
            ),
          'default' => 'disable',
          // 'dependency' => array( 'header_layout', 'any', '5' )
        ),
        array(
          'id'      => 'menu_hov_color',
          'type'    => 'color_picker',
          'title'   => 'Menu active bg color',
          'default' => '#84694e',
          'rgba'    => true,
        ),
        array(
          'id'      => 'menu_color',
          'type'    => 'color_picker',
          'title'   => 'Menu active color',
          'default' => '#000',
          'rgba'    => true,
        ),
    array(
      'type'    => 'subheading',
      'content' => 'Menu typography style',
    ),
    array(
      'id'      => 'header_but_col',
      'type'    => 'color_picker',
      'title'   => 'Header button color',
      'default' => '#84694e',
    ),
    array(
      'id'      => 'default_header_typography',
      'type'    => 'switcher',
      'title'   => 'Default header typography',
      'default' => true
    ),
    array(
      'id'        => 'header_typography_group',
      'type'      => 'fieldset',
      'title'     => 'Menu typography',
      'fields'    => array(
        array(
          'id'      => 'header_typography',
          'type'    => 'typography',
          'title'   => 'Font',
          'default'   => array(
            'font'    => 'google',
          ),
        ),
        array(
          'id'      => 'header_font_size',
          'type'    => 'number',
          'title'   => 'Menu font size',
          'after'   => ' <i class="cs-text-muted">(px)</i>'
        ),
        array(
          'id'      => 'header_font_color',
          'type'    => 'color_picker',
          'title'   => 'Menu font color',
        ),
      ),
      'dependency' => array( 'default_header_typography', '==', false )
    ),

  ) // end: fields
);

// ----------------------------------------
// Footer option section                  -
// ----------------------------------------
$options[] = array(
  'name'        => 'footer',
  'title'       => 'Footer',
  'icon'        => 'fa fa-copyright',
  'fields'      => array(
        array(
          'id'       => 'footer_layout',
          'type'     => 'image_select',
          'title'    => esc_html__( 'Footer layout', 'nrg_premium' ),
          'subtitle' => esc_html__( 'Select footer layout. Note that naked footers are applicable to Pages only.', 'nrg_premium' ),
          'options'  => array(
            '1' => plugins_url( 'img/footer_type_1.jpg', __FILE__ ),
            '2' => plugins_url( 'img/footer_type_2.jpg', __FILE__ ),
            '3' => plugins_url( 'img/footer_type_3.jpg', __FILE__ ),
            '4' => plugins_url( 'img/footer_type_4.jpg', __FILE__ ),
            '5' => plugins_url( 'img/footer_type_5.jpg', __FILE__ ),
            '6' => plugins_url( 'img/footer_type_6.jpg', __FILE__ ),
            '7' => plugins_url( 'img/footer_type_7.jpg', __FILE__ ),
          ),
          'default' => '1'
        ),
        array(
          'id'    => 'link_title',
          'type'    => 'text',
          'title'   => 'Link title',
          'default' => '',
          'dependency'  => array( 'footer_layout_6', '==', 'true' )
        ),
        array(
          'id'    => 'link',
          'type'    => 'text',
          'title'   => 'Link',
          'default' => '',
          'dependency'  => array( 'footer_layout_6', '==', 'true' )
        ),
    array(
      'id'         => 'copyright_text',
      'type'       => 'text',
      'title'      => 'Copyright text',
      'default'    => '',
    ),
    array(
      'id'         => 'f_button_text',
      'type'       => 'text',
      'title'      => 'Button text',
      'default'    => '',
      // 'dependency' => array( 'f_button|footer_layout_1', '==|==', 'true|true' )
    ),
    array(
      'id'         => 'f_button_link',
      'type'       => 'text',
      'title'      => 'Button link',
      'default'    => '',
      // 'dependency' => array( 'f_button|footer_layout_1', '==|==', 'true|true' )
    ),
    array(
      'type'    => 'subheading',
      'content' => 'Menu typography style',
    ),
    array(
      'id'      => 'default_footer_typography',
      'type'    => 'switcher',
      'title'   => 'Default footer typography',
      'default' => true
    ),
    array(
      'id'        => 'footer_typography_group',
      'type'      => 'fieldset',
      'title'     => 'Footer typography',
      'fields'    => array(
        array(
          'id'      => 'footer_typography',
          'type'    => 'typography',
          'title'   => 'Font',
          'default' => array(
            'font' => 'google'
          ),
        ),
        array(
          'id'      => 'footer_font_size',
          'type'    => 'number',
          'title'   => 'Menu font size',
          'after'   => ' <i class="cs-text-muted">(px)</i>'
        ),
        array(
          'id'      => 'footer_font_color',
          'type'    => 'color_picker',
          'title'   => 'Menu font color'
        )
      ),
      'dependency' => array( 'default_footer_typography', '==', false )
    ),
  ) // end: fields
);

// ----------------------------------------
// Social                                 -
// ----------------------------------------
$options[] = array(
  'name'        => 'social',
  'title'       => 'Social',
  'icon'        => 'fa fa-thumbs-o-up',
  'fields'      => array(
    array(
      'type'    => 'subheading',
      'content' => 'Social settings',
    ),
    array(
      'id'          => 'fb_link',
      'type'        => 'text',
      'title'       => 'Facebook link',
      'default'     => 'https://www.facebook.com/',
    ),
    array(
      'id'          => 'tw_link',
      'type'        => 'text',
      'title'       => 'Twitter link',
      'default'     => 'https://twitter.com/',
    ),
    array(
      'id'          => 'in_link',
      'type'        => 'text',
      'title'       => 'Linkedin link',
      'default'     => 'https://www.linkedin.com/',
    ),
    array(
      'id'          => 'g_link',
      'type'        => 'text',
      'title'       => 'Google+ link',
      'default'     => 'https://plus.google.com/',
    ),
  )
);
// ----------------------------------------
// Contact info                                 -
// ----------------------------------------
$options[] = array(
  'name'        => 'contact',
  'title'       => 'Contact info',
  'icon'        => 'fa fa-info',
  'fields'      => array(
    array(
      'type'    => 'subheading',
      'content' => 'Contact info',
    ),
    array(
      'id'          => 'address_info',
      'type'        => 'text',
      'title'       => 'Address',
      'desc'        => 'Enter you address.',
    ), 
    array(
      'id'          => 'email_info',
      'type'        => 'text',
      'title'       => 'Email',
      'desc'        => 'Enter you email.',
    ),
    array(
      'id'          => 'phone_info',
      'type'        => 'text',
      'title'       => 'Contact number',
      'desc'        => 'Enter your contact phone number. Use only number sumbols.',
    ),
  )
);
// ----------------------------------------
// Blog                                   -
// ----------------------------------------
$options[] = array(
  'name'        => 'blog',
  'title'       => 'Blog',
  'icon'        => 'fa fa-book',
  'fields'      => array(
    array(
      'id'      => 'blog_color',
      'type'    => 'color_picker',
      'title'   => 'Blog color button',
      'default' => '#84694e',
    ),
  ),
);
// ----------------------------------------
// Custom CSS and JS
// ----------------------------------------
$options[] = array(
  'name'        => 'custom_css',
  'title'       => 'Custom CSS and JS',
  'icon'        => 'fa fa-paint-brush',
  'fields'      => array(
    array(
        'id'         => 'custom_css_styles',
        'desc'       => 'Only CSS, without tag &lt;style&gt;.',
        'type'       => 'textarea',
        'title'      => 'Custom CSS code'
    ),
    array(
        'id'         => 'custom_js_code',
        'desc'       => 'Only JS code, without tag &lt;script&gt;.',
        'type'       => 'textarea',
        'title'      => 'Custom JS code'
    )
  )
);

// ----------------------------------------
// 404 Page                               -
// ----------------------------------------
$options[] = array(
  'name'        => 'error_page',
  'title'       => '404 Page',
  'icon'        => 'fa fa-bolt',
  'fields'      => array(
    array(
      'id'      => 'error_title',
      'type'    => 'text',
      'title'   => 'Error Title',
      'default' => 'Page not found',
    ),
    array(
      'id'      => 'error_btn_text',
      'type'    => 'text',
      'title'   => 'Error button text',
      'default' => 'Go home',
    )
  ) // end: fields
);
//Google Maps
$options[] = array(
    'icon' => 'dashicons dashicons-location',
    'title' => esc_html__( 'Google Maps', 'nrg_premium' ),
    'name' => 'google-maps-settings',
    'fields' => array(
        array(
            'id' => 'google_maps_key',
            'type' => 'text',
            'title' => esc_html__('Google Maps API Key', 'nrg_premium'),
            'default' => 'AIzaSyBvEniZ89czPBUmYpsmhJQ3f8iso8l9kDQ'
        )
    )
);
// ----------------------------------------
// Backup
// ----------------------------------------
$options[] = array(
  'name'     => 'backup_section',
  'title'    => 'Backup',
  'icon'     => 'fa fa-shield',
  'fields'   => array(
    array(
      'type'    => 'notice',
      'class'   => 'warning',
      'content' => 'You can save your current options. Download a Backup and Import.',
    ),
    array(
      'type'    => 'backup',
    ),
  ) // end: fields
);


CSFramework::instance( $settings, $options );
