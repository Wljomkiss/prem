<?php
if ( ! defined( 'ABSPATH' ) ) { die; } // Cannot access pages directly.
/**
 *
 * CSFramework Taxonomy Config
 *
 * @since 1.0
 * @version 1.0
 *
 */
$options      = array();

$options[]    = array(
  'id'        => '_custom_category_options',
  'taxonomy' => 'category',
  'fields'    => array(
    array(
      'id'      => 'post_cat_color',
      'type'    => 'color_picker',
      'title'   => 'Background color category',
    ),
  ),
);

CSFramework_Taxonomy::instance( $options );