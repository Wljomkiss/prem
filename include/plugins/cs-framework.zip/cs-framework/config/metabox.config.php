<?php if ( ! defined( 'ABSPATH' ) ) { die; } // Cannot access pages directly.
// ===============================================================================================
// -----------------------------------------------------------------------------------------------
// METABOX OPTIONS
// -----------------------------------------------------------------------------------------------
// ===============================================================================================
$options      = array();

// -----------------------------------------
// Page Metabox Options                    -
// -----------------------------------------
$options[] = array(
	'id'        => '_custom_page_options',
	'title'     => 'Custom Page Options',
	'post_type' => 'page',
	'context'   => 'normal',
	'priority'  => 'default',
	'sections'  => array(
		array(
			'name'   => 'header_type',
			'title'  => 'Header type',
			'fields' => array(
				array(
					'id' 	   => 'header_layout',
					'type'     => 'image_select',
					'title'    => esc_html__( 'Header layout', 'nrg_premium' ),
					'subtitle' => esc_html__( 'Select header layout. Note that naked headers are applicable to Pages only.', 'nrg_premium' ),
					'options'  => array(
						'default' => plugins_url( 'img/default.jpg', __FILE__ ),
						'1' => plugins_url( 'img/header_type_1.jpg', __FILE__ ),
						'2' => plugins_url( 'img/header_type_2.jpg', __FILE__ ),
						'3' => plugins_url( 'img/header_type_3.jpg', __FILE__ ),
						'4' => plugins_url( 'img/header_type_4.jpg', __FILE__ ),
						'5' => plugins_url( 'img/header_type_5.jpg', __FILE__ ),
						'6' => plugins_url( 'img/header_type_6.jpg', __FILE__ ),
						'7' => plugins_url( 'img/header_type_7.jpg', __FILE__ ),
						'8' => plugins_url( 'img/header_type_8.jpg', __FILE__ ),
						'9' => plugins_url( 'img/header_type_9.jpg', __FILE__ ),
						'10' => plugins_url( 'img/header_type_10.jpg', __FILE__ ),
						'11' => plugins_url( 'img/header_type_11.jpg', __FILE__ ),
						'12' => plugins_url( 'img/header_type_12.jpg', __FILE__ ),
					),
					'default' => '1'
				),
				array(
					'id'      => 'work_time', 
					'type'    => 'text',
					'title'   => 'Work  time',
					'default' => '',
					'dependency' => array( 'header_layout_7', '==', 'true' ),
				),
				array(
					'id'		=> 'header_transparent',
					'type'		=> 'select',
					'title'		=> 'Header transparent',
					'options'	=> array(
						'no'	=> 'No',
						'yes'	=> 'Yes',
						),
					'default'	=> 'no',
				),
				array(
					'id'         => 'cats',
					'type'       => 'select',
					'title'      => __( 'Custom Categories', 'nrg_premium' ),
					'options'    => nrg_premium_param_values( 'terms', array(
						'taxonomies' => 'portfolio_categories',
					), 'DESC' ),
					'attributes' => array(
						'multiple' => 'multiple',
						'style'    => 'width: 125px; height: 125px;',
					)
				),
				array(
					'id'		=> 'header_scroll_bg',
					'type'		=> 'select',
					'title'		=> 'Header scroll bg',
					'options'	=> array(
						'disable'	=> 'disable',
						'enable'	=> 'enable',
						),
					'default'	=> 'disable',
					'dependency'	=> array( 'header_layout_5', '==', 'true' )
				),
				array(
					'id'      => 'menu_hov_color',
					'type'    => 'color_picker',
					'title'   => 'Menu active bg color',
					'default' => '#84694e',
					'rgba'    => true,
				),
				array(
					'id'      => 'menu_color',
					'type'    => 'color_picker',
					'title'   => 'Menu active color',
					'default' => '#000',
					'rgba'    => true,
				),
			),
		),
		array(
			'name'	 => 'footer_type',
			'title'  => 'Footer type',
			'fields' => array(
				array(
					'id'       => 'footer_layout',
					'type'     => 'image_select',
					'title'    => esc_html__( 'Footer layout', 'nrg_premium' ),
					'subtitle' => esc_html__( 'Select footer layout. Note that naked footers are applicable to Pages only.', 'nrg_premium' ),
					'options'  => array(
						'default' => plugins_url( 'img/default.jpg', __FILE__ ),
						'1' => plugins_url( 'img/footer_type_1.jpg', __FILE__ ),
						'2' => plugins_url( 'img/footer_type_2.jpg', __FILE__ ),
						'3' => plugins_url( 'img/footer_type_3.jpg', __FILE__ ),
						'4' => plugins_url( 'img/footer_type_4.jpg', __FILE__ ),
						'5' => plugins_url( 'img/footer_type_5.jpg', __FILE__ ),
						'6' => plugins_url( 'img/footer_type_6.jpg', __FILE__ ),
						'7' => plugins_url( 'img/footer_type_7.jpg', __FILE__ ),
					),
					'default' => '1'
				),
				array(
					'id'		=> 'f_insta',
					'type'		=> 'select',
					'title'		=> 'Instagram enable',
					'options'	=> array(
						'disable'	=> 'disable',
						'enable'	=> 'enable',
						),
					'default'	=> 'disable',
					'dependency'	=> array( 'footer_layout_2', '==', 'true' )
				),
				array(
					'id'		=> 'link_title_page',
					'type'		=> 'text',
					'title'		=> 'Link title',
					'default'	=> '',
					'dependency'	=> array( 'footer_layout_6', '==', 'true' )
				),
				array(
					'id'		=> 'link_page',
					'type'		=> 'text',
					'title'		=> 'Link',
					'default'	=> '',
					'dependency'	=> array( 'footer_layout_6', '==', 'true' )
				),
				array(
					'id'		=> 'instagram_userid',
					'type'		=> 'text',
					'title'		=> 'Instagram user ID:',
					'default'	=> '',
					'dependency'	=> array( 'f_insta', '==', 'enable' )
				),
				array(
					'id'		=> 'instagram_access_token',
					'type'		=> 'text',
					'title'		=> 'Instagram access token:',
					'default'	=> '',
					'dependency'	=> array( 'f_insta', '==', 'enable' )
				),
				array(
					'id'		=> 'img_limit',
					'type'		=> 'text',
					'title'		=> 'Instagram image limit:',
					'default'	=> '',
					'dependency'	=> array( 'f_insta', '==', 'enable' )
				),
			),
		),
		array(
			'name'	 => 'font_style_page',
			'title'  => 'Font style',
			'fields' => array(
				array(
					'id'       => 'font_class_page',
					'type'     => 'select',
					'title'    => esc_html__( 'Font style', 'nrg_premium' ),
					'options'  => array(
						'default' => 'Default',
						'font_style_1' => 'Font style 1',
						'font_style_2' => 'Font style 2',
						'font_style_3' => 'Font style 3',
						'font_style_4' => 'Font style 4',
						'font_style_5' => 'Font style 5',
						'font_style_6' => 'Font style 6',
						'font_style_7' => 'Font style 7',
						'font_style_8' => 'Font style 8',
					),
					'default' => 'default'
				),
			),
		),
		array(
			'name'	 => 'border_style_page',
			'title'  => 'Border style',
			'fields' => array(
				array(
					'id'       => 'border_class_page',
					'type'     => 'select',
					'title'    => esc_html__( 'Border style', 'nrg_premium' ),
					'options'  => array(
						'default'		=> 'Default',
						'no_border'		=> 'No border',
						'border_style'	=> 'Border style',
						'border_style_grey'	=> 'Border style grey border',
						'frame_style'	=> 'Frame style',
					),
					'default' => 'default'
				),
			),
		),
	),
);

$options[]    = array(
	'id'        => '_custom_projects_options',
	'title'     => 'Custom Projects Options',
	'post_type' => 'projects',
	'context'   => 'normal',
	'priority'  => 'default',
	'sections'  => array(
		array(
			'name'  => 'Subtitle',
			'fields' => array(
				array(
				'id'    => 'subtitle_project',
				'type'  => 'text',
				'title' => 'Project Subtitle',
				),
			),
		),
	),
);

CSFramework_Metabox::instance( $options );