<?php 
/*
**
** Functions for NRGPremium Plugins
**
*/


// php custom css for onepage
add_action('wp_ajax_dynamic_css', 'nrg_premium_plugins_dynamic_css');
add_action('wp_ajax_nopriv_dynamic_css', 'nrg_premium_plugins_dynamic_css');
function nrg_premium_plugins_dynamic_css() {
  require_once T_PATH . '/assets/css/custom.css.php';
  exit;
}

function hm_get_template_part( $file, $template_args = array(), $cache_args = array() ) {
    $template_args = wp_parse_args( $template_args );
    $cache_args = wp_parse_args( $cache_args );
    if ( $cache_args ) {
        foreach ( $template_args as $key => $value ) {
            if ( is_scalar( $value ) || is_array( $value ) ) {
                $cache_args[$key] = $value;
            } else if ( is_object( $value ) && method_exists( $value, 'get_id' ) ) {
                $cache_args[$key] = call_user_method( 'get_id', $value );
            }
        }
        if ( ( $cache = wp_cache_get( $file, serialize( $cache_args ) ) ) !== false ) {
            if ( ! empty( $template_args['return'] ) )
                return $cache;
            echo $cache;
            return;
        }
    }
    $file_handle = $file;
    do_action( 'start_operation', 'hm_template_part::' . $file_handle );
    if ( file_exists( EF_ROOT. '/' . $file . '.php' ) ){
        $file = EF_ROOT. '/' . $file . '.php';
        ob_start();
        $return = require( $file );
        $data = ob_get_clean();
        do_action( 'end_operation', 'hm_template_part::' . $file_handle );
        if ( $cache_args ) {
            wp_cache_set( $file, $data, serialize( $cache_args ), 3600 );
        }
        if ( ! empty( $template_args['return'] ) )
            if ( $return === false )
                return false;
            else
                return $data;
        echo $data;
    } else {
        return false;
    }
}