<?php
//REGISTER PROJECTS
function nrg_premium_post_type(){
  register_post_type( 'projects', array(
    'labels' => array(
      'name'               => __('Projects', 'nrg_premium'),
      'singular_name'      => __('Projects', 'nrg_premium'),
      'menu_name'          => __('Projects', 'nrg_premium'),
      'name_admin_bar'     => __('Project', 'nrg_premium'),
      'all_items'          => __('All Projects', 'nrg_premium'),
      'add_new'            => _x('Add New', 'Projects', 'nrg_premium'),
      'add_new_item'       => __('Add New Project', 'nrg_premium'),
      'edit_item'          => __('Edit Project', 'nrg_premium'),
      'new_item'           => __('New Project', 'nrg_premium'),
      'view_item'          => __('View Project', 'nrg_premium'),
      'search_items'       => __('Search Projects', 'nrg_premium'),
      'not_found'          => __('No Projects found.', 'nrg_premium'),
      'not_found_in_trash' => __('No Projects found in Trash.', 'nrg_premium'),
      'parent_item_colon'  => __('Parent Projects:', 'nrg_premium'),
    ),
    'public'        => true,
    'menu_position' => 5,
    'supports'      => array( 'title', 'editor', 'thumbnail', 'excerpt', 'custom-fields' ),
    'taxonomies'    => array( 'projects_categories'),
    'has_archive'   => true,
    'rewrite'       => array( 'slug' => 'projects' ),
    )
  );
//REGISTER PROJECTS TAXONOMY  
  register_taxonomy( 'projects_categories', array( 'projects' ),
    array(
      'labels'            => array(
        'name'              => _x('Categories', 'Projects', 'nrg_premium'),
        'singular_name'     => _x('Category', 'Projects', 'nrg_premium'),
        'menu_name'         => __('Categories', 'nrg_premium'),
        'all_items'         => __('All Categories', 'nrg_premium'),
        'edit_item'         => __('Edit Category', 'nrg_premium'),
        'view_item'         => __('View Category', 'nrg_premium'),
        'update_item'       => __('Update Category', 'nrg_premium'),
        'add_new_item'      => __('Add New Category', 'nrg_premium'),
        'new_item_name'     => __('New Category Name', 'nrg_premium'),
        'parent_item'       => __('Parent Category', 'nrg_premium'),
        'parent_item_colon' => __('Parent Category:', 'nrg_premium'),
        'search_items'      => __('Search Categories', 'nrg_premium'),
      ),
      'show_admin_column' => true,
      'hierarchical'      => true,
      'rewrite'           => array( 'slug' => 'projects/category' ),
    )
  );
//REGISTER PORTFOLIO
  register_post_type( 'portfolio', array(
    'labels' => array(
      'name'               => __('Portfolio', 'nrg_premium'),
      'singular_name'      => __('Portfolio', 'nrg_premium'),
      'menu_name'          => __('Portfolio', 'nrg_premium'),
      'name_admin_bar'     => __('Portfolio', 'nrg_premium'),
      'all_items'          => __('All Portfolio', 'nrg_premium'),
      'add_new'            => _x('Add New', 'Portfolio', 'nrg_premium'),
      'add_new_item'       => __('Add New Portfolio', 'nrg_premium'),
      'edit_item'          => __('Edit Portfolio', 'nrg_premium'),
      'new_item'           => __('New Portfolio', 'nrg_premium'),
      'view_item'          => __('View Portfolio', 'nrg_premium'),
      'search_items'       => __('Search Portfolio', 'nrg_premium'),
      'not_found'          => __('No Portfolio found.', 'nrg_premium'),
      'not_found_in_trash' => __('No Portfolio found in Trash.', 'nrg_premium'),
      'parent_item_colon'  => __('Parent Portfolio:', 'nrg_premium'),
    ),
    'public'        => true,
    'menu_position' => 5,
    'supports'      => array( 'title', 'editor', 'thumbnail', 'excerpt', 'custom-fields' ),
    'taxonomies'    => array( 'portfolio_categories' ),
    'has_archive'   => true,
    'rewrite'       => array( 'slug' => 'folio' ),
    )
  );
//REGISTER PORTFOLIO TAXONOMY   
  register_taxonomy( 'portfolio_categories', array( 'portfolio' ),
    array(
      'labels' => array(
        'name'              => _x('Categories', 'Portfolio', 'nrg_premium'),
        'singular_name'     => _x('Category', 'Portfolio', 'nrg_premium'),
        'menu_name'         => __('Categories', 'nrg_premium'),
        'all_items'         => __('All Categories', 'nrg_premium'),
        'edit_item'         => __('Edit Category', 'nrg_premium'),
        'view_item'         => __('View Category', 'nrg_premium'),
        'update_item'       => __('Update Category', 'nrg_premium'),
        'add_new_item'      => __('Add New Category', 'nrg_premium'),
        'new_item_name'     => __('New Category Name', 'nrg_premium'),
        'parent_item'       => __('Parent Category', 'nrg_premium'),
        'parent_item_colon' => __('Parent Category:', 'nrg_premium'),
        'search_items'      => __('Search Categories', 'nrg_premium'),
      ),
      'show_admin_column' => true,
      'hierarchical'      => true,
      'rewrite'           => array( 'slug' => 'portfolio/category' ),
    )
  );
}
add_action('init', 'nrg_premium_post_type', 0);