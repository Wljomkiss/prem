<?php
/*
Plugin Name: NRG Premium Plugins
Version: 1.0.0
Description: Visual Composer Shortcodes
*/


// add in constant name path
defined( 'EF_ROOT')		or  define( 'EF_ROOT', dirname(__FILE__));

defined( 'T_URI' )      or  define( 'T_URI',  get_template_directory_uri() );
defined( 'T_IMG' )		or 	define(	'T_IMG',	T_URI . '/assets/images' );

defined( 'T_PATH' )     or  define( 'T_PATH', get_template_directory() );
defined( 'FUNC_PATH' )  or  define( 'FUNC_PATH', T_PATH . '/inc' );

if(!class_exists('NRGPremium_Plugins')) {

	class NRGPremium_Plugins {
		
		public function __construct() { 

			if ( !function_exists( 'is_plugin_active' ) ) {
			  include_once( ABSPATH . 'wp-admin/includes/plugin.php' ); // Require plugin.php to use is_plugin_active() below
			}

			// include aq resizer
			require_once( EF_ROOT .'/includes/aq_resizer.php');

			if ( is_plugin_active( 'js_composer/js_composer.php' ) ) {

				require_once( WP_PLUGIN_DIR . '/js_composer/js_composer.php');
				// init settings and custom shortcode for visual composer
				//require_once( EF_ROOT .'/composer/init.php');

				add_action('admin_init', array($this, 'upqode_init') );
				add_action('wp', array($this, 'upqode_init') );

				add_action( 'admin_print_scripts-post.php', array($this, 'vc_enqueue_scripts'), 99);
				add_action( 'admin_print_scripts-post-new.php', array($this, 'vc_enqueue_scripts'), 99);

			}

		}

		//include custom shortcodes
		public function upqode_init() {

			// init vc
			require_once( EF_ROOT .'/composer/init.php');

		}

		//include scripts
		public function vc_enqueue_scripts() {
		  $assets_js = plugins_url('/composer/js', __FILE__);
		  wp_enqueue_script( 'vc-script', $assets_js .'/vc-script.js' ,  array(), '1.0.0', true );
		}


	} // end of class

	// include functions
	require_once( EF_ROOT .'/includes/functions_plugins.php');

	// kill default gallery
	if (!function_exists('nrg_premium_kill_default_gallery')) {

		function nrg_premium_kill_default_gallery() {
			$portfolio_options_gallery = get_post_meta( get_the_ID(), '_projects_options_gallery', true );
			if ( is_array($portfolio_options_gallery) && $portfolio_options_gallery['switch_gallery_to_slider']) {
				remove_shortcode('gallery');
				$create_new_shortcode = 'add' . '_' . 'shortcode';
				$create_new_shortcode('gallery', 'nrg_premium_gallery_to_slider');
			}
		}

		//  change gallery to slider
		function nrg_premium_gallery_to_slider( $atts, $content = '', $id = '' ) {

			  extract( shortcode_atts( array(
			    'ids' => ''
			  ), $atts ) );
			  $ids_gallery = explode( ',', $ids );

			  $portfolio_options_gallery = get_post_meta( get_the_ID(), '_projects_options_gallery', true );
			  if (! is_array($portfolio_options_gallery) ) return;
			  ob_start();
			  ?>
			  <div class="slider-container slider-filter active" data-filter="nature">
		          <div class="slider-wrap">
		              <div class="swiper-container main-slider" data-autoplay="<?php echo esc_attr( $portfolio_options_gallery['autoplay'] ); ?>" data-touch="1" data-mouse="0" data-slides-per-view="1" data-loop="<?php echo esc_attr( $portfolio_options_gallery['loop'] ); ?>" data-speed="<?php echo esc_attr( $portfolio_options_gallery['speed'] ); ?>" data-mode="horizontal">
		                  <div class="swiper-wrapper">
		                  	<?php  foreach ( $ids_gallery as $id ) : ?>
		                      <div class="swiper-slide swiper-d">
		                          <div class="clip">
		                              <?php $url_image = wp_get_attachment_image_url( $id, 'full'); ?>
		                              <div class="bg-slide" style="background-image:url(<?php echo esc_url( $url_image ); ?>)">
		                              </div>
		                          </div>
		                      </div>
		                    <?php endforeach; ?>
		                  </div>
		                  <div class="slide-prev slide-detail-prev"><i class="fa fa-long-arrow-left"></i></div>
		                  <div class="slide-next slide-detail-next"><i class="fa fa-long-arrow-right"></i></div>
		                  <div class="pagination vertical-mode pagination-index"></div>
		              </div>
		          </div>
		      </div>
		      <?php
		      return ob_get_clean();
		}
	}
	add_action( 'wp', 'nrg_premium_kill_default_gallery' );

	new NRGPremium_Plugins;
} // end of class_exists

//--ajax url--//
function site_ajaxurl() {
?>
    <script type="text/javascript">var ajaxurl = '<?php print admin_url('admin-ajax.php'); ?>';</script>
<?php
}
add_action('wp_footer','site_ajaxurl');

require_once EF_ROOT.'/post-type.php';