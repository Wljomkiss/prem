<?php 
/*
** 
** Author: NRGTHEMES
** Author URI: http://nrgthemes.com
** Version: 1.0.0 
*/

vc_map( array(
	'name'                    => __( 'Product tabs', 'nrg_premium' ),
	'base'                    => 'nrg_premium_product_tabs',
	'content_element'         => true,
	'show_settings_on_create' => true,
	'description' 		      => __( 'Product tabs', 'nrg_premium' ),
	'category' 				  => __( 'NRGPremium', 'nrg_premium' ),
	'params'          => array(
		array(
			'type'        => 'vc_efa_chosen',
			'heading'     => __( 'Choose Tag', 'nrg_premium' ),
			'param_name'  => 'tag',
			'value'       => nrg_premium_param_values( 'terms', array(
				'taxonomies' => 'product_tag',
			) ),
		),
		array(
			'type'        => 'textfield',
			'heading'     => __( 'Count items', 'nrg_premium' ),
			'param_name'  => 'limit',
			'value'       => '',
			'description' => __( 'Default 20 items.', 'nrg_premium' )
		),
		array(
			'type' => 'textfield',
			'heading' => __( 'Extra class name', 'nrg_premium' ),
			'param_name' => 'el_class',
			'description' => __( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'nrg_premium' ),
			'value' => '',
		),
		array(
			'type' => 'css_editor',
			'heading' => __( 'CSS box', 'nrg_premium' ),
			'param_name' => 'css',
			'group' => __( 'Design options', 'nrg_premium' ),
		),
	) //end params
) );

class WPBakeryShortCode_nrg_premium_product_tabs extends WPBakeryShortCode {
	protected function content( $atts, $content = null) {

		extract( shortcode_atts( array(
			'el_class'	=> '',
			'css'		=> '',
			'tag'		=> '',
			'limit'		=> '',

 		), $atts ) );

		$limit 	  = ( empty( $limit ) || ! is_numeric( $limit ) ) ? 20 : $limit;
		
		$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, $this->settings['base'], $atts );
		
		// custum css
		$css_class .= vc_shortcode_custom_css_class( $css, ' ' );

		// custum class
		$css_class .= (!empty($el_class)) ? ' '.$el_class : '';
		
		if( $tag ){
			$tags = explode( ',', $tag );
			$i = 1;
			$tab_first = $tabs_filter = $tab_item = $slide = '';
			foreach( $tags as $item ){
				$args = array(
					'post_type'      => 'product',
					'posts_per_page' => $limit,
					'order'			 => 'DESC',
					'tax_query'      => array(
						array(
							'taxonomy' => 'product_tag',
							'field'    => 'id',
							'terms'    => $item
						)
					)
				);
				$query = new WP_Query( $args );
				if( $query->have_posts() ){
					while( $query->have_posts() ){ $query->the_post();
						global $product;
						$slide.= '<div class="swiper-slide">';
						$slide.= '<div class="product-item '.( $product->is_on_sale() ? 'hot' : '' ).'">';
						$slide.= '<div class="image">';
						if ( $product->is_on_sale() )
							$slide.= '<div class="category">'.esc_html__('Hot', 'nrg_premium').'</div>';
						$slide.= '<div class="prod-view"><a href="#" class="open-popup" data-popup="index-popup-1">quick view</a></div>';
						$slide.= '<img src="'.get_the_post_thumbnail_url().'" alt="'.get_the_title().'" class="resp-img">';
						$slide.= '<div class="product-button">';
						$slide.= '<a href="'.get_the_permalink().'" class="prod-more">'.esc_html__('view more','nrg_premium').'</a>';
						$slide.= '<div class="prod-icon-link add-to-wish"><i class="fa fa-heart-o"></i><i class="fa fa-heart"></i>'.do_shortcode('[yith_wcwl_add_to_wishlist]').'</div>';
						$slide.= '<a href="#" class="prod-icon-link add-to-cart" data-quantity="1" data-postid="'.wp_kses_post( $product->get_id() ).'"><i class="fa fa-shopping-basket"></i><i class="fa fa-spinner"></i><i class="fa fa-check-circle-o"></i></a>';
						$slide.= '</div>';
						$slide.= '</div>';
						$slide.= '<div class="text">';
						$slide.= '<div class="empty-sm-20 empty-xs-20"></div>';
						$slide.= '<h6 class="h6 title"><a href="'.get_the_permalink().'">'.get_the_title().'</a></h6>';
						$slide.= '<i class="prod-subtitle">'.get_the_excerpt().'</i>';
						$slide.= '<span class="prod-price">'.$product->get_price_html().'</span>';
						$slide.= '</div>';
						$slide.= '</div>';
						$slide.= '</div>';
					}
					$filter = get_term( $item, 'product_tag' );
					if( $filter ){
						if( $i == 1 )
							$tab_first = '<div class="select-txt second-font"><p>'.$filter->name.'</p><i class="fa fa-angle-down"></i></div>';
						$tabs_filter.= '<li'.( $i == 1 ? ' class="active"' : '' ).'><a>'.$filter->name.'</a></li>';
					}
					$tab_item.= '<div class="tab-item">';
					$tab_item.= '<div class="arrow-closest arrow-hover align-arrow">';
					$tab_item.= '<div class="row">';
					$tab_item.= '<div class="swiper-container gutter-15" data-mode="horizontal" data-autoplay="0" data-effect="slide" data-slides-per-view="responsive" data-loop="0" data-speed="800" data-add-slides="4" data-lg-slides="4" data-md-slides="3" data-sm-slides="2" data-xs-slides="1">';
					$tab_item.= '<div class="swiper-wrapper">';
						$tab_item.= $slide;
					$tab_item.= '</div>';
					$tab_item.= '<div class="pagination pagination-hide"></div>';
					$tab_item.= '</div>';
					$tab_item.= '<div class="swiper-arrow-left slider-arrow-1"><i class="fa fa-angle-left"></i></div>';
					$tab_item.= '<div class="swiper-arrow-right slider-arrow-1"><i class="fa fa-angle-right"></i></div>';
					$tab_item.= '</div>';
					$tab_item.= '</div>';
					$tab_item.= '</div>';
					wp_reset_postdata();
				}
				$slide = '';
				$i++;
			}
			if( $tab_item ){
		 		// output
				ob_start();
				do_shortcode( $content ); ?>
				<!--Tabs -->
				<div class="filter-products <?php print esc_attr( $css_class ); ?>"> 
					<div class="tabs-block"> 
						<div class="filter-list-mobile list-mobile-2">
							<?php print $tab_first; ?>
							<ul class="tabs-link-type-1 type-2 tabs-link second-font filter-list">
								<?php print $tabs_filter; ?>
							</ul>
						</div>
						<div class="empty-md-80 empty-sm-40 empty-xs-40"></div>
						<div class="tabs-container"><?php print $tab_item; ?></div>
					</div>
				</div>
				<?php return  ob_get_clean();
			}
		}
	}
}