<?php 
/*
** Heading
** Author: NRGTHEMES
** Author URI: http://nrgthemes.com
** Version: 1.0.0 
*/

vc_map( array(
	'name'                    => __( 'Heading', 'nrg_premium' ),
	'base'                    => 'nrg_premium_heading',
	'category' 				  => __( 'NRGPremium', 'nrg_premium' ),
	'content_element'         => true,
	'show_settings_on_create' => true,
	'description' 		      => __( 'Title, Subtitle, short description', 'nrg_premium' ),
	'params'          => array(
		array(
			'type'        => 'dropdown',
			'heading'     => __( 'Type', 'nrg_premium' ),
			'param_name'  => 'type',
			'value'       => array(
				'Type 1'	=> 'type_1',
				'Type 2'	=> 'type_2',
				'Type 3'	=> 'type_3',
				'Type 4'	=> 'type_4',
				'Type 5'	=> 'type_5',
				'Type 6'	=> 'type_6',
				'Type 7'	=> 'type_7',
				'Type 8'	=> 'type_8',
				'Type 9'	=> 'type_9',
				'Type 10'	=> 'type_10',
			),
		),
		array(
			'type'        => 'attach_image',
			'heading'     => __( "Icon", "nrg_premium" ),
			'param_name'  => 'icon',
			'admin_label' => true,
			'description' => 'Upload your image.',
			'dependency'  => array( 'element' => 'type', 'value' => array('type_5', 'type_1', 'type_6')),
		),
		array(
			'type'        => 'dropdown',
			'heading'     => __( 'Icon place', 'nrg_premium' ),
			'param_name'  => 'icon_place',
			'value'       => array(
				'After title'   		=> 'aft_title',
				'after description'		=> 'aft_desc',
			),
			'dependency'  => array( 'element' => 'type', 'value' => 'type_1'),
		),
		array(
			'type' 		  => 'checkbox',
			'heading'	  => __( 'All content center', 'nrg_premium' ),
			'param_name'  => 'check_all_center',
			'dependency'  => array( 'element' => 'type', 'value' => 'type_3'),
		),
		array(
			'type'        => 'textfield',
			'heading'     => 'Title',
			'param_name'  => 'title',
			'admin_label' => true,
			'value'       => '',
		),
		array(
			'type'        => 'dropdown',
			'heading'     => __( 'Heading separator', 'nrg_premium' ),
			'param_name'  => 'separator',
			'value'       => array(
				'Disable'		=> 'disable',
				'Enable'		=> 'enable',
			),
			'dependency'  => array( 'element' => 'type', 'value' => array('type_1', 'type_2')),
		),
		array(
			'type'        => 'dropdown',
			'heading'     => __( 'Title class', 'nrg_premium' ),
			'param_name'  => 'title_h',
			'value'       => array(
				'H2'		=> 'h2',
				'H3'		=> 'h3',
			),
			'dependency'  => array( 'element' => 'type', 'value' => 'type_1'),
		),
		array(
			'type'        => 'dropdown',
			'heading'     => __( 'Color type', 'nrg_premium' ),
			'param_name'  => 'color_type',
			'value'       => array(
				'Dark'		=> 'dark',
				'Light'		=> 'light',
				),
			'dependency'  => array( 'element' => 'type', 'value' => array('type_3', 'type_1', 'type_6')),
		),
		array(
			'type'        => 'textfield',
			'heading'     => 'Subtitle',
			'param_name'  => 'subtitle',
			'admin_label' => true,
			'value'       => '',
		),
		array(
			'type' => 'textarea',
			'heading'     => __( 'Short Description', 'nrg_premium' ),
			'param_name'  => 'short_desc',
		),
		array(
			'type'        => 'textfield',
			'heading'     => 'Button title',
			'param_name'  => 'button_title',
			'admin_label' => true,
			'value'       => '',
			'dependency'  => array( 'element' => 'type', 'value' => 'type_7'),
		),
		array(
			'type'        => 'vc_link',
			'heading'     => 'Button url',
			'param_name'  => 'button_url',
			'admin_label' => true,
			'value'       => '',
			'dependency'  => array( 'element' => 'type', 'value' => 'type_7'),
		),
		array(
			'type'        => 'dropdown',
			'heading'     => __( 'Align text', 'nrg_premium' ),
			'param_name'  => 'text_align',
			'value'       => array(
				'Align left'   => 'left',
				'Align center' => 'center',
				'Align right'  => 'right',
			),
		),
		array(
			'type' => 'textfield',
			'heading' => __( 'Extra class name', 'nrg_premium' ),
			'param_name' => 'el_class',
			'description' => __( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'nrg_premium' ),
			'value' => '',
		),
		array(
			'type' => 'css_editor',
			'heading' => __( 'CSS box', 'nrg_premium' ),
			'param_name' => 'css',
			'group' => __( 'Design options', 'nrg_premium' ),
		),
	) //end params
) );

class WPBakeryShortCode_nrg_premium_heading extends WPBakeryShortCode {
	protected function content( $atts, $content = null) {

		extract( shortcode_atts( array(
			'el_class'     => '',
			'css'          => '',
			'title'        => '',
			'subtitle'     => '',
			'short_desc'   => '',
			'type'		   => 'type_1',
			'text_align'	=> 'left',
			'check_all_center' => false,
			'icon'			=> '',
			'separator'		=> 'disable',
			'button_url'	=> '',
			'button_title'	=> '',
			'color_type'	=> 'dark',
			'icon_place'	=> 'aft_title',
			'title_h'		=> 'h2',


 		), $atts ) );

		$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, $this->settings['base'], $atts );
		
		// custum css
		$css_class .= vc_shortcode_custom_css_class( $css, ' ' );

		// custum class
		$css_class .= (!empty($el_class)) ? ' '.$el_class : '';

		if ($button_url) {
			$button_link = vc_build_link($button_url);
		}

		$custom_pad = '';
		if ($type == 'type_3') {
			if ($check_all_center == true){
			$custom_pad = esc_html(' custome-padd-70 ');
			}
		}

		$image_html = '';
		if (!empty($icon)) {
		$image_full = wp_get_attachment_image_url( $icon, 'full' );
		$image_html = '<img src="'. esc_url( $image_full ). '" alt="">';
		}

		$col_desc = $t_type_3 = '';
		if ($color_type == 'dark') {
			$col_desc = 'col-1';
		} else {
			$col_desc = 'col-3';
			$t_type_3 = 'type-2';
		}


 		// output
		ob_start();
		do_shortcode( $content );
		?>
		<!--TITLE -->
		<?php if ($type == 'type_1' || $type == 'type_2' || $type == 'type_3' || $type == 'type_4' || $type == 'type_5' || $type == 'type_6' ) { ?>
			<div class="caption text-<?php print esc_html($text_align);?> <?php print $t_type_3; ?> <?php print $custom_pad;?> <?php print esc_attr( $css_class ); ?>">
				<?php if ($type == 'type_5') { ?>
					<?php print $image_html ?>
					<div class="empty-sm-20 empty-xs-15"></div>
				<?php } ?>
				<?php if($type == 'type_3') { ?>
					<div class="title-separator-2"><span></span></div>
				    <div class="empty-sm-25 empty-xs-25"></div>
			    <?php }?>
				<?php if ($type == 'type_1' || $type == 'type_2' || $type == 'type_4' || $type == 'type_5') { ?>
					<?php if ($subtitle) { ?>
						<span class="sub-title <?php echo ($color_type == 'light' ? 'subt_light' : '') ?> <?php if($type == 'type_2') {print 'sm';} elseif ($type == 'type_4') {print 'ls col-5';} elseif ($type == 'type_5') {print 'col-8';}?>"><?php print wp_kses_post( $subtitle ); ?></span>
						<?php if ($type == 'type_5') { ?>
							<div class="empty-sm-10 empty-xs-10"></div>
						<?php } else { ?>
							<div class="empty-sm-5 empty-xs-5"></div>
						<?php }
					} 
				}?>

				<?php if ($title) { 
					if($type == 'type_1') { ?> 
						<h2 class="<?php echo ($title_h == 'h2' ? 'h2' : 'h3')?> title"><?php print esc_html($title); ?></h2>
						<div class="empty-sm-15 empty-xs-15"></div>
						<?php if($separator == 'enable') { ?>
							<div class="title-separator-3"></div>
							<div class="empty-sm-25 empty-xs-20"></div>
						<?php } ?>
						<?php if (!empty($icon) && $icon_place == 'aft_title') { ?>
							<?php print $image_html ?>
							<div class="empty-sm-40 empty-xs-30"></div>
						<?php } ?>
					<?php } elseif ($type == 'type_2')  { ?>
						<h4 class="h4 title"><?php print esc_html($title); ?></h2>
						<div class="empty-sm-25 empty-xs-25"></div>
						<?php if ($separator == 'enable') { ?>
							<div class="title-separator-1"><span></span></div>
						<?php } ?>
						<div class="empty-lg-0 empty-md-0 empty-sm-30 empty-xs-30"></div>
					<?php } elseif ($type == 'type_3') { ?> 
						<h2 class="h2 title"><?php print esc_html($title); ?></h2>
					    <div class="empty-sm-25 empty-xs-25"></div>
					<?php } elseif ($type == 'type_4') { ?>
						<h5 class="h5"><?php print esc_html($title); ?></h5>
	                   <div class="empty-sm-15 empty-xs-15"></div>
					<?php } elseif ($type == 'type_5') { ?>
						<h1 class="h1 title"><?php print esc_html($title); ?></h1>
						<div class="empty-sm-15 empty-xs-15"></div>
					<?php } elseif ($type == 'type_6') {?>
						<h2 class="h2 title"><?php print esc_html($title); ?></h2>
						<div class="empty-sm-15 empty-xs-15"></div>
					<?php } ?>
				<?php } ?>

				<?php if($type == 'type_3') { 
					if ($subtitle) { ?>
					<div class="sub-title <?php echo ($color_type == 'light' ? 'subt_light' : '') ?>"><?php print wp_kses_post( $subtitle ); ?></div>
					<?php } 
				} ?>

	            <?php if ($type == 'type_6' && $subtitle ) { ?>
	                <div class="simple-text md <?php echo esc_html($col_desc); ?>">
	                    <p><?php print esc_html( $subtitle ); ?></p>
	                </div>
	                <?php if (!empty($icon)) { ?>
	                    <div class="empty-sm-20 empty-xs-20"></div>
	                    <?php print $image_html ?>
	                <?php } ?>
	            <?php } ?>

				<?php if($type == 'type_1' || $type == 'type_2' || $type == 'type_3' || $type == 'type_4' || $type == 'type_6') {
					if( $short_desc ){ ?>
						<?php if ($type == 'type_6') { ?>
							<div class="empty-sm-50 empty-xs-40"></div>
						<?php } elseif ($type == 'type_3') { ?>
							<div class="empty-sm-40 empty-xs-40"></div>
						<?php }?>
						<div class="simple-text <?php if ($type == 'type_1'){print 'md '; print esc_html($col_desc);} ?> <?php echo ($type == 'type_6' ? 'col-1' : '' ); ?>"> 
							<p><?php print wp_kses_post($short_desc); ?></p>
						</div>
						<?php if ($type == 'type_1'){ ?>
							<?php if (!empty($icon) && $icon_place == 'aft_desc') { ?>
								<div class="empty-sm-20 empty-xs-20"></div>
								<?php print $image_html ?>
							<?php } ?>
						<?php } ?>
					<?php }
				} ?>
				<?php if ($type == 'type_5') { 
					if( $short_desc ){ ?>
						<div class="row">
							<div class="col-md-8 col-md-offset-2">
								<div class="simple-text col-1 lg">
									<p><?php print wp_kses_post($short_desc); ?></p>
								</div>  
							</div>
						</div>
					<?php } 
				}?>
			</div>
		<?php } elseif ($type == 'type_7') { ?>
			<div class="frame-block text-<?php print esc_html($text_align);?> sm-frame">
				<div class="empty-lg-90 empty-md-90 empty-sm-60 empty-xs-60"></div>
				<div class="custome-padd-80">
					<div class="caption type-2">
						<?php if ($title) { ?>
							<h2 class="h2 title"><?php echo esc_html($title); ?></h2>
							<div class="empty-sm-25 empty-xs-20"></div>
						<?php } 
						if ($subtitle) { ?>
							<div class="simple-text md col-3">
								<p><?php echo esc_html($subtitle); ?></p>
							</div>
						<?php }
						if (isset($button_link) && $button_title) { ?>
							<div class="empty-sm-30 empty-xs-30"></div>
							<a href="<?php print esc_html($button_link['url'])?>" class="main-link link-style-1 type-3 color-1 wh-md"><span><?php echo esc_html($button_title); ?></span></a>
						<?php } ?>
					</div>        
				</div>
				<div class="empty-lg-90 empty-md-90 empty-sm-60 empty-xs-60"></div>
			</div>
		<?php } elseif ($type == 'type_8') { ?>
			<div class="caption-bg-style <?php echo ($text_align == 'left'? 'left-position' : ''); ?>">
				<?php if ($subtitle) { ?>
					<div class="sub-title ls col-2"><i><?php echo esc_html($subtitle);?></i></div>
					<div class="empty-sm-10 empty-xs-10"></div>
				<?php }
				if ($title) { ?>
					<h3 class="title h4 lg tt"><?php echo esc_html($title);?></h3>
				<?php } ?>
			</div>
		<?php } elseif ($type == 'type_9') { ?>
			<div class="caption text-<?php print esc_html($text_align);?>">
					<h4 class="h4 lg tt"><?php echo esc_html($title);?></h4>
					<div class="empty-sm-20 empty-xs-20"></div>
					<div class="simple-text md col-1">
					<p><i><?php echo esc_html($subtitle);?></i></p>
					</div> 
			</div>
		<?php } elseif ($type == 'type_10') { ?>
			<div class="caption text-<?php print esc_html($text_align);?> type-2">
				<?php if ($subtitle) { ?>
					<div class="sub-title col-2 ls"><?php echo esc_html($subtitle);?></div>
					<div class="empty-sm-10 empty-xs-10"></div>
				<?php } 
				if ($title) { ?>
					<h2 class="h2 title"><?php echo esc_html($title);?></h2>
				<?php } 
				if ($short_desc) { ?>
					<div class="empty-sm-20 empty-xs-20"></div>
					<div class="simple-text col-2 md">
						<p><?php echo wp_kses_post($short_desc);?></p>
					</div>
				<?php } ?>
				<div class="empty-lg-80 empty-md-60 empty-sm-60 empty-xs-40"></div>
			</div>
		<?php } ?>
		<?php 
		return  ob_get_clean();
	}
}