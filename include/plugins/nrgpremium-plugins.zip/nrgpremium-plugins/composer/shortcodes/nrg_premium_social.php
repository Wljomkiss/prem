<?php 
/*
** Social
** Author: NRGTHEMES
** Author URI: http://nrgthemes.com
** Version: 1.0.0 
*/

vc_map( array(
	'name'                    => __( 'Follow us', 'nrg_premium' ),
	'base'                    => 'nrg_premium_social',
	'content_element'         => true,
	'show_settings_on_create' => true,
	'description' 		      => __( 'Shortcode Follow us use info from Theme Options. There you can change info. ', 'nrg_premium' ),
	'category' 				  => __( 'NRGPremium', 'nrg_premium' ),
	'params'          => array(
		array(
			'type' => 'textfield',
			'heading' => __( 'Extra class name', 'nrg_premium' ),
			'param_name' => 'el_class',
			'description' => __( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'nrg_premium' ),
			'value' => '',
		),
		array(
			'type' => 'css_editor',
			'heading' => __( 'CSS box', 'nrg_premium' ),
			'param_name' => 'css',
			'group' => __( 'Design options', 'nrg_premium' ),
		),
	) //end params
) );

class WPBakeryShortCode_nrg_premium_social extends WPBakeryShortCode {
	protected function content( $atts, $content = null) {

		extract( shortcode_atts( array(
			'el_class' 	   => '',
			'css'          => '',
 		), $atts ) );

		$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, $this->settings['base'], $atts );
		
		// custum css
		$css_class .= vc_shortcode_custom_css_class( $css, ' ' );

		// custum class
		$css_class .= (!empty($el_class)) ? ' '.$el_class : '';

 		// output
		ob_start();
		do_shortcode( $content );
		?>
		<!--Follow us -->
		<div class="follow-link follow-link-hov <?php print esc_attr( $css_class ); ?>">
			<h6 class="h7 title"><?php print esc_html__('Follow us', 'nrg_premium');?></h6>
			<?php nrg_premium_get_social();?>
		</div> 
		<?php 
		return  ob_get_clean();
	}
}