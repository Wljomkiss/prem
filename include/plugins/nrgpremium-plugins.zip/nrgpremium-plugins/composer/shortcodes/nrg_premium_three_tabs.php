<?php 
/*
** three tabs
** Author: NRGTHEMES
** Author URI: http://nrgthemes.com
** Version: 1.0.0 
*/

vc_map( array(
	'name'						=> __( 'Three tabs', 'nrg_premium' ),
	'base'						=> 'nrg_premium_three_tabs',
	'category'					=> __( 'NRGPremium', 'nrg_premium' ),
	'content_element'			=> true,
	'show_settings_on_create'	=> true,
	'description'				=> __( 'Three tabs', 'nrg_premium' ),
	'params'					=> array(
		array(
			'type'			=> 'textfield',
			'heading'		=>  __( "Title", "nrg_premium" ),
			'param_name'	=> 'title',
			'admin_label'	=> true,
			'value'			=> '',
		),
		array(
			'type'			=> 'textfield',
			'heading'		=>  __( "Subtitle", "nrg_premium" ),
			'param_name'	=> 'subtitle',
			'admin_label'	=> true,
			'value'			=> '',
		),

		// TAB 1
		array(
			'type'			=> 'textfield',
			'heading'		=>  __( "Tab title 1", "nrg_premium" ),
			'param_name'	=> 'tab_title_1',
			'value'			=> '',
			'group'			=> 'Tab 1',
		),
		array(
			'type'			=> 'textfield',
			'heading'		=>  __( "Title", "nrg_premium" ),
			'param_name'	=> 'title_1',
			'value'			=> '',
			'group'			=> 'Tab 1',
		),
		array(
			'type'			=> 'textarea',
			'heading'		=> __( 'Short Description', 'nrg_premium' ),
			'param_name'	=> 'short_desc_1',
			'group'			=> 'Tab 1',
		),
		array(
			'type'			=> 'textfield',
			'heading'		=> 'Button title',
			'param_name'	=> 'button_title_1',
			'value'			=> '',
			'group'			=> 'Tab 1',
		),
		array(
			'type'			=> 'vc_link',
			'heading'		=> 'Button url',
			'param_name'	=> 'button_url_1',
			'value'			=> '',
			'group'			=> 'Tab 1',
		),
		// TAB 2
		array(
			'type'			=> 'textfield',
			'heading'		=>  __( "Tab title 2", "nrg_premium" ),
			'param_name'	=> 'tab_title_2',
			'value'			=> '',
			'group'			=> 'Tab 2',
		),
		array(
			'type'			=> 'textfield',
			'heading'		=>  __( "Title", "nrg_premium" ),
			'param_name'	=> 'title_2',
			'value'			=> '',
			'group'			=> 'Tab 2',
		),
		array(
			'type'			=> 'textarea',
			'heading'		=> __( 'Short Description', 'nrg_premium' ),
			'param_name'	=> 'short_desc_2',
			'group'			=> 'Tab 2',
		),
		array(
			'type'			=> 'textfield',
			'heading'		=> 'Button title',
			'param_name'	=> 'button_title_2',
			'value'			=> '',
			'group'			=> 'Tab 2',
		),
		array(
			'type'			=> 'vc_link',
			'heading'		=> 'Button url',
			'param_name'	=> 'button_url_2',
			'value'			=> '',
			'group'			=> 'Tab 2',
		),
		// TAB 3
		array(
			'type'			=> 'textfield',
			'heading'		=>  __( "Tab title 3", "nrg_premium" ),
			'param_name'	=> 'tab_title_3',
			'value'			=> '',
			'group'			=> 'Tab 3',
		),
		array(
			'type'			=> 'textfield',
			'heading'		=>  __( "Title", "nrg_premium" ),
			'param_name'	=> 'title_3',
			'value'			=> '',
			'group'			=> 'Tab 3',
		),
		array(
			'type'			=> 'textarea',
			'heading'		=> __( 'Short Description', 'nrg_premium' ),
			'param_name'	=> 'short_desc_3',
			'group'			=> 'Tab 3',
		),
		array(
			'type'			=> 'textfield',
			'heading'		=> 'Button title',
			'param_name'	=> 'button_title_3',
			'value'			=> '',
			'group'			=> 'Tab 3',
		),
		array(
			'type'			=> 'vc_link',
			'heading'		=> 'Button url',
			'param_name'	=> 'button_url_3',
			'value'			=> '',
			'group'			=> 'Tab 3',
		),

		array(
			'type'			=> 'textfield',
			'heading'		=> __( 'Extra class name', 'nrg_premium' ),
			'param_name'	=> 'el_class',
			'description'	=> __( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'nrg_premium' ),
			'value'			=> '',
		),
		array(
			'type'			=> 'css_editor',
			'heading'		=> __( 'CSS box', 'nrg_premium' ),
			'param_name'	=> 'css',
			'group'			=> __( 'Design options', 'nrg_premium' ),
		),
	) //end params
) );

class WPBakeryShortCode_nrg_premium_three_tabs extends WPBakeryShortCode {
	protected function content( $atts, $content = null) {

		extract( shortcode_atts( array(
			'el_class'		=> '',
			'css'			=> '',
			'title'			=> '',
			'subtitle'		=> '',
			'tab_title_1'	=> '',
			'title_1'		=> '',
			'short_desc_1'	=> '',
			'tab_title_2'	=> '',
			'title_2'		=> '',
			'short_desc_2'	=> '',
			'tab_title_3'	=> '',
			'title_3'		=> '',
			'short_desc_3'	=> '',
			'button_url_1'	=> '',
			'button_url_2'	=> '',
			'button_url_3'	=> '',
			'button_title_1'	=> '',
			'button_title_2'	=> '',
			'button_title_3'	=> '',

 		), $atts ) );

		$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, $this->settings['base'], $atts );
		
		// custum css
		$css_class .= vc_shortcode_custom_css_class( $css, ' ' );

		// custum class
		$css_class .= (!empty($el_class)) ? ' '.$el_class : '';

 		// output
		ob_start();
		do_shortcode( $content );
		?>
		<!--three tabs-->
		<div class="<?php print esc_attr( $css_class ); ?> section">                   
			<div class="container-fluid no-padd">
				<div class="row vertical-wrap">
					<?php if ($title || $subtitle) {?>
						<div class="col-md-3 col-sm-12 col-xs-12">
							<div class="caption type-2 text-center bg-section-9 padd-50">
								<div class="empty-sm-60 empty-xs-40"></div>
								<?php if ($subtitle) { ?>
									<div class="sub-title col-2 ls"><?php echo esc_html($subtitle); ?></div>
								<?php } 
								if ($title) { ?>
									<div class="empty-sm-5 empty-xs-5"></div>
									<h2 class="h2 title tt"><?php echo esc_html($title);?></h2>
								<?php } ?>
								<div class="empty-sm-60 empty-xs-40"></div>
							</div>
						</div>
						<div class="col-md-9 col-sm-12 col-xs-12">
					<?php } else { ?>
						<div class="col-md-12 col-sm-12 col-xs-12">
					<?php } ?>
						<div class="slider-custome vertical-wrap">
							<ul class="slider-tabs align-item">
								<li class="active"><h5 class="h5 title"><?php echo esc_html($tab_title_1);?></h5></li>
								<li><h5 class="h5 title"><?php echo esc_html($tab_title_2);?></h5></li>
								<li><h5 class="h5 title"><?php echo esc_html($tab_title_3);?></h5></li>
							</ul>
							<div class="slider-container align-item">
								<?php if ($tab_title_1) { ?>
									<?php if ($title_1 || $short_desc_1) { ?>
										<div class="slider-container-item active">
											<div class="flex-align full-h">
												<div class="wrap custome-padd-100">
													<?php if ($title_1) { ?>
														<div class="caption">
															<h2 class="h2 title"><?php echo esc_html($title_1);?></h2>
														</div>
													<?php }
													if ($short_desc_1) { ?>
														<div class="empty-sm-40 empty-xs-30"></div>
														<div class="simple-text col-1">
															<?php echo wpautop($short_desc_1);?>
														</div>
													<?php } 
													$button_link_1 = vc_build_link($button_url_1);
													if ($button_title_1 && isset($button_link_1)) { ?>
														<div class="empty-sm-40 empty-xs-30"></div>
														<a href="<?php echo $button_link_1['url']?>" class="main-link link-style-1 type-3 color-6"><span><?php echo esc_html($button_title_1);?></span></a> 
													<?php } ?>
												</div>
											</div>
										</div>
									<?php }
								}
								if ($tab_title_2) { 
									if ($title_2 || $short_desc_2) { ?>
										<div class="slider-container-item">
											<div class="flex-align full-h">
												<div class="wrap custome-padd-100">
													<?php if ($title_2) { ?>
														<div class="caption">
															<h2 class="h2 title"><?php echo esc_html($title_2);?></h2>
														</div>
													<?php }
													if ($short_desc_2) { ?>
														<div class="empty-sm-40 empty-xs-30"></div>
														<div class="simple-text col-1">
															<?php echo wpautop($short_desc_2);?>
														</div>
													<?php }
													$button_link_2 = vc_build_link($button_url_2);
													if ($button_title_2 && isset($button_link_2)) { ?>
														<div class="empty-sm-40 empty-xs-30"></div>
														<a href="<?php echo $button_link_2['url']?>" class="main-link link-style-1 type-3 color-6"><span><?php echo esc_html($button_title_2);?></span></a> 
													<?php } ?> 
												</div>
											</div>
										</div>
									<?php }
								}
								if ($tab_title_3) { 
									if ($title_3 || $short_desc_3) { ?>
										<div class="slider-container-item">
											<div class="flex-align full-h">
												<div class="wrap custome-padd-100">
													<?php if ($title_1) { ?>  
														<div class="caption">
															<h2 class="h2 title"><?php echo esc_html($title_3);?></h2>
														</div>
													<?php } 
													if ($short_desc_3) { ?>
														<div class="empty-sm-40 empty-xs-30"></div>
														<div class="simple-text col-1">
															<?php echo wpautop($short_desc_3);?>
														</div>
													<?php }
													$button_link_3 = vc_build_link($button_url_3);
													if ($button_title_3 && isset($button_link_3)) { ?>
														<div class="empty-sm-40 empty-xs-30"></div>
														<a href="<?php echo $button_link_3['url']?>" class="main-link link-style-1 type-3 color-6"><span><?php echo esc_html($button_title_3);?></span></a> 
													<?php } ?> 
												</div>
											</div>
										</div>
									<?php } 
								} ?>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<?php 
		return  ob_get_clean();
	}
}