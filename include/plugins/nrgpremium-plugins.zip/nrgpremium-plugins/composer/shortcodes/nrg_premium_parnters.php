<?php 
/*
** Partners
** Version: 1.0.0 
*/

vc_map( array(
	'name'						=> __( 'Partners', 'nrg_premium' ),
	'base'						=> 'nrg_premium_partners',
	'as_parent'					=> array('only' => 'nrg_premium_partners_item'),
	'content_element'			=> true,
	'show_settings_on_create'	=> false,
	'category'					=> __( 'NRGPremium', 'nrg_premium' ),
	'description'				=> __( 'Partners', 'nrg_premium'),
	'js_view'					=> 'VcColumnView',
	'params'					=> array(
		array(
			'type' => 'textfield',
			'heading' => __( 'Extra class name', 'nrg_premium' ),
			'param_name' => 'el_class',
			'description' => __( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'nrg_premium' ),
			'value' => '',
		),
		array(
			'type' => 'css_editor',
			'heading' => __( 'CSS box', 'nrg_premium' ),
			'param_name' => 'css',
			'group' => __( 'Design options', 'nrg_premium' ),
		),
	) //end params
) );

class WPBakeryShortCode_nrg_premium_partners extends WPBakeryShortCodesContainer {

	protected function content( $atts, $content = null) {

		extract( shortcode_atts( array(
			'el_class'		=> '',
			'css'			=> '',
			'bg_col'		=> '',
		), $atts ) );

		global $_parnters_1_items;
		$_parnters_1_items = array();

		$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, $this->settings['base'], $atts );

		// custum css
		$css_class .= vc_shortcode_custom_css_class( $css, ' ' );

		// custum class
		$css_class .= (!empty($el_class)) ? ' '.$el_class : '';
		
		// output
		ob_start();
		do_shortcode( $content );
		?>
			<div class="<?php print esc_attr( $css_class ); ?> client-block">
				<?php foreach ($_parnters_1_items as $key => $shortcode) :
				$shortcode_atts = $shortcode['atts'];?>
					<a href="<?php echo (isset($shortcode_atts['url']) ? vc_build_link($shortcode_atts['url'])['url'] : '#');?>" class="flex-align col-20">
						<img src="<?php echo esc_url(wp_get_attachment_image_url( $shortcode_atts['image'], 'full' )); ?>" alt=""> 
						<img src="<?php echo esc_url(wp_get_attachment_image_url( $shortcode_atts['image_hover'], 'full' )); ?>" alt="" class="hov center-align">
					</a>
				<?php endforeach; ?>
			</div>
		<?php
		return  ob_get_clean();
	}

}
/* Shortvode Item */

vc_map( array(
  'name'					=> 'Partners Item',
  'base'					=> 'nrg_premium_partners_item',
  'as_child'				=> array('only' => 'nrg_premium_partners'),
  'content_element'			=> true,
  'show_settings_on_create'	=> true,
  'description'				=> 'Slider item',
  'params'					=> array(
		array(
			'type'			=> 'attach_image',
			'heading'		=> __( 'Image', 'nrg_premium' ),
			'param_name'	=> 'image',
			'admin_label'	=> true,
			'description'	=> 'Upload your image.'
		),
		array(
			'type'			=> 'attach_image',
			'heading'		=> __( 'Image hover', 'nrg_premium' ),
			'param_name'	=> 'image_hover',
			'admin_label'	=> true,
			'description'	=> 'Upload your image.'
		),
		array(
			'type'			=> 'vc_link',
			'heading'		=> __( 'Link', 'nrg_premium' ),
			'param_name'	=> 'url',
			'value'			=> '',
		),
  ) //end params
) );


class WPBakeryShortCode_nrg_premium_partners_item extends WPBakeryShortCode{
	protected function content( $atts, $content = null ) {
		global $_parnters_1_items;
		$_parnters_1_items[] = array('atts' => $atts, 'content' => $content, 'css_class' => '');
		return;
	}
}