<?php 
/*
** Team slider
** Version: 1.0.0 
*/


vc_map( array(
	'name'                    => __( 'Team slider', 'nrg_premium' ),
	'base'                    => 'nrg_premium_team_slider',
	'as_parent'               => array('only' => 'nrg_premium_team_slider_item'),
	'content_element'         => true,
	'show_settings_on_create' => true,
	'category' 				  => __( 'NRGPremium', 'nrg_premium' ),
	'description'             => __( 'Team slider', 'nrg_premium'),
	'js_view'                 => 'VcColumnView',
	'params'          => array(
		array(
			'type'			=> 'dropdown',
			'heading'		=> __( 'Type team slider', 'nrg_premium' ),
			'param_name'	=> 'type_slider',
			'value'			=> array(
				'Type 1'		=> 'type_1',
				'Type 2'		=> 'type_2',
				'Type 3'		=> 'type_3',
			)
		),
		array(
			'type'			=> 'dropdown',
			'heading'		=> __( 'Visible desktop team members', 'nrg_premium' ),
			'param_name'	=> 'visib_lg',
			'value'			=> array(
				'2'		=> '2',
				'3'		=> '3',
			),
			'dependency'  => array( 'element' => 'type_slider', 'value' => 'type_3'),
		),
		array(
			'type'			=> 'dropdown',
			'heading'		=> __( 'Subtype team slider', 'nrg_premium' ),
			'param_name'	=> 'sybtype_sl',
			'value'			=> array(
				'Type 1'		=> 'type_1',
				'Type 2'		=> 'type_2',
				'Type 3'		=> 'type_3',
			),
			'dependency'  => array( 'element' => 'type_slider', 'value' => 'type_2'),
		),
		array(
			'type'			=> 'dropdown',
			'heading'		=> __( 'Slider arrows', 'nrg_premium' ),
			'param_name'	=> 'slider_arrows',
			'value'			=> array(
				'Disable'		=> 'disable',
				'Enable'		=> 'enable',
				)
		),
		array(
			'type'			=> 'dropdown',
			'heading'		=> __( 'Pagination', 'nrg_premium' ),
			'param_name'	=> 'pagi',
			'value'			=> array(
				'Disable'		=> 'disable',
				'Enable'		=> 'enable',
				),
			'dependency'  => array( 'element' => 'type_slider', 'value' => 'type_2'),
		),
		array(
			'type'			=> 'dropdown',
			'heading'		=> __( 'Pagination', 'nrg_premium' ),
			'param_name'	=> 'pagi_type',
			'value'			=> array(
				'Square'		=> 'square',
				'round'			=> 'round',
				),
			'dependency'  => array( 'element' => 'pagi', 'value' => 'enable'),
		),
		array(
			'type'			=> 'colorpicker',
			'class'			=> '',
			'heading'		=> __( 'Main social color', 'nrg_premium' ),
			'param_name'	=> 'm_s_color',
			'value'			=> 'fff',
			'dependency'  => array( 'element' => 'type_slider', 'value' => 'type_2'),
		),
		array(
			'type'			=> 'colorpicker',
			'class'			=> '',
			'heading'		=> __( 'Hover color', 'nrg_premium' ),
			'param_name'	=> 'h_color',
			'value'			=> '#84694e',
		),
		array(
			'type'			=> 'textfield',
			'heading'		=> __( 'Extra class name', 'nrg_premium' ),
			'param_name'	=> 'el_class',
			'description'	=> __( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'nrg_premium' ),
			'value'			=> '',
		),
		array(
			'type'			=> 'css_editor',
			'heading'		=> __( 'CSS box', 'nrg_premium' ),
			'param_name'	=> 'css',
			'group'			=> __( 'Design options', 'nrg_premium' ),
		),
	) //end params
) );

class WPBakeryShortCode_nrg_premium_team_slider extends WPBakeryShortCodesContainer {

	protected function content( $atts, $content = null) {

		extract( shortcode_atts( array(
			'el_class'		=> '',
			'css'			=> '',
			'visib_lg'		=> '2',
			'type_slider'	=> 'type_1',
			'slider_arrows'	=> 'disable',
			'sybtype_sl'	=> 'type_1',
			'pagi'			=> 'disable',
			'pagi_type'		=> 'square',
			'h_color'		=> '',
			'm_s_color'		=> '',

		), $atts ) );

		global $_team_sliders_items;
		$_team_sliders_items = array();

		$data_add = '';
		if ($type_slider == 'type_1') {
			$data_add = '4';
		} else {
			$data_add = '3';
		}

		$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, $this->settings['base'], $atts );

		// custum css
		$css_class .= vc_shortcode_custom_css_class( $css, ' ' );

		// custum class
		$css_class .= (!empty($el_class)) ? ' '.$el_class : '';
		
		$gut = '';
		if ($type_slider == 'type_3' ) {
			$gut = '';
		} else {
			$gut = 'gutter-15';
		}

		$subtype = '';
		$sub_sh_desc = '';
		$sub_sub = ''; 
		if  ($sybtype_sl == 'type_1') {
			$subtype = '';
		} elseif ($sybtype_sl == 'type_2') {
			$subtype = 'sub-type-2';
			$sub_sh_desc = '';
			$sub_sub = 'col-9';
		} elseif ($sybtype_sl == 'type_3') {
			$subtype = 'sub-type-3';
			$sub_sh_desc = 'col-2 sm';
			$sub_sub = 'col-6';
		}

		$hov_class = uniqid('hov-');
		// output
		ob_start();
		do_shortcode( $content );
		?>
		<div class="<?php print esc_attr( $css_class ); ?>">
			<?php if ($type_slider == 'type_3') { ?>
				<div class="arrow-closest mobile-pagination">
			<?php } ?>
				<div class="swiper-container <?php echo $hov_class; ?> <?php echo $gut ?>" data-mode="horizontal" data-autoplay="0" data-effect="slide" data-slides-per-view="responsive" data-loop="0" data-speed="800" data-add-slides="<?php echo esc_html($data_add);?>" data-lg-slides="<?php echo ($type_slider == 'type_3' ? $visib_lg : '3'); ?>" data-md-slides="<?php echo ($type_slider == 'type_3' ? '2' : '3'); ?>" data-sm-slides="2" data-xs-slides="1">
					<div class="swiper-wrapper">
						<?php foreach ($_team_sliders_items as $key => $shortcode) {
							$shortcode_atts = $shortcode['atts'];
							$image_html = '';
							if (isset($shortcode_atts['image'])) {
								$image_full = wp_get_attachment_image_url( $shortcode_atts['image'], 'full' );
								$image_link = '';
								if (isset($shortcode_atts['person_url'])) {
									$image_link = esc_html($shortcode_atts['person_url']);
								}
								$image_html = '<a href="'.$image_link.'" class="image hover-layer"><img src="'.esc_url( $image_full ).'" alt=""></a>';
							} 
							if ($type_slider == 'type_1') { ?>
								<div class="swiper-slide">
									<div class="team-item style-1 hover-block">
										<?php echo $image_html ?>
										<div class="text type-2">
											<div class="empty-sm-30 empty-xs-30"></div>
											<?php if (isset($shortcode_atts['name'])) { ?>
												<h6 class="h6 title"><?php echo esc_html($shortcode_atts['name']) ?></h6>
												<div class="empty-sm-5 empty-xs-5"></div>
											<?php }
											if (isset($shortcode_atts['position'])) { ?>
												<div class="sub-title sm col-4 sub-pos"><?php echo esc_html($shortcode_atts['position']) ?></div>
											<?php }
											if (isset($shortcode_atts['short_desc'])) {?>
												<div class="empty-sm-10 empty-xs-10"></div>
												<div class="simple-text">
							 						<p><?php echo esc_html($shortcode_atts['short_desc']) ?></p>
												</div>
											<?php } 
											if (isset($shortcode_atts['fb_link']) || isset($shortcode_atts['tw_link']) || isset($shortcode_atts['g_link'])) { ?>
												<div class="empty-sm-10 empty-xs-10"></div>
												<div class="folow-style-1 header-folow align-center">
													<?php if (isset($shortcode_atts['fb_link'])) {?>
														<a href="<?php echo esc_html($shortcode_atts['fb_link']) ?>"><span class="fa fa-facebook"></span></a>
													<?php } 
													if (isset($shortcode_atts['tw_link'])) {?>
														<a href="<?php echo esc_html($shortcode_atts['tw_link']) ?>"><span class="fa fa-twitter"></span></a>
													<?php } 
													if (isset($shortcode_atts['g_link'])) {?>
														<a href="<?php echo esc_html($shortcode_atts['g_link']) ?>"><span class="fa fa-google-plus"></span></a>
													<?php } ?>
												</div>
											<?php } ?>

										</div>
									</div>
								</div>
							<?php } elseif ($type_slider == 'type_2') { ?>
								<div class="swiper-slide">
									<div class="team-item style-2 <?php echo $subtype; ?>">
										<?php echo $image_html ?>
										<div class="text">
											<div class="empty-sm-30 empty-xs-30"></div>
											<?php if (isset($shortcode_atts['name'])) { ?>
												<h6 class="h6 title"><?php echo esc_html($shortcode_atts['name']) ?></h6>
													<div class="empty-sm-5 empty-xs-5"></div>
											<?php }
											if (isset($shortcode_atts['position'])) {?>
												<div class="sub-title sm <?php echo $sub_sub; ?> tt"><?php echo esc_html($shortcode_atts['position']) ?></div>
											<?php } ?> 
											<div class="hover-hide">
												<?php if (isset($shortcode_atts['short_desc'])) {?>
													<div class="empty-sm-10 empty-xs-10"></div>
													<div class="simple-text <?php echo $sub_sh_desc; ?>">
														<p><?php echo esc_html($shortcode_atts['short_desc']) ?></p>
													</div>
												<?php } 
												if (isset($shortcode_atts['fb_link']) || isset($shortcode_atts['tw_link']) || isset($shortcode_atts['g_link'])) { ?>
													<div class="empty-sm-20 empty-xs-20"></div>
													<div class="folow-style-2 header-folow align-center">
														<?php if (isset($shortcode_atts['fb_link'])) {?>
															<a href="<?php echo esc_html($shortcode_atts['fb_link']) ?>"><span class="fa fa-facebook"></span></a>
														<?php } 
														if (isset($shortcode_atts['tw_link'])) {?>
															<a href="<?php echo esc_html($shortcode_atts['tw_link']) ?>"><span class="fa fa-twitter"></span></a>
														<?php } 
														if (isset($shortcode_atts['g_link'])) {?>
															<a href="<?php echo esc_html($shortcode_atts['g_link']) ?>"><span class="fa fa-google-plus"></span></a>
														<?php } ?>
													</div>
												<?php } ?>
											</div>
										</div>
									</div>
								</div>
							<?php } elseif ($type_slider == 'type_3') { ?>
								<div class="swiper-slide">
									<div class="team-item style-3">
										<?php echo $image_html ?>
										<div class="text">
											<?php if (isset($shortcode_atts['name'])) { ?>
												<h6 class="h6 title"><?php echo esc_html($shortcode_atts['name']) ?></h6>
											<?php }
											if (isset($shortcode_atts['position'])) { ?>
												<div class="empty-sm-5 empty-xs-5"></div>
												<div class="sub-title sm col-9 tt"><?php echo esc_html($shortcode_atts['position']) ?></div>
											<?php } ?>
											<div class="hover-hide">
												<?php if (isset($shortcode_atts['short_desc'])) { ?>
												<div class="empty-sm-10 empty-xs-10"></div>
												<div class="simple-text">
													<p><?php echo esc_html($shortcode_atts['short_desc']) ?></p>
												</div>
												<?php } 
												if (isset($shortcode_atts['fb_link']) || isset($shortcode_atts['tw_link']) || isset($shortcode_atts['g_link'])) { ?>
													<div class="empty-sm-20 empty-xs-20"></div>
													<div class="folow-style-2 sub-type-1 header-folow align-center col-1">
														<?php if (isset($shortcode_atts['fb_link'])) {?>
															<a href="<?php echo esc_html($shortcode_atts['fb_link']) ?>"><span class="fa fa-facebook"></span></a>
														<?php } 
														if (isset($shortcode_atts['tw_link'])) {?>
															<a href="<?php echo esc_html($shortcode_atts['tw_link']) ?>"><span class="fa fa-twitter"></span></a>
														<?php } 
														if (isset($shortcode_atts['g_link'])) {?>
															<a href="<?php echo esc_html($shortcode_atts['g_link']) ?>"><span class="fa fa-google-plus"></span></a>
														<?php } ?>
													</div>
												<?php } ?>
											</div>
										</div>
									</div>
								</div>
							<?php } ?>
						<?php } ?>
					</div>
				<?php 
				if( $pagi == 'enable' ) { ?>
					<div class="empty-lg-90 empty-md-80 empty-sm-60 empty-xs-60"></div>
					<div class="pagination  <?php echo ( $pagi_type == 'square' ? 'type-col-3' : 'type-2 colo-type-2' ); ?>"></div>
				<?php }
				 if ( $slider_arrows == 'enable' ) { ?> 
					<div class="swiper-arrow-left slider-arrow-1"><i class="fa fa-angle-left"></i></div>
					<div class="swiper-arrow-right slider-arrow-1"><i class="fa fa-angle-right"></i></div>
				<?php } ?>
				</div>
			<?php if ($type_slider == 'type_3') { ?>
				</div>
			<?php } 
				$custom_css = '';
				if ($type_slider == 'type_1') {
	 				if($h_color){
						$custom_css.= '.'.$hov_class.':hover .hover-layer:before {background:'.$h_color.'; opacity: 0.7;}';
						$custom_css.= '.'.$hov_class.':hover .folow-style-1 a span:after {background:'.$h_color.';}';
					}
				} elseif ($type_slider == 'type_2') {
					if ($m_s_color) {
						$custom_css.= '.'.$hov_class.' .folow-style-2 a span {background:'.$m_s_color.';}';
					}
					if($h_color){
						$custom_css.= '.'.$hov_class.' .folow-style-2 a span:hover {background:'.$h_color.';}';
						if ($pagi_type == 'square') {
							$custom_css.= '.'.$hov_class.' .pagination.type-col-3 .swiper-pagination-bullet-active:before {border-color: '.$h_color.';}';
							$custom_css.= '.'.$hov_class.' .pagination.type-col-3 .swiper-pagination-bullet:hover:before {background: '.$h_color.'; border-color: '.$h_color.';}';
						} else { 
							$custom_css.= '.'.$hov_class.' .pagination.type-2.colo-type-2 .swiper-pagination-bullet-active:before {background: '.$h_color.';}';
							$custom_css.= '.'.$hov_class.' .pagination.type-2.colo-type-2 .swiper-pagination-bullet:hover:before {background: '.$h_color.'; border-color: '.$h_color.';}';
						}
					}
				} elseif ($type_slider == 'type_3') {
					if($h_color){
						$custom_css.= '.'.$hov_class.' .folow-style-2 a span:hover {background:'.$h_color.'; border-color:'.$h_color.'}';
					}
				}
				if( $custom_css ){ ?>
					<style type="text/css"><?php echo $custom_css; ?></style>
				<?php } 
			?>
		</div>
		<?php 
		return  ob_get_clean();
	}

}
/* Shortvode Item */

vc_map( array(
  'name'            => 'Team slider item',
  'base'            => 'nrg_premium_team_slider_item',
  'as_child' 		=> array('only' => 'nrg_premium_team_slider'),
  'content_element' => true,
  'show_settings_on_create' => true,
  'description'     => 'Team slide, descriprion, social',
  'params'          => array(
		array(
			'type'        => 'attach_image',
			'heading'     => __( "Image", "nrg_premium" ),
			'param_name'  => 'image',
			'admin_label' => true,
			'description' => 'Upload your image.'
		),
		array(
			'type'        => 'textfield',
			'heading'     =>  __( "Name", "nrg_premium" ),
			'param_name'  => 'name',
			'admin_label' => true,
			'value'       => '',
		),
		array(
			'type'        => 'textfield',
			'heading'     =>  __( "Position", "nrg_premium" ),
			'param_name'  => 'position',
			'admin_label' => true,
			'value'       => '',
		),
		array(
			'type' => 'textarea',
			'heading'     => __( 'Short Description', 'nrg_premium' ),
			'param_name'  => 'short_desc',
		),
		array(
			'type'        => 'textfield',
			'heading'     => 'Person link',
			'param_name'  => 'person_url',
			'admin_label' => true,
			'value'       => '',
		),
		array(
			'type'        => 'textfield',
			'heading'     =>  __( "Facebook link", "nrg_premium" ),
			'param_name'  => 'fb_link',
			'admin_label' => true,
			'value'       => '',
			'group'		  => __( 'Social', 'nrg_premium' ),
		),
		array(
			'type'        => 'textfield',
			'heading'     =>  __( "Twitter link", "nrg_premium" ),
			'param_name'  => 'tw_link',
			'admin_label' => true,
			'value'       => '',
			'group'		  => __( 'Social', 'nrg_premium' ),
		),
		array(
			'type'        => 'textfield',
			'heading'     =>  __( "Google+ link", "nrg_premium" ),
			'param_name'  => 'g_link',
			'admin_label' => true,
			'value'       => '',
			'group'		  => __( 'Social', 'nrg_premium' ),
		),
	) //end params
) );


class WPBakeryShortCode_nrg_premium_team_slider_item extends WPBakeryShortCode{
	protected function content( $atts, $content = null ) {

		global $_team_sliders_items;
		$_team_sliders_items[] = array( 'atts' => $atts, 'content' => $content, 'css_class' => '');
		return;
	}
}