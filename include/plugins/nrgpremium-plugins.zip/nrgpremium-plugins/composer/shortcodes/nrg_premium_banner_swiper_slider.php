<?php 
/*
** Baner Slider
** Version: 1.0.0 
*/

vc_map( array(
	'name'		=> __( 'Banner slider', 'nrg_premium' ),
	'base'		=> 'nrg_premium_slider',
	'as_parent'	=> array('only' => '
		nrg_premium_slider_item, 
		nrg_premium_slider_item_2,
		nrg_premium_slider_item_3,
		nrg_premium_slider_item_titles 
	'),
	'content_element'			=> true,
	'show_settings_on_create'	=> true,
	'category'					=> __( 'NRGPremium', 'nrg_premium' ),
	'description'				=> __( 'Image and Text', 'nrg_premium'),
	'js_view'					=> 'VcColumnView',
	'params'					=> array(
		array(
			'type'			=> 'dropdown',
			'heading'		=> __( 'Slider type', 'nrg_premium' ),
			'param_name'	=> 'type_sw',
			'value'			=> array(
				'Type 1'		=> 'type_1',
				'Type 2'		=> 'type_2',
			),
		),
		array(
			'type'			=> 'dropdown',
			'heading'		=> __( 'Arrow enable', 'nrg_premium' ),
			'param_name'	=> 'arrow_enable',
			'value'			=> array(
				'Enable'		=> 'enable',
				'Disable'		=> 'disable',
			),
			'dependency'	=> array( 'element' => 'type_sw', 'value' => array('type_1', 'type_2') ),
		),
		array(
			'type'			=> 'dropdown',
			'heading'		=> __( 'Arrow type', 'nrg_premium' ),
			'param_name'	=> 'arrow_type',
			'value'			=> array(
				'Type 1'		=> 'type_1',
				'Type 2'		=> 'type_2',
			),
			'dependency'	=> array( 'element' => 'arrow_enable', 'value' => 'enable' ),
		),
		array(
			'type'			=> 'dropdown',
			'heading'		=> __( 'Pagination enable', 'nrg_premium' ),
			'param_name'	=> 'pagination_enable',
			'value'			=> array(
				'Enable'		=> 'enable',
				'Disable'		=> 'disable',
			),
			'dependency'	=> array( 'element' => 'type_sw', 'value' => array('type_1', 'type_2') ),
		),
		array(
			'type'			=> 'dropdown',
			'heading'		=> __( 'Pagination type', 'nrg_premium' ),
			'param_name'	=> 'pag_type',
			'value'			=> array(
				'square'		=> 'square',
				'round'			=> 'round',
				'vertical'		=> 'vertical',
			),
			'dependency'	=> array( 'element' => 'pagination_enable', 'value' => 'enable' ),
		),
		array(
		    'type'			=> 'textfield',
		    'heading'		=> __( 'Autoplay (sec)', 'nrg_premium' ),
		    'description'	=> __( '0 - off autoplay', 'nrg_premium' ),
		    'param_name'	=> 'autoplay',
		    'value'			=> '0',
		    'group'			=> __( 'Animation', 'nrg_premium' )
		),
		array(
		    'type'			=> 'textfield',
		    'heading'		=> __( 'Speed (milliseconds)', 'nrg_premium' ),
		    'description'	=> __( 'Speed Animation. Default 800 milliseconds', 'nrg_premium' ),
		    'param_name'	=> 'speed',
		    'value'			=> '800',
		    'group'			=> __( 'Animation', 'nrg_premium' )
		),
		array(
			'type'			=> 'checkbox',
			'heading'		=> __( 'Off full height', 'nrg_premium' ),
			'param_name'	=> 'full',
			'value'			=> false,
		),
		array(
			'type'			=> 'textfield',
			'heading'		=> __( 'Extra class name', 'nrg_premium' ),
			'param_name'	=> 'el_class',
			'description'	=> __( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'nrg_premium' ),
			'value'			=> '',
		),
		array(
			'type'			=> 'css_editor',
			'heading'		=> __( 'CSS box', 'nrg_premium' ),
			'param_name'	=> 'css',
			'group'			=> __( 'Design options', 'nrg_premium' ),
		),
	) //end params
) );

class WPBakeryShortCode_nrg_premium_slider extends WPBakeryShortCodesContainer {

	protected function content( $atts, $content = null) {

		extract( shortcode_atts( array(
			'el_class'				=> '',
			'css'					=> '',
			'autoplay'				=> '0',
			'speed'					=> '800',
			'type_sw'				=> 'type_1',
			'arrow_type'			=> 'type_1',
			'arrow_enable'			=> 'enable',
			'pag_type'				=> 'square',
			'pagination_enable'		=> 'enable',
			'full'					=> false,

		), $atts ) );

		$background_left_image_html = '';
		if (!empty($background_left_image)) {
			$background_left_image_full = wp_get_attachment_image_url( $background_left_image, 'full' );
			$background_left_image_html = '<div class="bg bg-bg-chrome act" style="background-image:url('. esc_url( $background_left_image_full ).')"></div>';
		} 

		global $_slider_items;
		$_slider_items = array();

		$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, $this->settings['base'], $atts );

		// custum css
		$css_class .= vc_shortcode_custom_css_class( $css, ' ' );
		// custum class
		$css_class .= (!empty($el_class)) ? ' '.$el_class : '';
		
		// autoplay, loop and speed
		$autoplay = is_numeric($autoplay) ? $autoplay*1000 : 0;
		$speed = is_numeric($speed) ? $speed : '800';

		// output
		ob_start();
		do_shortcode( $content );
		?>
		<div class="<?php print esc_attr( $css_class ); ?>">
			<div class="<?php echo ($full == false ? 'main-top-slider' : '');?> no-offset arrow-closest mobile-pagination <?php echo ($type_sw == 'type_2' ? ' height-sm ' : '');?>">
				<div class="swiper-container full-h" data-mode="horizontal" data-autoplay="<?php print esc_attr( $autoplay ); ?>" data-effect="slide" data-slides-per-view="1" data-loop="0" data-speed="<?php print esc_attr($speed); ?>">
					<div class="swiper-wrapper">
						<?php foreach ($_slider_items as $key => $shortcode) :
							$shortcode_atts = $shortcode['atts'];
							$image_html = $st = '';
							if (!empty($shortcode_atts['image'])) {
								if ($shortcode_atts['type'] == 'standart_2') {
									$st = 'type-11';
								} elseif ($shortcode_atts['type'] == 'standart') {
									$st = 'type-8';
								}
								$image_full = wp_get_attachment_image_url( $shortcode_atts['image'], 'full' );
								$image_html = '<div class="bg layer-hold '.$st.'" style="background-image: url('. esc_url( $image_full ). ')"></div>';
							} ?>
							<?php if ($shortcode_atts['type'] == 'titles' || $shortcode_atts['type'] == 'standart_2' || $shortcode_atts['type'] == 'standart') { ?>
								<div class="swiper-slide">
									<?php print $image_html ?>
									<div class="vertical-align full">
										<div class="container<?php if ($shortcode_atts['type'] == 'titles' || $shortcode_atts['type'] == 'standart_2') {echo '-fluid';} ?>">
											<div class="row">
												<?php if ( (!empty($shortcode_atts['type'])) && $shortcode_atts['type'] == 'standart') { ?>
													<?php if ($shortcode_atts['sub_slide'] == 'subtype_1') { ?>
														<div class="col-md-10 col-md-offset-1">
													<?php } else { ?>
														<div class="col-lg-6 col-lg-offset-3 col-md-12 col-sm-12 col-xs-12">
													<?php } ?>
														<div class="<?php if (isset($shortcode_atts['txt_border']) == true) {print esc_html('style-caption-1'); } ?> type-2">
															<div class="empty-sm-80 empty-xs-60"></div>
															
															<?php if ($type_sw == 'type_1'){ ?>
																<?php if (isset($shortcode_atts['subtitle'])){ ?>
																	<span class="sub-title col-1"><?php print wp_kses_post($shortcode_atts['subtitle']); ?></span>
																<?php }
															} else {
																if (isset($shortcode_atts['subtitle'])){ ?>
																	<div class="simple-text md col-6">
																		<p><i><?php print esc_html($shortcode_atts['subtitle']); ?></i></p>
																	</div>	
																<?php } 
															}
															if (isset($shortcode_atts['title_icon'])){ ?>	
																<div class="title-img-wrap">
																	<img src="<?php echo esc_url(wp_get_attachment_image_url( $shortcode_atts['title_icon'], 'full' )); ?>" alt="">
																</div>
															<?php }
															if (isset($shortcode_atts['title'])){ 
																if ($type_sw == 'type_1') { ?> 
																	<div class="empty-sm-10 empty-xs-10"></div>
																	<h1 class="title <?php echo (isset($shortcode_atts['title_size']) && $shortcode_atts['title_size'] =='h2' ? 'h2 lg' : 'h1');?><?php ?> "><?php print esc_html($shortcode_atts['title']); ?></h1>
																<?php } else { ?>
																	<h2 class="h2 lg title"><?php print esc_html($shortcode_atts['title']); ?></h2>
																<?php } 
															}

															if (isset($shortcode_atts['short_desc'])){ ?>
																<div class="empty-sm-15 empty-xs-15"></div>
																<?php if ($type_sw == 'type_1') { ?>	
																	<div class="simple-text col-3 lg">
																		<p><?php print wp_kses_post($shortcode_atts['short_desc']); ?></p>
																	</div>
																<?php } else { ?>
																	<div class="simple-text md col-7">
																		<p><?php print wp_kses_post($shortcode_atts['short_desc']); ?></p>
																	</div>
																<?php }
															}
															if(isset($shortcode_atts['button_text']) && isset($shortcode_atts['button_link'])){ 
																	$btn_align_n = 'text-center';
																	$btn_type = $shortcode_atts['button_type'];
																	$button_title = $shortcode_atts['button_text'];
																	$button_url 	= $shortcode_atts['button_link']; 
																	$but_width		= $shortcode_atts['b_width'];
																	$main_color		= $shortcode_atts['m_color']; 
																?>

																<div class="empty-sm-35 empty-xs-30"></div>
																<div class="button-wrap">
																	<?php hm_get_template_part('composer/shortcodes/buttons/button-'.$btn_type, [ 'title' => $button_title, 'but_url' => $button_url, 'but_align' =>  $btn_align_n, 'main_color' => $main_color, 'but_width' => $but_width ]); ?>
																</div>
															<?php } ?>
															<div class="empty-sm-100 empty-xs-60"></div>
														</div>     
													</div>
												<?php } ?>
											
												<?php if ( (!empty($shortcode_atts['type'])) && $shortcode_atts['type'] == 'standart_2') { ?>
													<div class="custome-padd-100">
														<div class="col-md-6">
															<div class="empty-lg-50 empty-md-60 empty-sm-60 empty-xs-60"></div>
															<div class="caption type-2 text-left">
																<?php if ($shortcode_atts['title']) { ?>
																	<h1 class="h1 title"><?php echo esc_html($shortcode_atts['title']);?></h1>
																<?php } 
																if (isset($shortcode_atts['short_desc'])) { ?>
																	<div class="empty-sm-15 empty-xs-15"></div>
																	<div class="simple-text lg col-3">
																		<p><?php echo wp_kses_post($shortcode_atts['short_desc']);?></p>
																	</div>
																<?php }
																if(isset($shortcode_atts['button_text']) && isset($shortcode_atts['button_link'])){ 
																$btn_align_n	= 'text-left';
																$btn_type		= $shortcode_atts['button_type'];
																$button_title	= $shortcode_atts['button_text'];
																$button_url 	= $shortcode_atts['button_link']; 
																$but_width		= $shortcode_atts['b_width'];
																$main_color		= $shortcode_atts['m_color']; ?>
																	<div class="empty-sm-30 empty-xs-30"></div>
																	<div class="button-wrap">
																		<?php hm_get_template_part('composer/shortcodes/buttons/button-'.$btn_type, [ 'title' => $button_title, 'but_url' => $button_url, 'but_align' =>  $btn_align_n, 'main_color' => $main_color, 'but_width' => $but_width ]); ?>
																	</div>
																<?php } ?>
															</div>
														</div>
													</div>
												<?php } ?>

												<?php if ( (!empty($shortcode_atts['type'])) && $shortcode_atts['type'] == 'titles') { ?>
													<div class="custome-padd-100">
														<div class="col-md-7">
															<div class="empty-lg-50 empty-md-60 empty-sm-60 empty-xs-60"></div>
															<div class="caption type-2 text-left">
																<?php if (isset($shortcode_atts['title_1']) || isset($shortcode_atts['col_title_1'])) { ?>
																	<h2 class="h1 title lh-60"><b class="page-col-1 font-1"><?php echo esc_html($shortcode_atts['col_title_1']); ?></b><?php echo esc_html($shortcode_atts['title_1']); ?></h2>
																<?php }
																if (isset($shortcode_atts['title_2']) || isset($shortcode_atts['col_title_2'])) { ?>
																	<h2 class="h1 title lh-60"><b class="page-col-1 font-1"><?php echo esc_html($shortcode_atts['col_title_2']); ?></b><?php echo esc_html($shortcode_atts['title_2']); ?></h2>
																<?php }
																if (isset($shortcode_atts['title_3']) || isset($shortcode_atts['col_title_3'])) { ?>
																	<h2 class="h1 title lh-60"><b class="page-col-1 font-1"><?php echo esc_html($shortcode_atts['col_title_3']); ?></b><?php echo esc_html($shortcode_atts['title_3']); ?></h2>
																<?php } ?>
																<div class="empty-sm-20 empty-xs-20"></div>
																<?php if (isset($shortcode_atts['short_desc'])) { ?>
																	<div class="simple-text lg col-3 second-font">
																		<p><i><?php echo wp_kses_post($shortcode_atts['short_desc']); ?></i></p>
																	</div>
																<?php } ?>
																<?php if (isset($shortcode_atts['button_link']) && isset($shortcode_atts['button_text']) ) {
																	$btn_align_n = '';
																	if ($shortcode_atts['btn_align'] == 'align_left') {
																		$btn_align_n = 'text-left';
																	} else {
																		$btn_align_n = 'text-center';
																	}
																	$btn_type = $shortcode_atts['button_type'];
																	$button_title = $shortcode_atts['button_text'];
																	$button_url 	= $shortcode_atts['button_link']; 
																	$but_width		= $shortcode_atts['b_width'];
																	$main_color		= $shortcode_atts['m_color']; ?>

																	<div class="empty-sm-30 empty-xs-30"></div>
																	<div class="button-wrap">
																		<?php hm_get_template_part('composer/shortcodes/buttons/button-'.$btn_type, [ 'title' => $button_title, 'but_url' => $button_url, 'but_align' =>  $btn_align_n, 'main_color' => $main_color, 'but_width' => $but_width ]); ?>
																	</div>
																<?php } ?>
															</div>
														</div>
													</div>
				                                <?php } ?>
											</div>
										</div>
									</div>
								</div>
							<?php } elseif ($shortcode_atts['type'] == 'standart_3') { ?>
								<div class="swiper-slide test">
									<div class="empty-lg-140 empty-md-100 empty-sm-60 empty-xs-60"></div>
									<div class="bg" style="background-image: url(<?php echo esc_url(wp_get_attachment_image_url( $shortcode_atts['image'], 'full' )); ?>)"></div>
									<div class="container-fluid">
										<div class="row">
											<div class="col-md-5 col-md-offset-6 col-sm-8 col-sm-offset-2 col-xs-12">
												<div class="frame-block text-left sm-frame">
													<div class="empty-lg-90 empty-md-90 empty-sm-60 empty-xs-60"></div>
													<div class="custome-padd-80">
														<div class="caption text-center-xs">
															<?php if (isset($shortcode_atts['subtitle'])) { ?>
																<span class="sub-title tt"><?php echo esc_html($shortcode_atts['subtitle']); ?></span>
																<div class="empty-sm-5 empty-xs-5"></div>
															<?php } ?>
															<?php if (isset($shortcode_atts['title'])) { ?>
																<h2 class="h2 title"><?php echo esc_html($shortcode_atts['title']); ?></h2>
															<?php } ?>
															<div class="empty-sm-35 empty-xs-30"></div>
															<?php if (isset($shortcode_atts['short_desc'])) { ?>
																<div class="simple-text col-1">
																	<p><?php echo wp_kses_post($shortcode_atts['short_desc']); ?></p>
																</div>
															<?php } ?>
															<?php if (isset($shortcode_atts['button_link']) && isset($shortcode_atts['button_text']) ) {
																	$btn_align_n = 'text-left';
																	$btn_type = $shortcode_atts['button_type'];
																	$button_title = $shortcode_atts['button_text'];
																	$button_url 	= $shortcode_atts['button_link']; 
																	$but_width		= $shortcode_atts['b_width'];
																	$main_color		= $shortcode_atts['m_color']; ?>
																		
																	<div class="empty-sm-35 empty-xs-30"></div>
																	<?php hm_get_template_part('composer/shortcodes/buttons/button-'.$btn_type, [ 'title' => $button_title, 'but_url' => $button_url, 'but_align' =>  $btn_align_n, 'main_color' => $main_color, 'but_width' => $but_width ] ); ?>
																<?php } ?>
														</div>
													</div>
													<div class="empty-lg-90 empty-md-90 empty-sm-60 empty-xs-60"></div>
												</div>
											</div>
											<div class="col-md-1 col-sm-hidden"></div>
										</div>
									</div>
									<div class="empty-lg-140 empty-md-100 empty-sm-60 empty-xs-60"></div>
								</div>
							<?php } ?>
						<?php endforeach; ?>
					</div>
				
					<?php 
					$pagin_type = '';
					if ($pag_type == 'square'){
						$pagin_type = 'color-revers'; 
					} elseif ($pag_type == 'round') {
						$pagin_type = 'type-2';
					} elseif ($pag_type == 'vertical') {
						$pagin_type = 'vertical-right type-2 colo-type-3';
					} ?>
						<div class="pagination <?php echo ($pagination_enable == 'disable'? 'pagination-hidden' : '');?> <?php echo esc_html($pagin_type);?>"></div>
				</div>
				<?php if ($arrow_enable == 'enable') { ?>
					<div class="swiper-arrow-left slider-arrow-1 <?php if ($arrow_type == 'type_2' ){print ('type-2');} ?>"><i class="fa fa-angle-left"></i></div>
					<div class="swiper-arrow-right slider-arrow-1 <?php if ($arrow_type == 'type_2' ){print ('type-2');} ?>"><i class="fa fa-angle-right"></i></div>
				<?php } ?>
			</div>  
		</div>

		<?php 
		return  ob_get_clean();
	}

}
/* Shortvode Item */
// SLIDE TYPE 1
vc_map( array(
  'name'					=> 'Slider Item',
  'base'					=> 'nrg_premium_slider_item',
  'as_child'				=> array('only' => 'nrg_premium_slider'),
  'content_element'			=> true,
  'show_settings_on_create'	=> true,
  'description'				=> 'Slider item',
  'params'					=> array(
  		array(
			'type'			=> 'dropdown',
			'heading'		=> __( 'Subtype slide', 'nrg_premium' ),
			'param_name'	=> 'sub_slide',
			'value'			=> array(
				'Subtype 1'	=> 'subtype_1',
				'Subtype 2'	=> 'subtype_2',
			),
		),
		array(
			'type'			=> 'attach_image',
			'heading'		=> __( 'Image', 'nrg_premium' ),
			'param_name'	=> 'image',
			'admin_label'	=> true,
			'description'	=> 'Upload your image.'
		),
		array(
			'type'			=> 'attach_image',
			'heading'		=> __( 'Title icon', 'nrg_premium' ),
			'param_name'	=> 'title_icon',
			'admin_label'	=> true,
			'description'	=> 'Upload your image.'
		),
		array(
			'type'			=> 'textfield',
			'heading'		=> __( 'Title', 'nrg_premium' ),
			'param_name'	=> 'title',
			'admin_label'	=> true,
			'value'			=> '',
			'description'	=> __( 'Title slider item.', 'nrg_premium' ),
		),
		array(
			'type'			=> 'dropdown',
			'heading'		=> __( 'Title size', 'nrg_premium' ),
			'param_name'	=> 'title_size',
			'value'			=> array(
				'H1'	=> 'h1',
				'H2'	=> 'h2',
			),
		),
		array(
			'type'			=> 'textfield',
			'heading'		=> __( 'Subtitle', 'nrg_premium' ),
			'param_name'	=> 'subtitle',
			'admin_label'	=> true,
			'value'			=> '',
			'description'	=> __( 'Subtitle slider item.', 'nrg_premium' ),
		),
		array(
			'type'			=> 'textarea',
			'heading'		=> __( 'Short Description', 'nrg_premium' ),
			'param_name'	=> 'short_desc',
			'description'	=> __( 'Short description slider item.', 'nrg_premium' ),
		),
		array(
			'type'			=> 'checkbox',
			'heading'		=> __( 'Text Border', 'nrg_premium' ),
			'param_name'	=> 'txt_border',
			'value'			=> true,
		),
		array(
			'type'			=> 'dropdown',
			'heading'		=> __( 'Button type', 'nrg_premium' ),
			'param_name'	=> 'button_type',
			'value'			=> array(
				'Type 1'		=> 'type_1',
				'Type 2'		=> 'type_2',
				'Type 3'		=> 'type_3',
				'Type 4'		=> 'type_4',
				'Type 5'		=> 'type_5',
				'Type 6'		=> 'type_6',
			),
			'group'			=> __( 'Button', 'nrg_premium' ),
		),
		array(
			'type'			=> 'dropdown',
			'heading'		=> __( 'Button width', 'nrg_premium' ),
			'param_name'	=> 'b_width',
			'value'			=> array(
				'Standart'		=> 'standart',
				'Small'			=> 'small',
			),
			'dependency'  => array( 'element' => 'button_type', 'value' => array('type_1', 'type_3')),
			'group'			=> __( 'Button', 'nrg_premium' ),
		),
		array(
			'type'			=> 'colorpicker',
			'class'			=> '',
			'heading'		=> __( 'Main color', 'nrg_premium' ),
			'param_name'	=> 'm_color',
			'value'			=> '#84694e',
			'group'			=> __( 'Button', 'nrg_premium' ),
		),
		array(
			'type'			=> 'textfield',
			'heading'		=> __( 'Button text', 'nrg_premium' ),
			'param_name'	=> 'button_text',
			'admin_label'	=> true,
			'value'			=> '',
			'description'	=> __( 'Button text', 'nrg_premium' ),
			'group'			=> __( 'Button', 'nrg_premium' ),
		),
		array(
			'type'			=> 'vc_link',
			'heading'		=> __( 'Link', 'nrg_premium' ),
			'param_name'	=> 'button_link',
			'value'			=> '',
			'description'	=> __( 'Button link', 'nrg_premium' ),
			'group'			=> __( 'Button', 'nrg_premium' ),
		),
	) //end params
) );


class WPBakeryShortCode_nrg_premium_slider_item extends WPBakeryShortCode{
	protected function content( $atts, $content = null ){
		global $_slider_items;
		$atts['type'] = 'standart';
		$atts['sub_slide'] =  ( isset($atts['sub_slide']) ? $atts['sub_slide'] : 'subtype_1');
		$atts['title_size'] =  ( isset($atts['title_size']) ? $atts['title_size'] : 'h1');
		$atts['b_width'] = ( isset($atts['b_width']) ? $atts['b_width'] : '#standart' );
		$atts['m_color'] = ( isset($atts['m_color']) ? $atts['m_color'] : '#84694e' );
		$atts['btn_align'] = ( isset($atts['btn_align']) ? $atts['btn_align'] : 'align_center' );
		$atts['button_type'] = ( isset($atts['button_type']) ? $atts['button_type'] : 'type_1' );
		$_slider_items[] = array('atts' => $atts, 'content' => $content, 'css_class' => '');
		return;
	}
}

// SLIDE TYPE 2
vc_map( array(
  'name'					=> 'Slider Item type 2 ',
  'base'					=> 'nrg_premium_slider_item_2',
  'as_child'				=> array('only' => 'nrg_premium_slider'),
  'content_element'			=> true,
  'show_settings_on_create'	=> true,
  'description'				=> 'Slider item',
  'params'					=> array(
		array(
			'type'			=> 'attach_image',
			'heading'		=> __( 'Image', 'nrg_premium' ),
			'param_name'	=> 'image',
			'admin_label'	=> true,
			'description'	=> 'Upload your image.'
		),
		array(
			'type'			=> 'textfield',
			'heading'		=> __( 'Title', 'nrg_premium' ),
			'param_name'	=> 'title',
			'admin_label'	=> true,
			'value'			=> '',
			'description'	=> __( 'Title slider item.', 'nrg_premium' ),
		),
		array(
			'type'			=> 'textarea',
			'heading'		=> __( 'Short Description', 'nrg_premium' ),
			'param_name'	=> 'short_desc',
			'description'	=> __( 'Short description slider item.', 'nrg_premium' ),
		),
		array(
			'type'			=> 'dropdown',
			'heading'		=> __( 'Button type', 'nrg_premium' ),
			'param_name'	=> 'button_type',
			'value'			=> array(
				'Type 1'		=> 'type_1',
				'Type 2'		=> 'type_2',
				'Type 3'		=> 'type_3',
				'Type 4'		=> 'type_4',
				'Type 5'		=> 'type_5',
				'Type 6'		=> 'type_6',
			),
			'group'			=> __( 'Button', 'nrg_premium' ),
		),
		array(
			'type'			=> 'dropdown',
			'heading'		=> __( 'Button width', 'nrg_premium' ),
			'param_name'	=> 'b_width',
			'value'			=> array(
				'Standart'		=> 'standart',
				'Small'			=> 'small',
			),
			'dependency'  => array( 'element' => 'button_type', 'value' => array('type_1', 'type_3')),
			'group'			=> __( 'Button', 'nrg_premium' ),
		),
		array(
			'type'			=> 'colorpicker',
			'class'			=> '',
			'heading'		=> __( 'Main color', 'nrg_premium' ),
			'param_name'	=> 'm_color',
			'value'			=> '#84694e',
			'group'			=> __( 'Button', 'nrg_premium' ),
		),
		array(
			'type'			=> 'textfield',
			'heading'		=> __( 'Button text', 'nrg_premium' ),
			'param_name'	=> 'button_text',
			'admin_label'	=> true,
			'value'			=> '',
			'description'	=> __( 'Button text', 'nrg_premium' ),
			'group'			=> __( 'Button', 'nrg_premium' ),
		),
		array(
			'type'			=> 'vc_link',
			'heading'		=> __( 'Link', 'nrg_premium' ),
			'param_name'	=> 'button_link',
			'value'			=> '',
			'description'	=> __( 'Button link', 'nrg_premium' ),
			'group'			=> __( 'Button', 'nrg_premium' ),
		),
	) //end params
) );


class WPBakeryShortCode_nrg_premium_slider_item_2 extends WPBakeryShortCode{
	protected function content( $atts, $content = null ){
		global $_slider_items;
		$atts['type'] = 'standart_2';
		$atts['b_width'] = ( isset($atts['b_width']) ? $atts['b_width'] : '#standart' );
		$atts['m_color'] = ( isset($atts['m_color']) ? $atts['m_color'] : '#84694e' );
		$atts['btn_align'] = ( isset($atts['btn_align']) ? $atts['btn_align'] : 'align_center' );
		$atts['button_type'] = ( isset($atts['button_type']) ? $atts['button_type'] : 'type_1' );
		$_slider_items[] = array('atts' => $atts, 'content' => $content, 'css_class' => '');
		return;
	}
}

// SLIDE TYPE 3
vc_map( array(
  'name'					=> 'Slider Item type 3 ',
  'base'					=> 'nrg_premium_slider_item_3',
  'as_child'				=> array('only' => 'nrg_premium_slider'),
  'content_element'			=> true,
  'show_settings_on_create'	=> true,
  'description'				=> 'Slider item',
  'params'					=> array(
		array(
			'type'			=> 'attach_image',
			'heading'		=> __( 'Image', 'nrg_premium' ),
			'param_name'	=> 'image',
			'description'	=> 'Upload your image.'
		),
		array(
			'type'			=> 'textfield',
			'heading'		=> __( 'Title', 'nrg_premium' ),
			'param_name'	=> 'title',
			'admin_label'	=> true,
			'value'			=> '',
			'description'	=> __( 'Title slider item.', 'nrg_premium' ),
		),
		array(
			'type'			=> 'textfield',
			'heading'		=> __( 'Subtitle', 'nrg_premium' ),
			'param_name'	=> 'subtitle',
			'value'			=> '',
		),
		array(
			'type'			=> 'textarea',
			'heading'		=> __( 'Short Description', 'nrg_premium' ),
			'param_name'	=> 'short_desc',
			'description'	=> __( 'Short description slider item.', 'nrg_premium' ),
		),
		array(
			'type'			=> 'dropdown',
			'heading'		=> __( 'Button type', 'nrg_premium' ),
			'param_name'	=> 'button_type',
			'value'			=> array(
				'Type 1'		=> 'type_1',
				'Type 2'		=> 'type_2',
				'Type 3'		=> 'type_3',
				'Type 4'		=> 'type_4',
				'Type 5'		=> 'type_5',
				'Type 6'		=> 'type_6',
			),
			'group'			=> __( 'Button', 'nrg_premium' ),
		),
		array(
			'type'			=> 'dropdown',
			'heading'		=> __( 'Button width', 'nrg_premium' ),
			'param_name'	=> 'b_width',
			'value'			=> array(
				'Standart'		=> 'standart',
				'Small'			=> 'small',
			),
			'dependency'  => array( 'element' => 'button_type', 'value' => array('type_1', 'type_3')),
			'group'			=> __( 'Button', 'nrg_premium' ),
		),
		array(
			'type'			=> 'colorpicker',
			'class'			=> '',
			'heading'		=> __( 'Main color', 'nrg_premium' ),
			'param_name'	=> 'm_color',
			'value'			=> '#84694e',
			'group'			=> __( 'Button', 'nrg_premium' ),
		),
		array(
			'type'			=> 'textfield',
			'heading'		=> __( 'Button text', 'nrg_premium' ),
			'param_name'	=> 'button_text',
			'admin_label'	=> true,
			'value'			=> '',
			'description'	=> __( 'Button text', 'nrg_premium' ),
			'group'			=> __( 'Button', 'nrg_premium' ),
		),
		array(
			'type'			=> 'vc_link',
			'heading'		=> __( 'Link', 'nrg_premium' ),
			'param_name'	=> 'button_link',
			'value'			=> '',
			'description'	=> __( 'Button link', 'nrg_premium' ),
			'group'			=> __( 'Button', 'nrg_premium' ),
		),
	) //end params
) );


class WPBakeryShortCode_nrg_premium_slider_item_3 extends WPBakeryShortCode{
	protected function content( $atts, $content = null ){
		global $_slider_items;
		$atts['type'] = 'standart_3';
		$atts['b_width'] = ( isset($atts['b_width']) ? $atts['b_width'] : '#standart' );
		$atts['m_color'] = ( isset($atts['m_color']) ? $atts['m_color'] : '#84694e' );
		$atts['btn_align'] = ( isset($atts['btn_align']) ? $atts['btn_align'] : 'align_center' );
		$atts['button_type'] = ( isset($atts['button_type']) ? $atts['button_type'] : 'type_1' );
		$_slider_items[] = array('atts' => $atts, 'content' => $content, 'css_class' => '');
		return;
	}
}


// SLIDE TYPE 4
vc_map( array(
  'name'					=> 'Slider few titles',
  'base'					=> 'nrg_premium_slider_item_titles',
  'as_child'				=> array('only' => 'nrg_premium_slider'),
  'content_element'			=> true,
  'show_settings_on_create'	=> true,
  'description'				=> 'Slider item',
  'params'					=> array(
		array(
			'type'			=> 'attach_image',
			'heading'		=> __( 'Image', 'nrg_premium' ),
			'param_name'	=> 'image',
			'admin_label'	=> true,
			'description'	=> 'Upload your image.'
		),
		array(
			'type'			=> 'textfield',
			'heading'		=> __( 'Colored part title 1', 'nrg_premium' ),
			'param_name'	=> 'col_title_1',
			'admin_label'	=> true,
			'value'			=> '',
		),
		array(
			'type'			=> 'textfield',
			'heading'		=> __( 'Title 1', 'nrg_premium' ),
			'param_name'	=> 'title_1',
			'admin_label'	=> true,
			'value'			=> '',
		),
		array(
			'type'			=> 'textfield',
			'heading'		=> __( 'Colored part title 2', 'nrg_premium' ),
			'param_name'	=> 'col_title_2',
			'admin_label'	=> true,
			'value'			=> '',
		),
		array(
			'type'			=> 'textfield',
			'heading'		=> __( 'Title 2', 'nrg_premium' ),
			'param_name'	=> 'title_2',
			'admin_label'	=> true,
			'value'			=> '',
		),
		array(
			'type'			=> 'textfield',
			'heading'		=> __( 'Colored part title 3', 'nrg_premium' ),
			'param_name'	=> 'col_title_3',
			'admin_label'	=> true,
			'value'			=> '',
		),
		array(
			'type'			=> 'textfield',
			'heading'		=> __( 'Title 3', 'nrg_premium' ),
			'param_name'	=> 'title_3',
			'admin_label'	=> true,
			'value'			=> '',
		),
		array(
			'type'			=> 'textarea',
			'heading'		=> __( 'Short Description', 'nrg_premium' ),
			'param_name'	=> 'short_desc',
			'description'	=> __( 'Short description slider item.', 'nrg_premium' ),
		),
		array(
			'type'			=> 'dropdown',
			'heading'		=> __( 'Button type', 'nrg_premium' ),
			'param_name'	=> 'button_type',
			'value'			=> array(
				'Type 1'		=> 'type_1',
				'Type 2'		=> 'type_2',
				'Type 3'		=> 'type_3',
				'Type 4'		=> 'type_4',
				'Type 5'		=> 'type_5',
				'Type 6'		=> 'type_6',
			),
			'group'			=> __( 'Button', 'nrg_premium' ),
		),
		array(
			'type'			=> 'dropdown',
			'heading'		=> __( 'Button width', 'nrg_premium' ),
			'param_name'	=> 'b_width',
			'value'			=> array(
				'Standart'		=> 'standart',
				'Small'			=> 'small',
			),
			'dependency'  => array( 'element' => 'button_type', 'value' => array('type_1', 'type_3')),
			'group'			=> __( 'Button', 'nrg_premium' ),
		),
		array(
			'type'			=> 'colorpicker',
			'class'			=> '',
			'heading'		=> __( 'Main color', 'nrg_premium' ),
			'param_name'	=> 'm_color',
			'value'			=> '#84694e',
			'group'			=> __( 'Button', 'nrg_premium' ),
		),
		array(
			'type'			=> 'textfield',
			'heading'		=> __( 'Button text', 'nrg_premium' ),
			'param_name'	=> 'button_text',
			'admin_label'	=> true,
			'value'			=> '',
			'description'	=> __( 'Button text', 'nrg_premium' ),
			'group'			=> __( 'Button', 'nrg_premium' ),
		),
		array(
			'type'			=> 'vc_link',
			'heading'		=> __( 'Link', 'nrg_premium' ),
			'param_name'	=> 'button_link',
			'value'			=> '',
			'description'	=> __( 'Button link', 'nrg_premium' ),
			'group'			=> __( 'Button', 'nrg_premium' ),
		),
		array(
			'type'			=> 'dropdown',
			'heading'		=> __( 'Button Align', 'nrg_premium' ),
			'param_name'	=> 'btn_align',
			'value'			 => array(
				'Align left'	=> 'align_left',
				'Align center'	=> 'align_center',
			),
			'group'			=> __( 'Button', 'nrg_premium' ),
		),
  ) //end params
) );


class WPBakeryShortCode_nrg_premium_slider_item_titles extends WPBakeryShortCode{
	protected function content( $atts, $content = null ){
		global $_slider_items;
		$atts['type'] = 'titles';
		$atts['b_width'] = ( isset($atts['b_width']) ? $atts['b_width'] : '#standart' );
		$atts['m_color'] = ( isset($atts['m_color']) ? $atts['m_color'] : '#84694e' );
		$atts['btn_align'] = ( isset($atts['btn_align']) ? $atts['btn_align'] : 'align_left' );
		$atts['button_type'] = ( isset($atts['button_type']) ? $atts['button_type'] : 'type_1' );
		$_slider_items[] = array('atts' => $atts, 'content' => $content, 'css_class' => '');
		return;
	}
}