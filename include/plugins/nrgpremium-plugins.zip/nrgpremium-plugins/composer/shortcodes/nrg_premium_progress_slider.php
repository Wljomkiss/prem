<?php 
/*
** Progress Slider
** Version: 1.0.0 
*/


vc_map( array(
	'name'                    => __( 'Progress slider', 'nrg_premium' ),
	'base'                    => 'nrg_premium_progress',
	'as_parent'               => array('only' => 'nrg_premium_progress_item'),
	'content_element'         => true,
	'show_settings_on_create' => false,
	'category' 				  => __( 'NRGPremium', 'nrg_premium' ),
	'description'             => __( 'Banner with slider', 'nrg_premium'),
	'js_view'                 => 'VcColumnView',
	'params'          => array(
		array(
			'type'        => 'attach_image',
			'heading'     => __( 'Background image', "nrg_premium" ),
			'param_name'  => 'image',
			'admin_label' => true,
			'description' => 'Upload your image.'
		),
		array(
			'type'        => 'textfield',
			'heading'     => __( "Title", "nrg_premium" ),
			'param_name'  => 'title',
			'admin_label' => true,
			'value'       => '',
		),
		array(
			'type'        => 'textfield',
			'heading'     => __( "Subtitle", "nrg_premium" ),
			'param_name'  => 'subtitle',
			'admin_label' => true,
			'value'       => '',
		),
		array(
			'type' => 'textfield',
			'heading' => __( 'Extra class name', 'nrg_premium' ),
			'param_name' => 'el_class',
			'description' => __( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'nrg_premium' ),
			'value' => '',
		),
		array(
			'type' => 'css_editor',
			'heading' => __( 'CSS box', 'nrg_premium' ),
			'param_name' => 'css',
			'group' => __( 'Design options', 'nrg_premium' ),
		),
	) //end params
) );

class WPBakeryShortCode_nrg_premium_progress extends WPBakeryShortCodesContainer {

	protected function content( $atts, $content = null) {

		extract( shortcode_atts( array(
			'el_class'     => '',
			'css'          => '',
			'image'        => '',
			'title'        => '',
			'subtitle'     => '',
			'content_desc' => '',
		), $atts ) );

		$image_html = '';
		if ($image) {
			$image_full = wp_get_attachment_image_url( $image, 'full' );
			$image_html = '<div class="bg layer-hold fix type-2" style="background-image: url('. esc_url( $image_full ).')"></div>';
		}


		global $_progress_items;
		$_progress_items = array();

		$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, $this->settings['base'], $atts );

		// custum css
		$css_class .= vc_shortcode_custom_css_class( $css, ' ' );

		// custum class
		$css_class .= (!empty($el_class)) ? ' '.$el_class : '';
		
		// output
		ob_start();
		do_shortcode( $content );
		?>
		<div class="section <?php print esc_attr( $css_class ); ?>">
			<?php print $image_html; ?>
			<div class="empty-lg-140 empty-md-100 empty-sm-60 empty-xs-60"></div>
			<?php if ($title || $subtitle) { ?>
				<div class="container">
					<div class="caption text-center type-2">
						<div class="title-separator-2"><span></span></div>
							<?php if ($title) { ?>
								<div class="empty-sm-25 empty-xs-25"></div>
								<h2 class="h2 title"><?php print esc_html($title) ?></h2>
							<?php } 
							if ($subtitle) { ?>
							<div class="empty-sm-15 empty-xs-15"></div>
							<div class="sub-title col-2"><?php print esc_html($subtitle) ?></div>
							<?php } ?>
						<div class="empty-md-80 empty-sm-60 empty-xs-40"></div>
					</div>
				</div>
			<?php } ?>
			<?php if ($_progress_items)  { ?>
				<div class="swiper-container progress-slider" data-mode="horizontal" data-autoplay="0" data-effect="slide" data-slides-per-view="auto" data-loop="0" data-speed="800" data-center="1">
					<div class="swiper-wrapper">
						<?php foreach ($_progress_items as $key => $shortcode):
							$shortcode_atts = $shortcode['atts'];
							$pr_item_image_html = '';
							if ( !empty($shortcode_atts['pr_item_image'])) {
								$pr_item_image_full = wp_get_attachment_image_url( $shortcode_atts['pr_item_image'], 'full' );
								$pr_item_image_html = '<img src="'. esc_url( $pr_item_image_full ).'" alt="pr_item_image"><div class="empty-sm-40 empty-xs-40"></div>';
							} ?>
							<div class="swiper-slide">
								<div class="progress-item">
									<?php print $pr_item_image_html; ?>
									<?php if ($shortcode_atts['progress_date']) { ?>
										<div class="progress-date"><?php print esc_html($shortcode_atts['progress_date']);?></div>
										<div class="empty-sm-20 empty-xs-20"></div>
									<?php } ?>
									<?php if ($shortcode_atts['title_item'] || $shortcode_atts['content_desc']) { ?>
										<div class="text type-2">
											<?php if ($shortcode_atts['title_item'] ) { ?>
												<h5 class="h5 title"><?php print esc_html($shortcode_atts['title_item']); ?> </h5>
											<?php } ?>
											<?php if ($shortcode_atts['content_desc'] ) { ?>
												<div class="empty-sm-15 empty-xs-15"></div>
												<div class="sub-title col-2"><?php print wp_kses_post($shortcode_atts['content_desc']); ?></div>
											<?php } ?>
										</div>
									<?php } ?>
								</div>
							</div>
						<?php endforeach; ?>
					</div>
					<div class="pagination pagination-hide"></div>
				</div>
			<?php } ?>
			<div class="empty-lg-140 empty-md-100 empty-sm-60 empty-xs-60"></div>
		</div>




		<?php 
		return  ob_get_clean();
	}

}
/* Shortvode Item */

vc_map( array(
  'name'            => 'Progress item',
  'base'            => 'nrg_premium_progress_item',
  'as_child' 		=> array('only' => 'nrg_premium_progress'),
  'content_element' => true,
  'show_settings_on_create' => true,
  'description'     => 'Progress item',
  'params'          => array(
		array(
			'type'        => 'attach_image',
			'heading'     => __( 'Progress item image', 'nrg_premium' ),
			'param_name'  => 'pr_item_image',
			'admin_label' => true,
			'description' => 'Upload your image.'
		),
		array(
			'type'        => 'textfield',
			'heading'     => __( 'Title', 'nrg_premium' ),
			'param_name'  => 'title_item',
			'admin_label' => true,
			'value'       => '',
		),
		array(
			'type'        => 'textfield',
			'heading'     => __( "Progress date", "nrg_premium" ),
			'param_name'  => 'progress_date',
			'admin_label' => true,
			'value'       => '',
		),
		array(
			'type'        => 'textarea',
			'heading'     => __( 'Short Description', 'nrg_premium' ),
			'param_name'  => 'content_desc',
		),
	) //end params
) );


class WPBakeryShortCode_nrg_premium_progress_item extends WPBakeryShortCode{
	protected function content( $atts, $content = null ) {

		global $_progress_items;
		$_progress_items[] = array( 'atts' => $atts, 'content' => $content, 'css_class' => '');
		return;
	}
}