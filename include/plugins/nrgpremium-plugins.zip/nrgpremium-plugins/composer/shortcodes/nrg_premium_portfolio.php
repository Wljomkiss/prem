<?php 
/*
 * Portfolio Shortcode
 * Author: Upqode
 * Author URI: http://upqode.com
 * Version: 1.0.0 
 */

vc_map( 
	array(
		'name'            => __( 'Portfolio', 'nrg_premium' ),
		'base'            => 'nrg_premium_portfolio',
		'description'     => __( 'Portfolio', 'nrg_premium' ),
		'category' 				  => __( 'NRGPremium', 'nrg_premium' ),
		'params'          => array(
			array(
				'type'        => 'dropdown',
				'heading'     => __( 'Portfolio type', 'nrg_premium' ),
				'param_name'  => 'port_type',
				'admin_label' => true, 
				'value'       => array(
					'Column'	=> 'column',
					'Masonry'	=> 'masonry',
					'Creative'	=> 'creative',
				)
			),
			array(
				'type'        => 'checkbox',
				'heading'     => __( 'Filter', 'nrg_premium' ),
				'param_name'  => 'filters',
				'value'       => true,
			),
			array(
				'type'			=> 'colorpicker',
				'heading'		=> __( 'Active filter color', 'nrg_premium' ),
				'param_name'	=> 'filter_color',
				'value'			=> '#8d9d71',
			),
			array(
				'type' 		  => 'dropdown',
				'admin_label' => true, 
				'heading' 	  => 'Order by',
				'param_name'  => 'orderby',
				'value' 	  => array(
					'ID' 		    => 'ID',
					'Author' 	    => 'author',
					'Post Title'    => 'title',
					'Date' 		    => 'date',
					'Last Modified' => 'modified',
					'Random Order'  => 'rand',
					'Menu Order'    => 'menu_order'
				)
			),
			array(
				'type' 		  => 'dropdown',
				'heading' 	  => 'Order',
				'param_name'  => 'order',
				'value' 	  => array(
					'Ascending'  => 'ASC',
					'Descending' => 'DESC'
				)
			),
			array(
				'type'        => 'vc_efa_chosen',
				'heading'     => __( 'Custom Categories', 'nrg_premium' ),
				'param_name'  => 'cats',
				'placeholder' => 'Choose category (optional)',
				'value'       => nrg_premium_param_values( 'terms', array(
					'taxonomies' => 'portfolio_categories',
				) ),
				'std'         => '',
				'description' => __( 'You can choose spesific categories for portfolio, default is all categories', 'nrg_premium' ),
			),
			array(
				'type'        => 'textfield',
				'heading'     => __( 'Count items', 'nrg_premium' ),
				'param_name'  => 'limit',
				'value'       => '',
				'description' => __( 'Default 20 items.', 'nrg_premium' )
			),
			array(
				'type' 		  => 'textfield',
				'heading' 	  => __( 'Extra class name', 'nrg_premium' ),
				'param_name'  => 'el_class',
				'description' => __( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'nrg_premium' ),
				'value' 	  => ''
			),
			/* CSS editor */
			array(
				'type' 		  => 'css_editor',
				'heading' 	  => __( 'CSS box', 'nrg_premium' ),
				'param_name'  => 'css',
				'group' 	  => __( 'Design options', 'nrg_premium' )
			),
		)
	)
);

class WPBakeryShortCode_nrg_premium_portfolio extends WPBakeryShortCode{
	protected function content( $atts, $content = null ) {
		extract( shortcode_atts( array(
			'orderby'		=> 'ID',
			'order'			=> 'ASC',
			'cats'			=> '',
			'limit'			=> '',
			'filters'		=> true,
			'el_class'		=> '',
			'css'			=> '',
			'port_type'		=> 'column',
			'item_size'		=> '',
			'filter_color'	=> '',

		), $atts ) );

		$class  = ( ! empty( $el_class ) ) ? $el_class : '';
		$class .= vc_shortcode_custom_css_class( $css, ' ' );

		$limit 	  = ( empty( $limit ) || ! is_numeric( $limit ) ) ? 20 : $limit;

		$category = '';
		$sc_cats = $cats;
		$cats 	 = explode( ',', $cats );
		
		//WP_Query
		if ( $sc_cats ){
			$category = array(
				'taxonomy' => 'portfolio_categories',
				'field'    => 'id',
				'terms'    => $cats
			);
		}

		$args = array(
			'post_type'      => 'portfolio',
			'posts_per_page' => $limit,
			'order'			 => $order,
			'orderby'		 => $orderby,
			'tax_query'      => array(
				$category
			)
		);
		$post = new WP_Query( $args );
		// Filter
		$port = uniqid('port-');
?>
		<div class="<?php echo $port ?>">
			<div class="container-fluid">
				<?php if ($port_type == 'column' || $port_type == 'masonry') { ?>
					<?php if( $filters == true ) { ?>
						<div class="filter-list-mobile">
							<div class="select-txt">
								<p><?php print esc_html__('All', 'nrg_premium' ) ?></p>
								<i class="fa fa-angle-down"></i>
							</div>      
							<ul class="filter-list style-1">
								<li data-filter="*" class="active"><span><?php print esc_html__('All', 'nrg_premium' ) ?></span></li>
								<?php $categories = get_terms( 'portfolio_categories', '' );
									if( $categories ){
										foreach ( $categories as $cat ) {
											if ( $sc_cats ) {
												if( in_array($cat->term_id, $cats ) ) { ?>
													<li data-filter=".<?php print $cat->slug ?>"><span><?php print $cat->name ?></span></li>
												<?php }
											} else { ?>
												<li data-filter=".<?php print $cat->slug ?>"><span><?php print $cat->name ?></span></li>
											<?php } 
										}
									}
								?>
							</ul>
						</div>    
					<?php } 
					if ( $post->have_posts() ) { ?>
						<div class="empty-md-90 empty-sm-60 empty-xs-40"></div>
						<div class="izotope-container gutter-15">
							<div class="grid-sizer"></div>
							<?php 
								$i = 1;
								while ( $post->have_posts() ) : $post->the_post();
									$portfolio_category = '';
									$categories = get_the_terms( get_the_ID() , 'portfolio_categories' );
									if( $categories ) {
										foreach ( $categories as $categorsy ) {
											$portfolio_category.= $categorsy->slug . ' ';
										}
									}
									if( has_post_thumbnail() ){ ?>
										<div class="item <?php echo ( $port_type == 'masonry' ? ( $i % 3 == 0 || $i % 4 == 0 ? 'col-50 md-col-100' : 'col-25 md-col-50' ) : 'col-25 md-col-33 sm-col-50' ).' xs-col-100 '.$portfolio_category; ?>">
											<div class="work-item">
												<img src="<?php the_post_thumbnail_url()?>" alt="<?php the_title(); ?>" class="work-img" >
												<a href="<?php the_permalink();?>" class="project-desc">
													<div class="vertical-align full">
														<h4 class="title h4"><?php the_title(); ?></h4> 
														<div class="sub-title"><?php the_excerpt(); ?></div>
													</div> 
												</a> 
											</div>
										</div>
									<?php }
									if( $i == 4 )
										$i = 1;
									else 
										$i++;
								endwhile;
								wp_reset_postdata();
							?>
						</div>
					<?php } ?>
				<?php } elseif ($port_type == 'creative') { ?>
					<?php if( $filters == true ) { ?>
						<div class="filter-list-mobile">
							<div class="select-txt"><p><?php print esc_html__('All', 'nrg_premium' ) ?></p><i class="fa fa-angle-down"></i></div>      
							<ul class="filter-list style-2">
								<li data-filter="*" class="active"><span class="h7"><?php print esc_html__('All', 'nrg_premium' ) ?></span></li>
								<?php $categories = get_terms( 'portfolio_categories', '' );
									if( $categories ){
										foreach ( $categories as $cat ) {
											if ( $sc_cats ) {
												if( in_array($cat->term_id, $cats ) ) { ?>
													<li data-filter=".<?php print $cat->slug ?>"><span class="h7"><?php print $cat->name ?></span></li>
												<?php }
											} else { ?>
												<li data-filter=".<?php print $cat->slug ?>"><span class="h7"><?php print $cat->name ?></span></li>
											<?php } 
										}
									}
								?>
							</ul>
						</div>
						<div class="empty-lg-60 empty-md-60 empty-sm-30 empty-xs-40"></div>
					<?php } 
					if ( $post->have_posts() ) { ?>
						<div class="wrap-project">
							<div class="view-link">
								<a href="#" class="list-type-project"><i class="fa fa-bars"></i></a>
								<a href="#" class="grid-type-project"><i class="fa fa-th"></i></a>
							</div>
							<div class="row">
								<div class="izotope-container gutter-15 padd-xs-off">
									<div class="grid-sizer"></div>
									<?php 
										while ( $post->have_posts() ) : $post->the_post();
										$portfolio_category = '';
										$categories = get_the_terms( get_the_ID() , 'portfolio_categories' );
										if( $categories ) {
											foreach ( $categories as $categorsy ) {
												$portfolio_category.= $categorsy->slug . ' ';
											}
										}
											if( has_post_thumbnail() ){ ?>
											<div class="item col-25 md-col-33 sm-col-50 xs-col-100 <?php echo $portfolio_category; ?>">
												<div class="simple-item-1 hover-block work-type-item">
													<a href="<?php the_permalink();?>" class="image hover-layer bg-col-6">
														<img src="<?php the_post_thumbnail_url();?>" alt="" class="resp-img">
													</a>
													<div class="text">
														<h3 class="h7 title"><a href="<?php the_title();?>" class="link-hover-4"><?php the_title();?></a></h3>
														<div class="sub-title sm tt ls col-9"><?php the_excerpt();?></div>
													</div>
												</div>
											</div>
										<?php }
									endwhile; 
									wp_reset_postdata(); ?>
								</div>
							</div>
						</div>
					<?php } ?>
				<?php } ?>
			</div>
		</div>

		<div class="test"></div>
			<?php
				$custom_css = '';
				if($filter_color){
					$custom_css.= '.'.$port.' .filter-list li:before{background:'.$filter_color.'!important;}';
					$custom_css.= '.'.$port.' .project-desc {background:'.$filter_color.'!important;}';
				}
				if( $custom_css ){ ?>
					<style type="text/css"><?php echo $custom_css; ?></style>
				<?php } ?>
		<?php
	}
}