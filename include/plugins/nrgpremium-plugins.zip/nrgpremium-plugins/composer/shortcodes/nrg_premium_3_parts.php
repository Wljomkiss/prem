<?php 
/*
** 3 parts with Slider
** Version: 1.0.0 
*/

vc_map( array(
	'name'                    => __( 'Three parts slider', 'nrg_premium' ),
	'base'                    => 'nrg_premium_3_parts_slider',
	'as_parent'               => array('only' => 'nrg_premium_3_parts_slider_item'),
	'content_element'         => true,
	'show_settings_on_create' => true,
	'category' 				  => __( 'NRGPremium', 'nrg_premium' ),
	'description'             => __( 'Image and Text', 'nrg_premium'),
	'js_view'                 => 'VcColumnView',
	'params'          => array(
		array(
			'type'        => 'attach_image',
			'heading'     => __( 'Background Image left', 'nrg_premium' ),
			'param_name'  => 'bg_l_image',
			'admin_label' => true,
			'description' => 'Upload your image.',
			'group'		  => 'Left part',
		),
		array(
			'type'        => 'textfield',
			'heading'     => 'Button title',
			'param_name'  => 'button_title',
			'admin_label' => true,
			'value'       => '',
			'group'		  => 'Left part',
		),
		array(
			'type'        => 'vc_link',
			'heading'     => 'Button url',
			'param_name'  => 'button_url',
			'admin_label' => true,
			'value'       => '',
			'group'		  => 'Left part'
		),

		array(
			'type'        => 'textfield',
			'heading'     => __( 'Subtitle', 'nrg_premium' ),
			'param_name'  => 'subtitle',
			'admin_label' => true,
			'value'       => '',
			'description' => __( 'Subtitle slider item.', 'nrg_premium' ),
			'group'		  => 'Center part',
		),
		array(
			'type'        => 'textfield',
			'heading'     => __( 'Title', 'nrg_premium' ),
			'param_name'  => 'title',
			'admin_label' => true,
			'value'       => '',
			'group'		  => 'Center part',
		),
		array(
			'type'        => 'attach_image',
			'heading'     => __( 'Title image', 'nrg_premium' ),
			'param_name'  => 'title_image',
			'admin_label' => true,
			'description' => 'Upload your image.',
			'group'		  => 'Center part',
		),
		array(
			'type' => 'textarea',
			'heading'	  => __( 'Short Description', 'nrg_premium' ),
			'param_name'  => 'short_desc',
			'description' => __( 'Short description slider item.', 'nrg_premium' ),
			'group'		  => 'Center part',
		),
		array(
			'type'        => 'attach_image',
			'heading'     => __( 'Background Image right', 'nrg_premium' ),
			'param_name'  => 'bg_r_image',
			'admin_label' => true,
			'description' => 'Upload your image.',
			'group'		  => 'Right part',
		),
		array(
			'type' => 'textfield',
			'heading' => __( 'Extra class name', 'nrg_premium' ),
			'param_name' => 'el_class',
			'description' => __( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'nrg_premium' ),
			'value' => '',
		),
		array(
			'type' => 'css_editor',
			'heading' => __( 'CSS box', 'nrg_premium' ),
			'param_name' => 'css',
			'group' => __( 'Design options', 'nrg_premium' ),
		),
	) //end params
) );

class WPBakeryShortCode_nrg_premium_3_parts_slider extends WPBakeryShortCodesContainer {

	protected function content( $atts, $content = null) {

		extract( shortcode_atts( array(
			'el_class'		=> '',
			'css'			=> '',
			'bg_l_image'	=> '',
			'button_title'	=> '',
			'button_url'	=> '',
			'bg_r_image'	=> '',
			'subtitle'		=> '',
			'title'			=> '',
			'short_desc'	=> '',
			'title_image'		=> '',

		), $atts ) );

		global $_3_parts_slider_items;
		$_3_parts_slider_items = array();

		$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, $this->settings['base'], $atts );

		// custum css
		$css_class .= vc_shortcode_custom_css_class( $css, ' ' );

		// custum class
		$css_class .= (!empty($el_class)) ? ' '.$el_class : '';
		
		// output
		ob_start();
		do_shortcode( $content );
		?>
		<div class="<?php print esc_attr($css_class); ?>">
			<div class="row">
				<div class="col-md-4 col-sm-12 col-xs-12">
					<div class="item-h-600 custome-padd-100 flex-align">
						<?php if ($bg_l_image) { ?>
							<div class="bg" style="background-image: url(<?php echo wp_get_attachment_image_url( $bg_l_image, 'full' );?>)"></div>
						<?php } 
						$button_link = vc_build_link($button_url); 
						if ($button_title && (isset($button_link))) {?>
							<div class="button-wrap"> 
								<a href="<?php echo esc_url($button_link['url']); ?>" class="main-link link-style-1 type-5"><span><?php echo esc_html($button_title); ?></span></a>
							</div>
						<?php } ?>
					</div> 
				</div>
				<div class="col-md-4 col-sm-12 col-xs-12">
					<div class="item-h-600 custome-padd-100 flex-align">
						<div class="caption">
							<?php if ($subtitle) { ?>
								<span class="sub-title"><?php echo esc_html($subtitle); ?></span>
								<div class="empty-sm-5 empty-xs-5"></div>
							<?php } 
							if ($title) { ?>
							<h2 class="h2 title"><?php echo esc_html($title); ?></h2>
							<?php }
							if (isset($title_image)) { ?>
								<div class="empty-sm-10 empty-xs-10"></div>
								<img src="<?php echo wp_get_attachment_image_url( $title_image, 'full' );?>" alt="">
							<?php }
							if ($short_desc) { ?>
								<div class="empty-sm-40 empty-xs-30"></div>
								<div class="simple-text col-4">
									<p><?php echo wp_kses_post($short_desc); ?></p>
								</div>
							<?php } ?>
						</div>  
					</div> 
				</div>
				<div class="col-md-4 col-sm-12 col-xs-12">
					<div class="item-h-600 custome-padd-100 flex-align">
						<div class="bg layer-hold type-5" style="background-image: url(<?php echo wp_get_attachment_image_url( $bg_r_image, 'full' );?>)"></div>
						<div class="swiper-container item-h-600-align" data-mode="horizontal" data-autoplay="0" data-effect="slide" data-slides-per-view="1" data-loop="0" data-speed="800">
							<div class="swiper-wrapper">
							<?php foreach ($_3_parts_slider_items as $key => $shortcode) { 
								$shortcode_atts = $shortcode['atts']; ?>
								<div class="swiper-slide">
									<div class="tesimonials-item">
										<?php if (isset($shortcode_atts['image'])); { ?>
											<img src="<?php echo wp_get_attachment_image_url( $shortcode_atts['image'], 'full' );?>" alt="">
											<div class="empty-sm-25 empty-xs-25"></div>
										<?php } 
										if (isset($shortcode_atts['short_desc'])) { ?>
											<div class="simple-text col-4">
												<p><?php echo wp_kses_post($shortcode_atts['short_desc']); ?></p>
											</div>
										<?php } 
										if (isset($shortcode_atts['name'])) { ?>
											<div class="empty-sm-25 empty-xs-25"></div>
											<h4 class="h4"><?php echo esc_html($shortcode_atts['name']);?></h4>
										<?php }
										if (isset($shortcode_atts['position'])) { ?>
											<div class="empty-sm-5 empty-xs-5"></div>
											<span class="sub-desc"><?php echo esc_html($shortcode_atts['position']); ?></span>
										<?php } ?>
									</div> 
								</div>
							<?php } ?>
							</div>
							<div class="pagination color-black type-col-2"></div>
						</div>  
					</div>
				</div>
			</div>
		</div>
		<?php 
		return  ob_get_clean();
	}

}
/* Shortvode Item */

vc_map( array(
  'name'            => '3 part slider Item',
  'base'            => 'nrg_premium_3_parts_slider_item',
  'as_child' 		=> array('only' => 'nrg_premium_3_parts_slider'),
  'content_element' => true,
  'show_settings_on_create' => true,
  'params'          => array(
		array(
			'type'        => 'attach_image',
			'heading'     => __( 'Image', 'nrg_premium' ),
			'param_name'  => 'image',
			'admin_label' => true,
			'description' => 'Upload your image.'
		),
		array(
			'type'        => 'textfield',
			'heading'     => __( 'Name', 'nrg_premium' ),
			'param_name'  => 'name',
			'admin_label' => true,
			'value'       => '',
			'description' => __( 'Title slider item.', 'nrg_premium' ),
		),
		array(
			'type'        => 'textfield',
			'heading'     => __( 'Position', 'nrg_premium' ),
			'param_name'  => 'position',
			'admin_label' => true,
			'value'       => '',
			'description' => __( 'Subtitle slider item.', 'nrg_premium' ),
		),
		array(
			'type' => 'textarea',
			'heading'	  => __( 'Short Description', 'nrg_premium' ),
			'param_name'  => 'short_desc',
			'description' => __( 'Short description slider item.', 'nrg_premium' ),
		),
  ) //end params
) );


class WPBakeryShortCode_nrg_premium_3_parts_slider_item extends WPBakeryShortCode{
	protected function content( $atts, $content = null ){
		global $_3_parts_slider_items;
		$_3_parts_slider_items[] = array('atts' => $atts, 'content' => $content, 'css_class' => '');
		return;
	}
}