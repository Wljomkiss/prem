<?php 
/*
** About
** Author: NRGTHEMES
** Author URI: http://nrgthemes.com
** Version: 1.0.0 
*/

vc_map( array(
	'name'						=> __( 'About', 'nrg_premium' ),
	'base'						=> 'nrg_premium_about',
	'category'					=> __( 'NRGPremium', 'nrg_premium' ),
	'content_element'			=> true,
	'show_settings_on_create'	=> true,
	'description'				=> __( 'About', 'nrg_premium' ),
	'params'					=> array(
		array(
			'type'        => 'attach_image',
			'heading'     => __( 'Background Image', "nrg_premium" ),
			'param_name'  => 'image_bg',
			'admin_label' => true,
			'description' => 'Upload your image.'
		),
		array(
			'type'			=> 'textfield',
			'heading'		=> 'Title',
			'param_name'	=> 'title',
			'admin_label'	=> true,
			'value'			=> '',
		),
		array(
			'type'			=> 'textfield',
			'heading'		=> 'Subtitle',
			'param_name'	=> 'subtitle',
			'admin_label'	=> true,
			'value'			=> '',
		),
		array(
			'type'			=> 'textarea',
			'heading'		=> 'Short description',
			'param_name'	=> 'short_desc',
			'admin_label'	=> true,
			'value'			=> '',
		),
		array(
			'type'    => 'param_group',
			'js_view'   => 'VcColumnView',
			'heading'   => __( 'Service icon', 'nrg_premium' ),
			'description' => __( 'Service iconі', 'nrg_premium' ),
			'param_name'  => 'ser_icons',
			'params'  => array(
				array(
					'type'        => 'attach_image',
					'heading'     => __( 'Image', "nrg_premium" ),
					'param_name'  => 'image',
					'description' => 'Upload your image.'
				),
				array(
					'type'        => 'textfield',
					'heading'     => 'Title',
					'param_name'  => 'title',
					'value'       => '',
				),
				array(
					'type'        => 'textarea',
					'heading'     => 'Description',
					'param_name'  => 'desc',
					'value'       => '',
				),
			),
		),
		array(
			'type'        => 'attach_image',
			'heading'     => __( 'Image', "nrg_premium" ),
			'param_name'  => 'image',
			'admin_label' => true,
			'description' => 'Upload your image.'
		),
		array(
			'type' => 'textfield',
			'heading' => __( 'Extra class name', 'nrg_premium' ),
			'param_name' => 'el_class',
			'description' => __( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'nrg_premium' ),
			'value' => '',
		),
		array(
			'type' => 'css_editor',
			'heading' => __( 'CSS box', 'nrg_premium' ),
			'param_name' => 'css',
			'group' => __( 'Design options', 'nrg_premium' ),
		),
	) //end params
) );

class WPBakeryShortCode_nrg_premium_about extends WPBakeryShortCode {
	protected function content( $atts, $content = null) {

		extract( shortcode_atts( array(
			'el_class'      => '',
			'css'           => '',
			'title'			=> '',
			'subtitle'		=> '',
			'short_desc'	=> '',
			'ser_icon'		=> '',
			'image_bg'		=> '',
			'image'			=> '',
			'ser_icons'		=> '',

 		), $atts ) );

		$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, $this->settings['base'], $atts );
		
		// custum css
		$css_class .= vc_shortcode_custom_css_class( $css, ' ' );

		// custum class
		$css_class .= (!empty($el_class)) ? ' '.$el_class : '';

		$values = vc_param_group_parse_atts( $atts['ser_icons']);
		
		$image_html = '';
		if ($image_bg) {
			$image_full = wp_get_attachment_image_url( $image_bg, 'full' );
			$image_html = '<div class="bg layer-opacity-1" style="background-image: url('.esc_url( $image_full ).')"></div>';
		}

 		// output
		ob_start();
		do_shortcode( $content );
		?>
		<!--About-->
		<div class="<?php echo esc_attr( $css_class ); ?>">	
			<div class="empty-lg-40 empty-md-0 empty-sm-0 empty-xs-0"></div> 
			<div class="empty-lg-200 empty-md-100 empty-sm-60 empty-xs-60"></div> 
			<?php echo $image_html; ?>
			<div class="container z-index-block">
				<div class="row">
					<div class="col-md-7">
						<div class="frame-block text-left sm-frame">
							<div class="empty-lg-90 empty-md-90 empty-sm-60 empty-xs-60"></div>
							<div class="custome-padd-80">
								<div class="caption text-center-xs">
									<?php if ($subtitle) { ?>
										<span class="sub-title tt"><?php echo esc_html($subtitle); ?></span>
										<div class="empty-sm-5 empty-xs-5"></div>
									<?php }
									if ($title) { ?>
										<h2 class="h2 title"><?php echo esc_html($title); ?></h2>
									<?php } ?>
										<div class="empty-sm-25 empty-xs-20"></div>
										<div class="title-separator-3"></div>
									<?php if ($short_desc) { ?>
										<div class="empty-sm-25 empty-xs-20"></div>
										<div class="simple-text md col-1">
											<p><?php echo wp_kses_post($short_desc); ?></p>
										</div>
									<?php } 
									foreach ($values as $value) { 
										if (isset($value['desc']) || isset($value['title'])) { ?>
											<div class="empty-md-50 empty-sm-40 empty-xs-40"></div>
											<div class="service-icon-box text-center-xs">
												<?php if (isset($value['image'])) { ?>
													<div class="image">
														<img src="<?php echo esc_url(wp_get_attachment_image_url( $value['image'], 'full' )); ?>" alt="">
													</div>
												<?php } ?>
												<div class="caption">
													<?php if ($value['title']) { ?>
														<h6 class="h6 title no-padd"><?php echo esc_html($value['title']); ?></h6>
													<?php } 
													if ($value['desc']) { ?>
														<div class="simple-text col-1">
															<p><?php echo wp_kses_post( $value['desc']); ?></p>
														</div>
													<?php } ?>
												</div>
											</div>
										<?php }
									} ?>
								</div>        	
							</div>
							<div class="empty-lg-90 empty-md-90 empty-sm-60 empty-xs-60"></div>
						</div>
					</div>
				</div>
			</div>
			<div class="img-bottom hide-mobile">
				<img src="<?php echo esc_url(wp_get_attachment_image_url( $image, 'full' )); ?>" alt="">
			</div>   
			<div class="empty-lg-130 empty-md-100 empty-sm-60 empty-xs-60"></div>   
		</div>
		<?php 
		return  ob_get_clean();
	}

}
