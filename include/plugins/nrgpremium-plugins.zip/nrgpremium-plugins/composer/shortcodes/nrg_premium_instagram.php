<?php 
/*
** instagram
** Author: NRGTHEMES
** Author URI: http://nrgthemes.com
** Version: 1.0.0 
*/

vc_map( array(
	'name'                    => __( 'Instagram', 'nrg_premium' ),
	'base'                    => 'nrg_premium_instagram',
	'content_element'         => true,
	'show_settings_on_create' => true,
	'description' 		      => __( 'Photos', 'nrg_premium' ),
	'category' 				  => __( 'NRGPremium', 'nrg_premium' ),
	'params'          => array(
		array(
			'type'			=> 'dropdown',
			'heading'		=> __( 'Instagram type', 'nrg_premium' ),
			'param_name'	=> 'insta_type',
			'value'			=> array(
				'Type 1'		=> 'type_1',
				'Type 2'		=> 'type_2',
			),
		),
		array(
			'type'        => 'textfield',
			'heading'     =>  __( "Subtitle", "nrg_premium" ),
			'param_name'  => 'subtitle',
			'admin_label' => true,
			'value'       => '',
		),
		array(
			'type'        => 'textfield',
			'heading'     =>  __( "Title", "nrg_premium" ),
			'param_name'  => 'title',
			'admin_label' => true,
			'value'       => '',
		),
		array(
			'type'        => 'attach_image',
			'heading'     => __( "Image", "nrg_premium" ),
			'param_name'  => 'image',
			'admin_label' => true,
			'description' => 'Upload your image.'
		),
	    array(
	  		'type' => 'textarea',
	  		'heading' => __( 'Short Description', 'nrg_premium' ),
	  		'param_name' => 'short_desc',
  	    ),
		array(
			'type'        => 'textfield',
			'heading'     =>  __( "Instagram user name:", "nrg_premium" ),
			'param_name'  => 'user_name',
			'admin_label' => true,
			'value'       => '',
			'group'		  => 'Instagram detail'
		),
		array(
			'type'        => 'textfield',
			'heading'     =>  __( "Link to Instagram user profile:", "nrg_premium" ),
			'param_name'  => 'profile_link',
			'admin_label' => true,
			'value'       => '',
			'group'		  => 'Instagram detail'
		),
		array(
			'type'        => 'textfield',
			'heading'     =>  __( "Instagram user ID:", "nrg_premium" ),
			'param_name'  => 'instagram_userid',
			'admin_label' => true,
			'value'       => '',
			'group'		  => 'Instagram detail'
		),
		array(
			'type'        => 'textfield',
			'heading'     =>  __( "Instagram access token:", "nrg_premium" ),
			'param_name'  => 'instagram_access_token',
			'admin_label' => true,
			'value'       => '',
			'group'		  => 'Instagram detail'
		),
		array(
			'type'        => 'textfield',
			'heading'     =>  __( "Instagram image limit:", "nrg_premium" ),
			'param_name'  => 'img_limit',
			'admin_label' => true,
			'value'       => '',
			'group'		  => 'Instagram detail'
		),
		array(
			'type' => 'textfield',
			'heading' => __( 'Extra class name', 'nrg_premium' ),
			'param_name' => 'el_class',
			'description' => __( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'nrg_premium' ),
			'value' => '',
		),
		array(
			'type' => 'css_editor',
			'heading' => __( 'CSS box', 'nrg_premium' ),
			'param_name' => 'css',
			'group' => __( 'Design options', 'nrg_premium' ),
		),
	) //end params
) );

class WPBakeryShortCode_nrg_premium_instagram extends WPBakeryShortCode {
	protected function content( $atts, $content = null) {

		extract( shortcode_atts( array(
			'el_class'					=> '',
			'css'						=> '',
			'subtitle'					=> '',
			'title'						=> '',
			'short_desc'				=> '',
			'insta_name'				=> '',
			'user_name'					=> '',
			'profile_link'				=> '',
			'instagram_userid'			=> '',
			'instagram_access_token'	=> '',
			'image'						=> '',
			'img_limit'					=> '15',
			'insta_type'				=> 'type_1'

 		), $atts ) );

		$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, $this->settings['base'], $atts );
		
		// custum css
		$css_class .= vc_shortcode_custom_css_class( $css, ' ' );

		// custum class
		$css_class .= (!empty($el_class)) ? ' '.$el_class : '';

		$inst_id = uniqid();
		$image_html = '';
			if (!empty($image)) {
			$image_full = wp_get_attachment_image_url( $image, 'full' );
			$image_html = '<div class="empty-sm-25 empty-xs-25"></div><img src="'.esc_url( $image_full ).'" alt="">';
		}
 		// output
		ob_start();
		do_shortcode( $content );
		?>
		<!--Instagram -->
		<?php if (isset($instagram_userid) && isset($img_limit) && isset($instagram_access_token)) { ?>
			<div class="<?php echo esc_attr( $css_class ); ?>">
				<?php if ($insta_type == 'type_1') { ?>	
					<div class="insta-shortcode">
						<div class="vertical-wrap">
							<div class="col-33 col-md-100 align-item">
								<div class="empty-lg-0 empty-md-100 empty-sm-60 empty-xs-60"></div>
								<div class="custome-padd-100"> 
									<div class="caption text-center type-2">
										<?php if ($subtitle) { ?>
											<span class="sub-title"><?php echo esc_html($subtitle); ?></span>
											<div class="empty-sm-5 empty-xs-5"></div>
										<?php }	?>
										<?php if ($title) { ?>
											<h2 class="h2 title"><?php echo esc_html($title); ?></h2>
										<?php }	?>
										<?php echo $image_html; ?>
										<?php if ($short_desc) { ?>
											<div class="empty-sm-25 empty-xs-25"></div>
											<div class="simple-text col-2">
												<p><?php echo wp_kses_post($short_desc);?></p>
											</div>
										<?php } ?>
										<?php if ($insta_name) { ?>
											<div class="empty-sm-50 empty-xs-30"></div>
											<div class="additional-link">
												<p><?php echo esc_html__('join us on instagram:', 'nrg_premium'); ?></p> 
												<div class="empty-sm-10 empty-xs-10"></div>
												<a href="<?php echo esc_html($profile_link); ?>"><?php echo esc_html($insta_name); ?></a> 
											</div>
										<?php } ?>
									</div>
								</div>
								<div class="empty-lg-0 empty-md-100 empty-sm-60 empty-xs-60"></div>      
							</div>
							<div class="col-60 col-md-100 align-item some-wrap" id="<?php echo $inst_id;?>">
			    				
							</div>
			    			<div class="empty-lg-0 empty-md-100 empty-sm-60 empty-xs-60"></div>
						</div>
					</div>
					<script type="text/javascript">
						jQuery(document).ready(function($) {
							//Instagram
							try{Typekit.load();}catch(e){}
							var feed = new Instafeed({
								get: 'user',
								userId: '<?php echo $instagram_userid; ?>',
								'limit': '<?php echo $img_limit; ?>',
								accessToken: '<?php echo $instagram_access_token; ?>',
								template: '<div class="col-20 hover-block gallery-block"><div class="bg layer-hold type-7" style="background-image: url({{image}})"></div><a href="{{link}}" class="hover-layer-2 type-sm"><div class="vertical-align full"><div class="caption type-2 text-center"><h4 class="h8 title"><?php echo esc_html__('detail', 'nrg_premium');?></h4></div></div></a></div>',
								target: '<?php echo $inst_id;?>',
								resolution: 'standard_resolution',
								after: function() {}
							});
							feed.run();
						});
					</script>
				<?php } elseif ($insta_type == 'type_2') { ?>
					<div class="instagram-photo wh-25" id="<?php echo $inst_id;?>">
					</div>
					<script type="text/javascript">
						jQuery(document).ready(function($) {
							//Instagram
							try{Typekit.load();}catch(e){}
							var feed = new Instafeed({
								get: 'user',
								userId: '<?php echo $instagram_userid; ?>',
								'limit': '<?php echo $img_limit; ?>',
								accessToken: '<?php echo $instagram_access_token; ?>',
								template: '<a href="{{link}}"><img src="{{image}}" alt=""></a>',
								target: '<?php echo $inst_id;?>',
								resolution: 'standard_resolution',
								after: function() {}
							});
							feed.run();
						});
					</script>
				<?php } ?>
			</div>
		<?php }
		return  ob_get_clean();
	}

}