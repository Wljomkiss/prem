<?php 
/*
** Video
** Author: NRGTHEMES
** Author URI: http://nrgthemes.com
** Version: 1.0.0 
*/

vc_map( array(
	'name'                    => __( 'Video', 'nrg_premium' ),
	'base'                    => 'nrg_premium_video',
	'category' 				  => __( 'NRGPremium', 'nrg_premium' ),
	'content_element'         => true,
	'show_settings_on_create' => true,
	'description' 		      => __( 'Video youtube', 'nrg_premium' ),
	'params'          => array(
		array(
			'type'        => 'dropdown',
			'heading'     => __( 'Video type', 'nrg_premium' ),
			'param_name'  => 'video_type',
			'value'       => array(
				'Type 1'   => 'type_1',
				'Type 2'   => 'type_2',
				'Type 3'   => 'type_3',
			),
		),
		array(
			'type'			=> 'colorpicker',
			'class'			=> '',
			'heading'		=> __( 'Play button color', 'nrg_premium' ),
			'param_name'	=> 'play_col',
			'value'			=> '',
			'dependency'	=> array( 'element' => 'video_type', 'value' => 'type_2'),
		),
		array(
			'type'        => 'dropdown',
			'heading'     => __( 'Video 2 subtype', 'nrg_premium' ),
			'param_name'  => 'video_subtype',
			'value'       => array(
				'Subtype 1'   => 'subtype_1',
				'Subtype 2'   => 'subtype_2',
			),
			'dependency'	=> array( 'element' => 'video_type', 'value' => 'type_2'),
		),
		array(
			'type'        => 'textfield',
			'heading'     =>  __( "Title", "nrg_premium" ),
			'param_name'  => 'title',
			'admin_label' => true,
			'value'       => '',
			'dependency'  => array( 'element' => 'video_type', 'value' => array('type_2', 'type_3') ),
		),
		array(
			'type'        => 'textfield',
			'heading'     =>  __( "Subtitle", "nrg_premium" ),
			'param_name'  => 'subtitle',
			'admin_label' => true,
			'value'       => '',
			'dependency'  => array( 'element' => 'video_subtype', 'value' => 'subtype_2' ),
		),
		array(
			'type'        => 'vc_link',
			'heading'     => 'Title link',
			'param_name'  => 'title_link',
			'value'       => '',
			'dependency'  => array( 'element' => 'video_type', 'value' => array('type_3','type_2')),
		),
		array(
			'type'			=> 'textarea',
			'heading'		=> __( 'Short Description', 'nrg_premium' ),
			'param_name'	=> 'short_desc',
			'dependency'	=> array( 'element' => 'video_type', 'value' => array('type_2', 'type_3') ),
		),
		array(
			'type'        => 'attach_image',
			'heading'     => __( "Icon", "nrg_premium" ),
			'param_name'  => 'icon',
			'admin_label' => true,
			'description' => 'Upload your image.',
			'dependency'  => array( 'element' => 'video_subtype', 'value' => 'subtype_1' ),
		),
		array(
			'type'        => 'textfield',
			'heading'     => __( "Youtube link", "nrg_premium" ),
			'param_name'  => 'video_link',
			'admin_label' => true,
			'value'       => '',
		),
		array(
			'type'        => 'attach_image',
			'heading'     => __( "Image", "nrg_premium" ),
			'param_name'  => 'image',
			'admin_label' => true,
			'description' => 'Upload your image.'
		),
		array(
			'type' => 'textfield',
			'heading' => __( 'Extra class name', 'nrg_premium' ),
			'param_name' => 'el_class',
			'description' => __( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'nrg_premium' ),
			'value' => '',
		),
		array(
			'type' => 'css_editor',
			'heading' => __( 'CSS box', 'nrg_premium' ),
			'param_name' => 'css',
			'group' => __( 'Design options', 'nrg_premium' ),
		),
	) //end params
) );

class WPBakeryShortCode_nrg_premium_video extends WPBakeryShortCode {
	protected function content( $atts, $content = null) {

		extract( shortcode_atts( array(
			'el_class'			=> '',
			'css'				=> '',
			'video_link'		=> '',
			'image'				=> '',
			'video_type'		=> 'type_1',
			'title'				=> '',
			'short_desc'		=> '',
			'icon'				=> '',
			'title_link'		=> '',
			'video_subtype'		=> 'subtype_1',
			'subtitle'			=> '',
			'play_col'			=> '',

 		), $atts ) );

		$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, $this->settings['base'], $atts );
		
		// custum css
		$css_class .= vc_shortcode_custom_css_class( $css, ' ' );

		// custum class
		$css_class .= (!empty($el_class)) ? ' '.$el_class : '';

		if ($video_type == 'type_3' || $video_type == 'type_2') {
			if (isset($title_link)) {
				$main_link = vc_build_link($title_link);
			}
		}
		
 		// output
		ob_start();
		do_shortcode( $content );
		?>
		<!--VIDEO SHORTCODE-->
		<?php if ($video_type == 'type_1' && $video_link) { ?>
			<div class="video-open block-height-800 <?php echo esc_attr( $css_class ); ?>">
				<div class="bg" style="background-image: url(<?php echo esc_url(wp_get_attachment_image_url( $image, 'full' )); ?>)"></div>
				<div class="play-button" data-video="<?php echo esc_html($video_link);?>">
					<i class="fa fa-play"></i>
				</div>
				<div class="video-item">
					<div class="video-wrapper">
						<div class="video-iframe"></div>
						<div class="close close-video"><span>+</span></div>
					</div>
				</div>
			</div>
		<?php } elseif ($video_type == 'type_2' && $video_link ) { ?>
			<?php $but_col = uniqid('play'); ?>
			<div class="video-open block-height-650 <?php print esc_attr( $css_class ); ?> <?php echo $but_col ?>">
				<div class="bg layer-hold type-4" style="background-image: url(<?php echo esc_url(wp_get_attachment_image_url( $image, 'full' ));?>)"></div>
				<?php if ($title || $short_desc) { ?>
					<div class="vertical-align full">
						<div class="container<?php echo ($video_subtype == 'subtype_1'? '-fluid' : ''); ?>">
							<div class="row">
								<div class="col-md-6 col-md-offset-3">
									<div class="caption text-center type-2">
										<?php if (!empty($icon) && $video_subtype == 'subtype_1') { ?>
											<img src="<?php echo wp_get_attachment_image_url( $icon, 'full' ); ?>" alt="">
											<div class="empty-sm-30 empty-xs-30"></div>
										<?php } 
										if ($subtitle && $video_subtype == 'subtype_2') { ?>
											<div class="sub-title tt ls col-1"><?php echo esc_html($subtitle);?></div>
											<div class="empty-sm-5 empty-xs-5"></div> 
										<?php }
										if ($title) { ?>
											<h2 class="h2 title">
												<?php if ($video_subtype == 'subtype_2') { ?>
													<a href="<?php echo (isset($main_link) ? esc_html($main_link['url']) : '#');?>">
												<?php } ?>
													<?php print esc_html($title); ?>
												<?php if ($video_subtype == 'subtype_2') { ?>
													</a>
												<?php } ?>
											</h2>
										<?php } 
										if ($short_desc) { ?>
										<div class="empty-sm-15 empty-xs-15"></div>
										<div class="simple-text md col-3">
											<p><?php print wp_kses_post($short_desc); ?></p>
										</div>
										<?php } ?>
										<div class="empty-sm-25 empty-xs-25"></div>
										
										<div class="play-button rel" data-video="<?php echo esc_html($video_link);?>">
											<i class="fa fa-play"></i>
										</div>
										<?php $custom_css = '';
										if( isset($play_col) && $play_col ){
											$custom_css.= '.'.$but_col.' .play-button {border-color:'.$play_col.';}';
											$custom_css.= '.'.$but_col.' .play-button:before {background:'.$play_col.';}';
											if  ($video_subtype == 'subtype_1') { 
												$custom_css.= '.'.$but_col.' .type-2 .title:hover a {color:'.$play_col.';}';
											}

										}
										if( $custom_css ){ ?>
											<style type="text/css"><?php echo $custom_css; ?></style>
										<?php } ?>
									</div>
								</div>
							</div>
						</div>
					</div>
				<?php } ?>
				<div class="video-item">
					<div class="video-wrapper">
						<div class="video-iframe"></div>
						<div class="close close-video"><span>+</span></div>
					</div>
				</div>
			</div>
		<?php } elseif ($video_type == 'type_3' && $video_link ) { ?>
			<div class="video-open video-type-1 flex-align <?php print esc_attr( $css_class ); ?>">
				<div class="bg layer-hold type-4" style="background-image: url(<?php echo esc_url(wp_get_attachment_image_url( $image, 'full' )); ?>)"></div>
				<div class="caption type-2 text-center">
					<?php if ($title) { ?>
						<h4 class="title h4 sm tt">
							<a href="<?php echo esc_html($main_link['url']);?>" class="link-hover-2 play-trigger"><?php echo esc_html($title); ?></a>
						</h4>
					<?php } 
					if ($short_desc) { ?>
						<div class="empty-sm-15 empty-xs-15"></div>
						<div class="simple-text col-3">
							<p><?php print wp_kses_post($short_desc); ?></p>
						</div>
					<?php } ?>
					<div class="empty-sm-20 empty-xs-20"></div>
					<div class="play-button rel play-type-2" data-video="https://www.youtube.com/embed/REqZelREwM8?autoplay=1">
						<i class="fa fa-play"></i>
					</div>
				</div>
				<div class="video-item">
					<div class="video-wrapper">
						<div class="video-iframe"></div>
						<div class="close close-video"><span>+</span></div>
					</div>
				</div>
			</div>
		<?php }
		return  ob_get_clean();
	}
}

       