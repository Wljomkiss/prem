<?php 
/*
** Google map
** Author: NRGTHEMES
** Author URI: http://nrgthemes.com
** Version: 1.0.0 
*/

vc_map( array(
	'name'                    => __( 'Map', 'nrg_premium' ),
	'base'                    => 'nrg_premium_map',
	'content_element'         => true,
	'show_settings_on_create' => true,
	'description' 		      => __( 'Google map', 'nrg_premium' ),
	'category' 				  => __( 'NRGPremium', 'nrg_premium' ),
	'params'          => array(
		array(
			'type'			=> 'dropdown',
			'heading'		=> __( 'Map height', 'nrg_premium' ),
			'param_name'	=> 'map_h',
			'value'			=> array(
				'Classic'		=> 'classic',
				'Classic 2' 	=> 'classic_2',
				'Full height'	=> 'full',
				'Small'			=> 'small',
			),
		),
		array(
			'type'			=> 'dropdown',
			'heading'		=> __( 'Style', 'nrg_premium' ),
			'param_name'	=> 'style',
			'value'			=> array(
				'Style 1'		=> '1',
				'Style 2' 		=> '2',
				'Style 3' 		=> '3',
			),
		),
		array(
			'type'        => 'attach_image',
			'heading'     => __( "Marker", "nrg_premium" ),
			'param_name'  => 'marker',
			'admin_label' => true,
			'description' => 'Upload your image.'
		),
		array(
			'type'        => 'textfield',
			'heading'     => 'Latitude',
			'param_name'  => 'lat',
			'admin_label' => true,
			'value'       => '',
		),
		array(
			'type'        => 'textfield',
			'heading'     => 'Longitude',
			'param_name'  => 'lng',
			'admin_label' => true,
			'value'       => '',
		),
		array(
			'type'        => 'textfield',
			'heading'     => 'Zoom',
			'param_name'  => 'zoom',
			'admin_label' => true,
			'value'       => '',
		),
		array(
			'type'        => 'textfield',
			'heading'     => 'Name',
			'param_name'  => 'name',
			'admin_label' => true,
			'value'       => '',
		),
		array(
			'type' => 'textfield',
			'heading' => __( 'Extra class name', 'nrg_premium' ),
			'param_name' => 'el_class',
			'description' => __( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'nrg_premium' ),
			'value' => '',
		),
		array(
			'type' => 'css_editor',
			'heading' => __( 'CSS box', 'nrg_premium' ),
			'param_name' => 'css',
			'group' => __( 'Design options', 'nrg_premium' ),
		),
	) //end params
) );

class WPBakeryShortCode_nrg_premium_map extends WPBakeryShortCode {
	protected function content( $atts, $content = null) {

		extract( shortcode_atts( array(
			'el_class'		=> '',
			'css'			=> '',
			'name'			=> '',
			'lng'			=> '-73.61862734722138',
			'lat'			=> '40.70623536613208',
			'zoom'			=> '12',
			'marker'		=> '',
			'full_height'	=> false,
			'map_h'			=> 'classic',
			'style'			=> '1',

 		), $atts ) );

		$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, $this->settings['base'], $atts );
		
		// custum css
		$css_class .= vc_shortcode_custom_css_class( $css, ' ' );

		// custum class
		$css_class .= (!empty($el_class)) ? ' '.$el_class : '';

		$height_class = '';
		$full_h = '';
		if ($map_h == 'full') {
			$height_class = 'full-h';
			$full_h = 'main-top-slider';
		} elseif ($map_h == 'classic') {
			$height_class = '';
			$full_h = 'map-item';
		} elseif ($map_h == 'small') {
			$height_class = 'sm-height';
		}

		$marker_full = '';
		if ($marker) {
			$marker_full = wp_get_attachment_image_url( $marker, 'full' );
		}

 		// output
		ob_start();
		do_shortcode( $content );
		?>
		<!--Google map -->

		<?php if ($map_h == 'full' || $map_h == 'classic' || $map_h == 'small') { ?>
			<div class="<?php print esc_html($full_h); ?> <?php print esc_attr( $css_class ); ?>">
				<div class="map-item <?php echo esc_html($height_class); ?>"> 
					<div class="map-wrapper map-full" id="map-canvas" data-lat="<?php if(is_numeric($lat)) {print esc_html($lat);} ?>" data-lng="<?php if(is_numeric($lng)) {print esc_html($lng);} ?>" data-zoom="<?php if(is_numeric($zoom)) {print esc_html($zoom);} ?>" data-marker="<?php print $marker_full ?>" data-style="<?php echo esc_html($style);?>"></div>
					<div class="markers-wrapper addresses-block">
						<a class="marker" data-rel="map-canvas" data-lat="<?php if(is_numeric($lat)) {print esc_html($lat);} ?>" data-lng="<?php if(is_numeric($lng)) {print esc_html($lng);} ?>" data-string='<?php if ($name) {print esc_html($name);}?>'></a>
					</div>
				</div>
			</div>
		<?php } elseif ($map_h == 'classic_2') { ?>
			<div class="block-height-800">
					<div class="map-wrapper map-full" id="map-canvas" data-lat="<?php if(is_numeric($lat)) {print esc_html($lat);} ?>" data-lng="<?php if(is_numeric($lng)) {print esc_html($lng);} ?>" data-zoom="<?php if(is_numeric($zoom)) {print esc_html($zoom);} ?>" data-marker="<?php print $marker_full ?>" data-style="<?php echo esc_html($style);?>"></div>
					<div class="markers-wrapper addresses-block">
						<a class="marker" data-rel="map-canvas" data-lat="<?php if(is_numeric($lat)) {print esc_html($lat);} ?>" data-lng="<?php if(is_numeric($lng)) {print esc_html($lng);} ?>" data-string='<?php if ($name) {print esc_html($name);}?>'></a>
					</div>
			</div>
		<?php } ?>


		<?php wp_enqueue_script( 'maps'); ?>
		<?php 
		return  ob_get_clean();
	}
}