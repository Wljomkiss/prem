<?php 
/*
** FAQ
** Author: NRGTHEMES
** Author URI: http://nrgthemes.com
** Version: 1.0.0 
*/

vc_map( array(
	'name'                    => __( 'FAQ', 'nrg_remium' ),
	'base'                    => 'nrg_premium_faq',
	'category' 				  => __( 'NRGPremium', 'nrg_remium' ),
	'content_element'         => true,
	'show_settings_on_create' => true,
	'description' 		      => __( 'frequently asked questions', 'nrg_remium' ),
	'params'          => array(
		array(
			'type'        => 'dropdown',
			'heading'     => __( 'FAQ type', 'nrg_remium' ),
			'param_name'  => 'faq_type',
			'value'       => array(
				'Faq classic'   => 'type_1',
				'Tabs faq'   	=> 'type_2',
			),
		),
		array(
			'type'    => 'param_group',
			'js_view'   => 'VcColumnView',
			'heading'   => __( 'FAQ', 'nrg_remium' ),
			'description' => __( 'FAQ', 'nrg_remium' ),
			'param_name'  => 'faq',
			'params'  => array(
				array(
					'type'        => 'textfield',
					'heading'     => 'Question',
					'param_name'  => 'question',
					'value'       => '',
				),
				array(
					'type'        => 'textarea',
					'heading'     => 'Answer',
					'param_name'  => 'answer',
					'value'       => '',
				),
			),
			'dependency'  => array( 'element' => 'faq_type', 'value' => 'type_1'),
		),
		array(
			'type'    => 'param_group',
			'js_view'   => 'VcColumnView',
			'heading'   => __( 'FAQ tabs', 'nrg_remium' ),
			'description' => __( 'FAQ tabs', 'nrg_remium' ),
			'param_name'  => 'tabs',
			'params'  => array(
				array(
						'type'        => 'textfield',
						'heading'     => 'Tab title',
						'param_name'  => 'tab_title',
						'value'       => '',
					),
				array(
					'type'    => 'param_group',
					'js_view'   => 'VcColumnView',
					'heading'   => __( 'FAQ', 'nrg_remium' ),
					'description' => __( 'FAQ', 'nrg_remium' ),
					'param_name'  => 'faq_2',
					'params'  => array(
						array(
							'type'        => 'textfield',
							'heading'     => 'Question',
							'param_name'  => 'question',
							'value'       => '',
						),
						array(
							'type'        => 'textarea',
							'heading'     => 'Answer',
							'param_name'  => 'answer',
							'value'       => '',
						),
					),
				),
			),
			'dependency'  => array( 'element' => 'faq_type', 'value' => 'type_2'),
		),
	) //end params
) );

class WPBakeryShortCode_nrg_premium_faq extends WPBakeryShortCode {
	protected function content( $atts, $content = null) {

		extract( shortcode_atts( array(
			'el_class'      => '',
			'css'           => '',
			'faq_type'		=> 'type_1',
			'faq'			=> '',
			'tabs'			=> '',

 		), $atts ) );

		$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, $this->settings['base'], $atts );
		
		// custum css
		$css_class .= vc_shortcode_custom_css_class( $css, ' ' );

		// custum class
		$css_class .= (!empty($el_class)) ? ' '.$el_class : '';

		

 		// output
		ob_start();
		do_shortcode( $content );
		?>
		<!--FAQ-->
		<!--TYPE 1-->

		<?php
		if( $faq_type == 'type_1' && isset($atts['faq']) ){
			$values = vc_param_group_parse_atts( $atts['faq'] );
			$element = ''; 
				$i = 1;
				$count= count($values);
				foreach ($values as $value) {

					if (isset($value['question']) && isset($value['answer'])) {
						$element.= '<li class="accordeon-item">';
						$element.= '<a href="#" class="accordeon-triger vertical-wrap"><span></span>';
						$element.= '<h5 class="h7 title align-item">';
						$element.= esc_html($value['question']);
						$element.= '</h5>';
						$element.= '</a>';
						$element.= '<div class="accordeon-inner">';
						$element.= '<div class="simple-text col-1">';
						$element.= '<p>'.wp_kses_post($value['answer']).'></p>';
						$element.= '</div>';
						$element.= '</div>';
						$element.= '</li>';
						if( ceil( $count/2) == $i ) {
							$element.= '</ul></div></div><div class="col-md-6"><div class="accordeon"><ul class="accordeon-list">';
						}
						$i++;
					}
				}
			?>

			<div class="<?php print esc_attr( $css_class ); ?>">
				<div class="col-md-6">
					<div class="accordeon">
						<ul class="accordeon-list">
							<?php echo $element; ?>
						</ul>
					</div> 
				</div>
			</div>
			<!--TYPE 1 END-->
		<?php } elseif ($faq_type == 'type_2' && isset($atts['tabs']) ){ 
			$values = vc_param_group_parse_atts( $atts['tabs']);
		
			//--TYPE 2
			if ( $values ) { 
				$element = $tab_t = $tab_m = '';
				$j = 1;
				foreach( $values as $value ){
					if( isset($value['tab_title']) && $value['tab_title'] && isset($value['faq_2']) ){
						$faqs = vc_param_group_parse_atts( $value['faq_2']);
						if( $j == 1 )
							$tab_m = '<div class="select-txt tt text-center"><p>'.esc_html($value['tab_title']).'</p><i class="fa fa-angle-down"></i></div>';
						$tab_t.= '<li '.( $j == 1 ? 'class="active"' : '' ).'><a href="#">'.esc_html($value['tab_title']).'</a></li>';
						$element.= '<div class="tab-item">';
						$element.= '<div class="row">';
						$element.= '<div class="col-md-6">';
						$element.= '<div class="accordeon">';
						$element.= '<ul class="accordeon-list">'; 
						$i = 1;
						$count= count($faqs);
						foreach( $faqs as $faq ){
							if ( isset($faq['question']) && isset($faq['answer'])) {
								$element.= '<li class="accordeon-item">';
								$element.= '<a href="#" class="accordeon-triger vertical-wrap">';
								$element.= '<span></span>';
								$element.= '<h5 class="h7 title align-item">'.esc_html($faq['question']).'</h5>';
								$element.= '</a>';
								$element.= '<div class="accordeon-inner">';
								$element.= '<div class="simple-text col-1">';
								$element.= '<p>'.esc_html($faq['answer']).'</p>';
								$element.= '</div>';
								$element.= '</div>';
								$element.= '</li>';
								if( ceil( $count/2) == $i ) {
									$element.= '</ul></div></div><div class="col-md-6"><div class="accordeon"><ul class="accordeon-list">';
								}
								$i++;
							}
						}
						$element.= '</ul>';
						$element.= '</div>';
						$element.= '</div>';
						$element.= '</div>';
						$element.= '</div>';
					}
					$j++;
				}
			?>

				<div class="tabs-block"> 
					<div class="filter-list-mobile">
						<?php echo $tab_m; ?> 
						<ul class="tabs-link-type-1 tabs-link second-font filter-list style-1">
							<?php echo $tab_t; ?>
						</ul>
					</div>
				</div>
				<div class="empty-md-80 empty-sm-40 empty-xs-40"></div>
				<div class="tabs-container">
					<?php echo $element; ?>
				</div>
			<?php } ?>
			<!--TYPE 2 END-->
		<?php } 

		return  ob_get_clean();
	}

}
