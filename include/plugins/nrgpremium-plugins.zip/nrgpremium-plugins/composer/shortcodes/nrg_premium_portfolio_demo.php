<?php 
/*
 * Portfolio Shortcode
 * Author: Upqode
 * Author URI: http://upqode.com
 * Version: 1.0.0 
 */

vc_map( 
	array(
		'name'            => __( 'Portfolio DEMO', 'nrg_premium' ),
		'base'            => 'nrg_premium_portfolio_demo',
		'description'     => __( 'Portfolio DEMo', 'nrg_premium' ),
		'category' 				  => __( 'NRGPremium', 'nrg_premium' ),
		'params'          => array(
			array(
				'type'        => 'checkbox',
				'heading'     => __( 'Filter', 'nrg_premium' ),
				'param_name'  => 'filters',
				'value'       => true,
			),
			array(
				'type' 		  => 'dropdown',
				'admin_label' => true, 
				'heading' 	  => 'Order by',
				'param_name'  => 'orderby',
				'value' 	  => array(
					'ID' 		    => 'ID',
					'Author' 	    => 'author',
					'Post Title'    => 'title',
					'Date' 		    => 'date',
					'Last Modified' => 'modified',
					'Random Order'  => 'rand',
					'Menu Order'    => 'menu_order'
				)
			),
			array(
				'type' 		  => 'dropdown',
				'heading' 	  => 'Order',
				'param_name'  => 'order',
				'value' 	  => array(
					'Ascending'  => 'ASC',
					'Descending' => 'DESC'
				)
			),
			array(
				'type'        => 'vc_efa_chosen',
				'heading'     => __( 'Custom Categories', 'nrg_premium' ),
				'param_name'  => 'cats',
				'placeholder' => 'Choose category (optional)',
				'value'       => nrg_premium_param_values( 'terms', array(
					'taxonomies' => 'portfolio_categories',
				) ),
				'std'         => '',
				'description' => __( 'You can choose spesific categories for portfolio, default is all categories', 'nrg_premium' ),
			),
			array(
				'type'        => 'textfield',
				'heading'     => __( 'Count items', 'nrg_premium' ),
				'param_name'  => 'limit',
				'value'       => '',
				'description' => __( 'Default 20 items.', 'nrg_premium' )
			),
			array(
				'type' 		  => 'textfield',
				'heading' 	  => __( 'Extra class name', 'nrg_premium' ),
				'param_name'  => 'el_class',
				'description' => __( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'nrg_premium' ),
				'value' 	  => ''
			),
			/* CSS editor */
			array(
				'type' 		  => 'css_editor',
				'heading' 	  => __( 'CSS box', 'nrg_premium' ),
				'param_name'  => 'css',
				'group' 	  => __( 'Design options', 'nrg_premium' )
			),
		)
	)
);

class WPBakeryShortCode_nrg_premium_portfolio_demo extends WPBakeryShortCode{
	protected function content( $atts, $content = null ) {
		extract( shortcode_atts( array(
			'orderby'		=> 'ID',
			'order'			=> 'ASC',
			'cats'			=> '',
			'limit'			=> '',
			'filters'		=> true,
			'el_class'		=> '',
			'css'			=> '',
			// 'port_type'		=> 'column',
			'item_size'		=> '',

		), $atts ) );

		$class  = ( ! empty( $el_class ) ) ? $el_class : '';
		$class .= vc_shortcode_custom_css_class( $css, ' ' );

		$limit 	  = ( empty( $limit ) || ! is_numeric( $limit ) ) ? 20 : $limit;
		$category = '';
		$sc_cats = $cats;
		$cats 	 = explode( ',', $cats );
		
		//WP_Query
		if ( $sc_cats ){
			$category = array(
				'taxonomy' => 'portfolio_categories',
				'field'    => 'id',
				'terms'    => $cats
			);
		}

		$args = array(
			'post_type'      => 'portfolio',
			'posts_per_page' => -1,
			'order'			 => $order,
			'orderby'		 => $orderby,
			'tax_query'      => array(
				$category
			)
		);
		$post = new WP_Query( $args );
		// Filter
?>
		<div class="">
			<div class="container-fluid">
					<?php if( $filters == true ) { ?>
						<div class="filter-list-mobile">
							<div class="select-txt">
								<p><?php print esc_html__('All', 'nrg_premium' ) ?></p>
								<i class="fa fa-angle-down"></i>
							</div>      
							<ul class="filter-list style-1 style-demo">
								<li data-filter="*" class="active"><span><?php print esc_html__('All', 'nrg_premium' ) ?></span></li>
								<?php $categories = get_terms( 'portfolio_categories', '' );
									if( $categories ){
										foreach ( $categories as $cat ) {
											if ( $sc_cats ) {
												if( in_array($cat->term_id, $cats ) ) { ?>
													<li data-filter=".<?php print $cat->slug ?>"><span><?php print $cat->name ?></span></li>
												<?php }
											} else { ?>
												<li data-filter=".<?php print $cat->slug ?>"><span><?php print $cat->name ?></span></li>
											<?php } 
										}
									}
								?>
							</ul>
						</div>    
					<?php } 
					if ( $post->have_posts() ) { ?>
						<div class="empty-md-90 empty-sm-60 empty-xs-40"></div>
						<div class="izotope-container gutter-15 demo-izo">
							<div class="grid-sizer"></div>
							<?php 
								$i = 1;
								while ( $post->have_posts() ) : $post->the_post();
									$portfolio_category = '';
									$categories = get_the_terms( get_the_ID() , 'portfolio_categories' );
									if( $categories ) {
										foreach ( $categories as $categorsy ) {
											$portfolio_category.= $categorsy->slug . ' ';
										}
									}
									if( has_post_thumbnail() ){ ?>
										<div class="item col-33 md-col-50 sm-col-50 xs-col-100 <?php echo $portfolio_category; ?>">
											<div class="work-item">
												<img src="<?php the_post_thumbnail_url()?>" alt="<?php the_title(); ?>" class="work-img" >
												<a href="<?php echo get_the_excerpt(); ?>" class="project-desc">
													<div class="vertical-align full">
														<h4 class="title h4"><?php the_title(); ?></h4> 
													</div> 
												</a> 
											</div>
										</div>
									<?php }
									if( $i == 4 )
										$i = 1;
									else 
										$i++;
								endwhile;
							?>
						</div>
					<?php } ?>
			</div>
		</div>
		<?php wp_reset_postdata();
	}
}