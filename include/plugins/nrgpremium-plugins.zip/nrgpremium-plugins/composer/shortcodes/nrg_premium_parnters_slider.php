<?php 
/*
** Partners
** Version: 1.0.0 
*/

vc_map( array(
	'name'                    => __( 'Partners slider', 'nrg_premium' ),
	'base'                    => 'nrg_premium_partners_slider',
	'as_parent'               => array('only' => 'nrg_premium_partners_slider_item'),
	'content_element'         => true,
	'show_settings_on_create' => false,
	'category' 				  => __( 'NRGPremium', 'nrg_premium' ),
	'description'             => __( 'Partners slider', 'nrg_premium'),
	'js_view'                 => 'VcColumnView',
	'params'          => array(
		array(
			'type'        => 'dropdown',
			'heading'     => __( 'Partners type', 'nrg_premium' ),
			'param_name'  => 'partners_type',
			'value'       => array(
				'Type 1'   => 'type_1',
				'Type 2'   => 'type_2',
			),
		),
		array(
			'type'			=> 'dropdown',
			'heading'		=> __( 'Border', 'nrg_premium' ),
			'param_name'	=> 'border',
			'value'			=> array(
				'Enable'		=> 'enable',
				'Disable'		=> 'disable',
			),
			'dependency'	=> array( 'element' => 'partners_type', 'value' => 'type_2'),
		),
		array(
			'type'			=> 'dropdown',
			'heading'		=> __( 'Border subtype', 'nrg_premium' ),
			'param_name'	=> 'border_subtype',
			'value'			=> array(
				'Subtype 1 '	=> 'subtype_1',
				'Subtype 2'		=> 'subtype_2',
			),
			'dependency'	=> array( 'element' => 'border', 'value' => 'enable'),
		),
		array(
		    'type'        => 'textfield',
		    'heading'     => __( 'Autoplay (sec)', 'nrg_premium' ),
		    'description' => __( '0 - off autoplay', 'nrg_premium' ),
		    'param_name'  => 'autoplay',
		    'value'       => '0',
		    'group' => __( 'Animation', 'nrg_premium' )
		),
		array(
		    'type'        => 'textfield',
		    'heading'     => __( 'Speed (milliseconds)', 'nrg_premium' ),
		    'description' => __( 'Speed Animation. Default 800 milliseconds', 'nrg_premium' ),
		    'param_name'  => 'speed',
		    'value'       => '800',
		    'group' => __( 'Animation', 'nrg_premium' )
		),
		array(
			'type' => 'textfield',
			'heading' => __( 'Extra class name', 'nrg_premium' ),
			'param_name' => 'el_class',
			'description' => __( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'nrg_premium' ),
			'value' => '',
		),
		array(
			'type' => 'css_editor',
			'heading' => __( 'CSS box', 'nrg_premium' ),
			'param_name' => 'css',
			'group' => __( 'Design options', 'nrg_premium' ),
		),
	) //end params
) );

class WPBakeryShortCode_nrg_premium_partners_slider extends WPBakeryShortCodesContainer {

	protected function content( $atts, $content = null) {

		extract( shortcode_atts( array(
			'el_class'		=> '',
			'css'			=> '',
			'autoplay'		=> '0',
			'speed'			=> '800',
			'partners_type'	=> 'type_1',
			'border'		=> 'enable',
			'border_subtype'	=> 'subtype_1',

		), $atts ) );

		global $_parnters_items;
		$_parnters_items = array();

		$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, $this->settings['base'], $atts );

		// custum css
		$css_class .= vc_shortcode_custom_css_class( $css, ' ' );

		// custum class
		$css_class .= (!empty($el_class)) ? ' '.$el_class : '';
		
		// autoplay, loop and speed
		$autoplay = is_numeric($autoplay) ? $autoplay*1000 : 0;
		$speed = is_numeric($speed) ? $speed : '800';

		// output
		ob_start();
		do_shortcode( $content );
		?>
		<?php if ($partners_type == 'type_1') { ?>
			<div class="<?php print esc_attr( $css_class ); ?>">
				<div class="swiper-container client-slider" data-mode="horizontal" data-autoplay="<?php print esc_attr( $autoplay ); ?>" data-effect="slide" data-slides-per-view="responsive" data-loop="0" data-speed="800" data-add-slides="7" data-lg-slides="7" data-md-slides="5" data-sm-slides="4" data-xs-slides="1" data-speed="<?php print esc_attr( $speed ); ?>">
					<div class="swiper-wrapper">
						<?php foreach ($_parnters_items as $key => $shortcode) :
							$shortcode_atts = $shortcode['atts'];
								$image_html = '';
								if (!empty($shortcode_atts['image'])) {
									$image_full = wp_get_attachment_image_url( $shortcode_atts['image'], 'full' );
									$image_html = '<img src="'. esc_url( $image_full ). '" alt=""> ';
								} ?>
								
								<div class="swiper-slide">
									<div class="client-slide flex-align">
										  <?php print $image_html ?>
									</div>
								</div>

						<?php endforeach; ?>
					</div>
					<div class="pagination pagination-hide"></div>
				</div> 
			</div>
		<?php } 
		elseif ($partners_type == 'type_2') { ?>
			<div class="<?php print esc_attr( $css_class ); ?>">
				<div class="swiper-container client-slider" data-mode="horizontal" data-autoplay="0" data-effect="slide" data-slides-per-view="responsive" data-loop="0" data-speed="800" data-add-slides="7" data-lg-slides="7" data-md-slides="5" data-sm-slides="4" data-xs-slides="1">
					<div class="swiper-wrapper">
						<?php foreach ($_parnters_items as $key => $shortcode) :
							$shortcode_atts = $shortcode['atts'];
							$image_html = '';
							if (!empty($shortcode_atts['image'])) {
								$image_full = wp_get_attachment_image_url( $shortcode_atts['image'], 'full' );
								$image_html = '<img src="'. esc_url( $image_full ). '" alt=""> ';
							} ?>
							<div class="swiper-slide">
								<?php 
									$b_subtype = '';
									if  ($border_subtype == 'subtype_1') {
										$b_subtype = 'border-type';
									} elseif ($border_subtype == 'subtype_2') {
										$b_subtype = 'border-type-2';
									}
									if (isset($shortcode_atts['url'])) {
										$link = vc_build_link($shortcode_atts['url']);
									}
								?>
								<a href="<?php echo (isset($link) ? $link['url'] : '#');?>" class="client-slide flex-align style-2 <?php echo ($border == 'enable'? $b_subtype : ''); ?>">
									<?php print $image_html ?>
								</a>
							</div>
						<?php endforeach; ?>
					</div>
					<div class="pagination pagination-hide"></div>
				</div>
			</div>
		<?php }
		return  ob_get_clean();
	}

}
/* Shortvode Item */

vc_map( array(
  'name'            => 'Partners Item',
  'base'            => 'nrg_premium_partners_slider_item',
  'as_child' 		=> array('only' => 'nrg_premium_partners_slider'),
  'content_element' => true,
  'show_settings_on_create' => true,
  'description'     => 'Slider item',
  'params'          => array(
		array(
			'type'        => 'attach_image',
			'heading'     => __( 'Image', 'nrg_premium' ),
			'param_name'  => 'image',
			'admin_label' => true,
			'description' => 'Upload your image.'
		),
		array(
			'type'        => 'vc_link',
			'heading'     => 'Link',
			'param_name'  => 'url',
			'value'       => '',
			'description' => 'Only for type 2'
		),
  ) //end params
) );


class WPBakeryShortCode_nrg_premium_partners_slider_item extends WPBakeryShortCode{
	protected function content( $atts, $content = null ) {
		global $_parnters_items;
		$_parnters_items[] = array('atts' => $atts, 'content' => $content, 'css_class' => '');
		return;
	}
}