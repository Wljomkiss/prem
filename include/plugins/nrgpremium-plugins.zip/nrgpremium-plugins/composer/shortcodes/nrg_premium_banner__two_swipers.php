<?php 
vc_map( array(
	'name'						=> __( 'Two slider', 'nrg_premium' ),
	'base'						=> 'nrg_premium__two_sliders',
	'as_parent'					=> array('only' => 'nrg_premium__two_sliders_item'),
	'content_element'			=> true,
	'show_settings_on_create'	=> false,
	'category'					=> __( 'NRGPremium', 'nrg_premium' ),
	'description'				=> __( 'Swiper pagination', 'nrg_premium'),
	'js_view'					=> 'VcColumnView',
	'params'					=> array(
		array(
			'type'			=> 'dropdown',
			'heading'		=> __( 'Arrow enable', 'nrg_premium' ),
			'param_name'	=> 'arrow_enable',
			'value'			=> array(
				'Enable'		=> 'enable',
				'Disable'		=> 'disable',
			),
		),
		array(
			'type'			=> 'dropdown',
			'heading'		=> __( 'Arrow type', 'nrg_premium' ),
			'param_name'	=> 'arrow_type',
			'value'			=> array(
				'Type 1'		=> 'type_1',
				'Type 2'		=> 'type_2',
			),
			'dependency'	=> array( 'element' => 'arrow_enable', 'value' => 'enable' ),
		),
		array(
			'type'			=> 'textfield',
			'heading'		=> __( 'Extra class name', 'nrg_premium' ),
			'param_name'	=> 'el_class',
			'description'	=> __( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'nrg_premium' ),
			'value'			=> '',
		),
		array(
			'type'			=> 'css_editor',
			'heading'		=> __( 'CSS box', 'nrg_premium' ),
			'param_name'	=> 'css',
			'group'			=> __( 'Design options', 'nrg_premium' ),
		),
	) //end params
) );

class WPBakeryShortCode_nrg_premium__two_sliders extends WPBakeryShortCodesContainer {

	protected function content( $atts, $content = null) {

		extract( shortcode_atts( array(
			'el_class'				=> '',
			'css'					=> '',
			'arrow_enable'			=> 'enable',
			'arrow_type'			=> 'type_1',
			

		), $atts ) );

		$background_left_image_html = '';
		if (!empty($background_left_image)) {
			$background_left_image_full = wp_get_attachment_image_url( $background_left_image, 'full' );
			$background_left_image_html = '<div class="bg bg-bg-chrome act" style="background-image:url('. esc_url( $background_left_image_full ).')"></div>';
		} 

		global $_two_slider_items;
		$_two_slider_items = array();

		$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, $this->settings['base'], $atts );

		// custum css
		$css_class .= vc_shortcode_custom_css_class( $css, ' ' );

		// custum class
		$css_class .= (!empty($el_class)) ? ' '.$el_class : '';
		
		// output
		ob_start();
		do_shortcode( $content );
		?>
		<div class="<?php print esc_attr($css_class); ?> arrow-closest">
			<div class="main-top-slider no-offset slider-swiching">
				<div class="swiper-container full-h container-swich" data-mode="horizontal" data-autoplay="0" data-effect="slide" data-slides-per-view="1" data-loop="0" data-speed="800">
					<div class="swiper-wrapper">
						<?php foreach ($_two_slider_items as $key => $shortcode) :
							$shortcode_atts = $shortcode['atts'];
							$image_html = '';
							if (!empty($shortcode_atts['image'])) {
								$image_full = wp_get_attachment_image_url( $shortcode_atts['image'], 'full' );
								$image_html = '<div class="bg layer-hold" style="background-image: url('. esc_url( $image_full ). ')"></div>';
							} ?>
							<div class="swiper-slide">
								<?php print $image_html ?>
								<div class="vertical-align full">
									<div class="container">
										<div class="row">
											<div class="col-md-8">
												<div class="custome-padd-100 xs-padd-15">
													<div class="empty-lg-0 empty-md-0 empty-sm-0 empty-xs-40"></div>
													<div class="caption text-left type-2 text-center-xs">
														<?php if (isset($shortcode_atts['subtitle'])){ ?>
															<span class="sub-title col-1"><?php echo esc_html($shortcode_atts['subtitle']); ?></span>
															<div class="empty-sm-15 empty-xs-15"></div>
														<?php } 
														if (isset($shortcode_atts['title'])){ ?>
															<h2 class="h1 title lh-60"><?php echo esc_html($shortcode_atts['title']); ?></h2>
															<div class="empty-sm-25 empty-xs-25"></div>
														<?php } 
														if (isset($shortcode_atts['short_desc'])){ ?>
															<div class="simple-text lg col-3">
																<p><?php print wp_kses_post($shortcode_atts['short_desc']); ?></p>
															</div>
															<div class="empty-sm-35 empty-xs-30"></div>
														<?php } ?>
														
														<?php 
														$btn_align_n = '';
														if ($shortcode_atts['btn_align'] == 'align_left') {
															$btn_align_n = 'text-left';
														} else {
															$btn_align_n = 'text-center';
														}

														$btn_type = $shortcode_atts['btn_type'];
														$button_title = $shortcode_atts['button_title'];
														$button_url 	= $shortcode_atts['button_url'];
														if (isset($shortcode_atts['b_width'])) {
															$but_width = $shortcode_atts['b_width'];
														} else {
															$but_width = 'standart';
														}
														if (isset($shortcode_atts['m_color'])) {
															$main_color = $shortcode_atts['m_color'];
														} else {
															$main_color = '#84694e';
														}
														hm_get_template_part('composer/shortcodes/buttons/button-'.$btn_type, [ 'title' => $button_title, 'but_url' => $button_url, 'but_align' =>  $btn_align_n, 'main_color' => $main_color, 'but_width' => $but_width ]); ?>
													</div>
												</div>
												<div class="empty-lg-0 empty-md-0 empty-sm-40 empty-xs-60"></div>
											</div>
										</div>
									</div>
								</div>
							</div>
						<?php endforeach; ?>
					</div>
					<div class="pagination d_none"></div>
				</div>
				<?php if ($arrow_enable == 'enable') { ?>
					<div class="swiper-arrow-left slider-arrow-1 <?php if ($arrow_type == 'type_2' ){print ('type-2');} ?>"><i class="fa fa-angle-left"></i></div>
					<div class="swiper-arrow-right slider-arrow-1 <?php if ($arrow_type == 'type_2' ){print ('type-2');} ?>"><i class="fa fa-angle-right"></i></div>
				<?php } ?>


				<!--SECOND SWIPER --> 
					<div class="swiper-container swich-parent service-choose-slider" data-mode="horizontal" data-autoplay="0" data-effect="slide" data-slides-per-view="responsive" data-loop="0" data-speed="800" data-add-slides="4" data-lg-slides="4" data-md-slides="3" data-sm-slides="2" data-xs-slides="1">
						<div class="swiper-wrapper">
							<?php $i = 1; 
							 foreach ($_two_slider_items as $key => $shortcode) :
								$shortcode_atts = $shortcode['atts'];
								?>
								<div class="swiper-slide <?php echo ( $i == 1 ? 'active' : '')?>">
									<div class="slide-swich <?php echo ( $i == 1 ? 'active' : '')?>">
										<div class="service-icon-box style-5">
											<?php if (isset($shortcode_atts['icon'])){ ?>
												<div class="image">
													<img src="<?php echo esc_url(wp_get_attachment_image_url( $shortcode_atts['icon'], 'full' )); ?>" alt="">
												</div>
											<?php } ?>
											<div class="caption">
												<?php if(isset($shortcode_atts['sw_2_title'])) { ?>
													<h6 class="h6 title"><?php echo $shortcode_atts['sw_2_title'] ?></h6>
												<?php } 
												if (isset($shortcode_atts['sw_2_subtitle'])) { ?>
													<span class="sub-desc"><?php echo $shortcode_atts['sw_2_subtitle'] ?></span>
												<?php } ?>  
											</div>
										</div>
									</div>
								</div>
							<?php $i++;
							endforeach; ?>
						</div>
						<div class="pagination pagination-hide"></div>
					</div>
				<!--SECOND SWIPER END-->
			</div>  
		</div>

		<?php 
		return  ob_get_clean();
	}

}
/* Shortvode Item */

vc_map( array(
  'name'					=> 'Slider Item',
  'base'					=> 'nrg_premium__two_sliders_item',
  'as_child'				=> array('only' => 'nrg_premium__two_sliders'),
  'content_element'			=> true,
  'show_settings_on_create'	=> true,
  'description'				=> 'Slider item',
  'params'					=> array(
		array(
			'type'			=> 'attach_image',
			'heading'		=> __( 'Image', 'nrg_premium' ),
			'param_name'	=> 'image',
			'admin_label'	=> true,
			'description'	=> 'Upload your image.'
		),
		array(
			'type'			=> 'textfield',
			'heading'		=> __( 'Title', 'nrg_premium' ),
			'param_name'	=> 'title',
			'admin_label'	=> true,
			'value'			=> '',
			'description'	=> __( 'Title slider item.', 'nrg_premium' ),
		),
		array(
			'type'			=> 'textfield',
			'heading'		=> __( 'Subtitle', 'nrg_premium' ),
			'param_name'	=> 'subtitle',
			'admin_label'	=> true,
			'value'			=> '',
			'description'	=> __( 'Subtitle slider item.', 'nrg_premium' ),
		),
		array(
			'type'			=> 'textarea',
			'heading'		=> __( 'Short Description', 'nrg_premium' ),
			'param_name'	=> 'short_desc',
			'description'	=> __( 'Short description slider item.', 'nrg_premium' ),
		),
		array(
			'type'			=> 'dropdown',
			'heading'		=> __( 'Button type', 'nrg_premium' ),
			'param_name'	=> 'btn_type',
			'value'			=> array(
				'Type 1'		=> 'type_1',
				'Type 2'		=> 'type_2',
				'Type 3'		=> 'type_3',
				'Type 4'		=> 'type_4',
				'Type 5'		=> 'type_5',
				'Type 6'		=> 'type_6',
			),
			'group'			=> __( 'Button', 'nrg_premium' ),
		),
		array(
			'type'			=> 'textfield',
			'heading'		=> __( 'Button title', 'nrg_premium' ),
			'param_name'	=> 'button_title',
			'admin_label'	=> true,
			'value'			=> '',
			'description'	=> __( 'Button title', 'nrg_premium' ),
			'group'			=> __( 'Button', 'nrg_premium' ),
		),
		array(
			'type'			=> 'vc_link',
			'heading'		=> __( 'Link', 'nrg_premium' ),
			'param_name'	=> 'button_url',
			'value'			=> '',
			'description'	=> __( 'Button link', 'nrg_premium' ),
			'group'			=> __( 'Button', 'nrg_premium' ),
		),
		array(
			'type'			=> 'dropdown',
			'heading'		=> __( 'Button width', 'nrg_premium' ),
			'param_name'	=> 'b_width',
			'value'			=> array(
				'Standart'		=> 'standart',
				'Small'			=> 'small',
			),
			'group'			=> __( 'Button', 'nrg_premium' ),
		),
		array(
			'type'			=> 'colorpicker',
			'class'			=> '',
			'heading'		=> __( 'Main color', 'nrg_premium' ),
			'param_name'	=> 'm_color',
			'value'			=> '#84694e',
			'group'			=> __( 'Button', 'nrg_premium' ),
		),
		array(
			'type'			=> 'dropdown',
			'heading'		=> __( 'Button Align', 'nrg_premium' ),
			'param_name'	=> 'btn_align',
			'value'			 => array(
				'Align left'	=> 'align_left',
				'Align center'	=> 'align_center',
			),
			'group'			=> __( 'Button', 'nrg_premium' ),
		),
		array(
			'type'			=> 'attach_image',
			'heading'		=> __( 'Icon', 'nrg_premium' ),
			'param_name'	=> 'icon',
			'admin_label'	=> true,
			'group'			=> __( 'Pagination swiper', 'nrg_premium' ),
		),
		array(
			'type'			=> 'textfield',
			'heading'		=> __( 'Swiper 2 title', 'nrg_premium' ),
			'param_name'	=> 'sw_2_title',
			'admin_label'	=> true,
			'value'			=> '',
			'group'			=> __( 'Pagination swiper', 'nrg_premium' ),
		),
		array(
			'type'			=> 'textfield',
			'heading'		=> __( 'Swiper 2 subtitle', 'nrg_premium' ),
			'param_name'	=> 'sw_2_subtitle',
			'group'			=> __( 'Pagination swiper', 'nrg_premium' ),
		),
  ) //end params
) );


class WPBakeryShortCode_nrg_premium__two_sliders_item extends WPBakeryShortCode{
	protected function content( $atts, $content = null ){
		global $_two_slider_items;
		$atts['btn_type'] = ( isset($atts['btn_type']) ? $atts['btn_type'] : 'type_1' );
		$atts['btn_align'] = ( isset($atts['btn_align']) ? $atts['btn_align'] : 'align_left' );
		$_two_slider_items[] = array('atts' => $atts, 'content' => $content, 'css_class' => '');
		return;
	}
}