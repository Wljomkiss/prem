<?php 
/*
** Banner with text
** Author: NRGTHEMES
** Author URI: http://nrgthemes.com
** Version: 1.0.0 
*/

vc_map( array(
	'name'                    => __( 'Banner with text', 'nrg_premium' ),
	'base'                    => 'nrg_premium_banner_text',
	'category' 				  => __( 'NRGPremium', 'nrg_premium' ),
	'content_element'         => true,
	'show_settings_on_create' => true,
	'description'             => __( 'Image and 1/3 left text ', 'nrg_premium'),
	'params'          => array(
		array(
			'type'        => 'dropdown',
			'heading'     => __( 'Type', 'nrg_premium' ),
			'param_name'  => 'type',
			'value'       => array(
				'Type 1'   => 'type_1',
				'Type 2'   => 'type_2',
				)
		),
		array(
			'type'        => 'attach_image',
			'heading'     => __( "Image", "nrg_premium" ),
			'param_name'  => 'image',
			'admin_label' => true,
			'description' => 'Upload your image.'
		),
		array(
			'type'        => 'dropdown',
			'heading'     => __( 'Image align', 'nrg_premium' ),
			'param_name'  => 'img_align',
			'value'       => array(
				'Right'		=> 'right',
				'Left'		=> 'left',
				)
		),
		array(
			'type'        => 'dropdown',
			'heading'     => __( 'Paralax efect', 'nrg_premium' ),
			'param_name'  => 'lax_efect',
			'value'       => array(
				'Enable'		=> 'enable',
				'Disable'		=> 'disable',
				)
		),
		array(
			'type'        => 'textfield',
			'heading'     => __( "Subtitle", "nrg_premium" ),
			'param_name'  => 'subtitle',
			'admin_label' => true,
			'value'       => '',
		),
		array(
			'type'        => 'textfield',
			'heading'     => __( "Title", "nrg_premium" ),
			'param_name'  => 'title',
			'admin_label' => true,
			'value'       => '',
		),
		array(
			'type'        => 'textarea',
			'heading'     => __( 'Short Description', 'nrg_premium' ),
			'param_name'  => 'short_desc',
			'dependency'  => array( 'element' => 'type', 'value' => 'type_1'),
		),
		array(
			'type'        => 'textarea',
			'heading'     => __( 'Content', 'nrg_premium' ),
			'param_name'  => 'desc',
			'dependency'  => array( 'element' => 'type', 'value' => 'type_1'),
		),
		array(
			'type'			=> 'param_group',
			'js_view'		=> 'VcColumnView',
			'heading'		=> __( 'List info', 'nrg_premium' ),
			'param_name'	=> 'values',
			'params'		=> array(
				array(
					'type'			=> 'textfield',
					'heading'		=> __('List info item', 'nrg_premium'),
					'param_name'	=> 'list_info_item',
				),
			),
			'dependency'	=> array( 'element' => 'type', 'value' => 'type_1'),
		),
		array(
			'type'			=> 'param_group',
			'js_view'		=> 'VcColumnView',
			'heading'		=> __( 'Service list', 'nrg_premium' ),
			'param_name'	=> 'values_type_2',
			'params'		=> array(
				array(
					'type'			=> 'attach_image',
					'heading'		=> __( "Service icon", "nrg_premium" ),
					'param_name'	=> 'ser_icon',
					'admin_label'	=> true,
					'description'	=> 'Upload your image.'
				),
				array(
					'type'			=> 'textfield',
					'heading'		=> __('Service item title', 'nrg_premium'),
					'param_name'	=> 'ser_title',
				),
				array(
					'type'			=> 'textfield',
					'heading'		=> __('Service item subtitle', 'nrg_premium'),
					'param_name'	=> 'ser_subtitle',
				),
			),
			'dependency'	=> array( 'element' => 'type', 'value' => 'type_2'),
		),
		array(
			'type'        => 'textfield',
			'heading'     => __( "Button title", "nrg_premium" ),
			'param_name'  => 'button_title',
			'admin_label' => true,
			'value'       => '',
			'dependency'  => array( 'element' => 'type', 'value' => 'type_1'),
		),
		array(
			'type'        => 'vc_link',
			'heading'     => __( "Button url", "nrg_premium" ),
			'param_name'  => 'button_url',
			'admin_label' => true,
			'value'       => '#',
			'dependency'  => array( 'element' => 'type', 'value' => 'type_1'),
		),
		array(
			'type' => 'textfield',
			'heading' => __( 'Extra class name', 'nrg_premium' ),
			'param_name' => 'el_class',
			'description' => __( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'nrg_premium' ),
			'value' => '',
		),
		array(
			'type' => 'css_editor',
			'heading' => __( 'CSS box', 'nrg_premium' ),
			'param_name' => 'css',
			'group' => __( 'Design options', 'nrg_premium' ),
		),
	) //end params
) );

class WPBakeryShortCode_nrg_premium_banner_text extends WPBakeryShortCode {
	protected function content( $atts, $content = null) {

		extract( shortcode_atts( array(
			'el_class'		=> '',
			'css'			=> '',
			'title'			=> '',
			'subtitle'		=> '',
			'short_desc'	=> '',
			'desc'			=> '',
			'values'		=> '',
			'button_title'	=> '',
			'button_url'	=> '',
			'image'			=> '',
			'type'			=> 'type_1',
			'img_align'		=> 'right',
			'lax_efect'		=> 'enable',
			'values_type_2'	=> '',


 		), $atts ) );

		if ($values) {
			$values_new = vc_param_group_parse_atts( $values );
		}

		if ($values_type_2) {
			$values_new_2 = vc_param_group_parse_atts( $values_type_2 );
		}

		$lax_ef = '';
		if ($lax_efect == 'enable') {
			$lax_ef = 'fix';
		}

		$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, $this->settings['base'], $atts );
		
		// custum css
		$css_class .= vc_shortcode_custom_css_class( $css, ' ' );

		// custum class
		$css_class .= (!empty($el_class)) ? ' '.$el_class : '';

 		// output
		ob_start();
		do_shortcode( $content );
		?>
		<!--Banner with text-->
		<div class="section <?php print esc_attr( $css_class ); ?> lalal">
			
			<?php if ($type == 'type_1') { ?>
				<?php if ($image) { ?>
					<div class="bg offset-33<?php echo esc_html($img_align == 'right' ? '' : '-right'); ?> <?php echo esc_html($lax_ef) ?> hide-mobile" style="background-image: url(<?php echo esc_url(wp_get_attachment_image_url( $image, 'full' ));?>)"></div>
				<?php } ?>
				<div class="<?php echo esc_html($img_align == 'right' ? '' : 'col-30-right'); ?> col-30 styled-block">
					<div class="empty-lg-140 empty-md-100 empty-sm-60 empty-xs-60"></div>
					<div class="caption type-2 text-center">
						<?php if ($subtitle){ ?>
							<span class="sub-title col-2"><?php print esc_html($subtitle) ?></span>
							<div class="empty-sm-5 empty-xs-5"></div>
						<?php } ?>
						<?php if ($title){ ?>
							<h2 class="h2 title"><?php print esc_html($title) ?></h2>
						<?php } ?>
						<div class="empty-sm-15 empty-xs-15"></div>
						<?php if($short_desc){ ?>
							<div class="simple-text md col-2">
								<p><?php print wp_kses_post($short_desc); ?></p>
							</div>
						<?php } ?>
						<div class="empty-sm-40 empty-xs-40"></div>
						<?php if($desc){ ?>
							<div class="simple-text md col-2">
								<p><?php print wp_kses_post($desc); ?></p>
							</div>
						<?php } ?>
						<div class="empty-sm-20 empty-xs-20"></div>
						<?php if (isset($values_new)) { ?>
							<ul class="simple-list list-style-1">
							<?php foreach ($values_new as $value) { 
								if ($value['list_info_item']) { ?>
								<li><?php print esc_html($value['list_info_item']); ?></li>
								<?php } ?>
							<?php } ?>
							</ul>
						<?php } ?>
						<div class="empty-sm-25 empty-xs-25"></div>
						<?php $button_link = vc_build_link($button_url);
						if ($button_title && $button_link) { ?>
							<a href="<?php print esc_html($button_link['url'])?>" class="main-link link-style-1 type-3"><span><?php print esc_html($button_title)?></span></a>
						<?php } ?>

					</div>
					<div class="empty-lg-140 empty-md-100 empty-sm-60 empty-xs-60"></div>    
				</div>
			<?php } elseif ($type == 'type_2') { ?>
				<div class="container-fluid no-padd">
					<div class="row vertical-wrap">
						<div class="col-md-8 col-sm-12 col-xs-12">
							<div class="block-height-800 flex-align">
								<div class="bg layer-hold" style="background-image: url(<?php echo esc_url(wp_get_attachment_image_url( $image, 'full' ));?>)"></div>
								<div class="custome-padd-100 xs-padd-15">
									<div class="row">
										<div class="col-md-7 col-md-offset-5">
											<div class="caption text-right type-2 text-center-md">
												<?php if ($title) { ?>
													<h3 class="h2 lg title"><?php print esc_html($title) ?></h3>
												<?php } 
												if ($subtitle) { ?>
													<div class="empty-sm-15 empty-xs-15"></div>
													<div class="simple-text md col-3 max-500">
														<p><?php print esc_html($subtitle) ?></p>
													</div>
												<?php } ?>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div class="col-md-4 col-sm-12 col-xs-12">
							<div class="empty-lg-0 empty-md-0 empty-sm-60 empty-xs-60"></div>
							<div class="custome-padd-100 xs-padd-15">   
								<?php foreach ($values_new_2 as $value_2) { ?>
							
									<div class="service-icon-box style-4 border-bottom">
										<?php if (isset($value_2['ser_icon'])) { ?>
											<div class="image">
												<img src="<?php echo esc_url(wp_get_attachment_image_url($value_2['ser_icon'], 'full' ));?>" alt="">
											</div>
										<?php } ?>
										<div class="caption">
											<?php if (isset($value_2['ser_title'])) { ?>
												<h6 class="h6 title"><?php echo esc_html($value_2['ser_title']); ?></h6>
											<?php } 
											if (isset($value_2['ser_subtitle'])) { ?>
												<div class="empty-sm-10 empty-xs-10"></div>
												<div class="simple-text col-1">
													<p><?php echo esc_html($value_2['ser_subtitle']); ?></p>
												</div>
											<?php } ?>
										</div>
										<div class="empty-sm-40 empty-xs-30"></div>
									</div>
									<div class="empty-sm-50 empty-xs-30"></div>

								<?php } ?>
							</div>
							<div class="empty-lg-0 empty-md-0 empty-sm-60 empty-xs-60"></div>  
						</div>
					</div>
				</div>
			<?php } ?>
		</div>
		<?php 
		return  ob_get_clean();
	}

}