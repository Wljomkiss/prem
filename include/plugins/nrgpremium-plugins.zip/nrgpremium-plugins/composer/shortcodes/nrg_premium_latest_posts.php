<?php 
/*
** Latest Post
** Author: NRGTHEMES
** Author URI: http://nrgthemes.com
** Version: 1.0.0 
*/

vc_map( array(
	'name'                    => __( 'Latest post', 'nrg_premium' ),
	'base'                    => 'nrg_premium_latest_post',
	'content_element'         => true,
	'show_settings_on_create' => true,
	'description' 		      => __( 'Latest posts from category', 'nrg_premium' ),
	'category' 				  => __( 'NRGPremium', 'nrg_premium' ),
	'params'          => array(
		array(
			'type'			=> 'dropdown',
			'heading'		=> __( 'View type', 'nrg_premium' ),
			'param_name'	=> 'type',
			'admin_label'	=> true,
			'value'			=> array(
				'Type 1'		=> 'type_1',
				'Type 2'		=> 'type_2',
				'Type 3'		=> 'type_3',
				'Type 4'		=> 'type_4',
				'Type 5'		=> 'type_5',
				'Classic'					=> 'classic',
				'Standart img '				=> 'standart_img',
				'Standart img gallery'		=> 'standart_img_gall',
				'Standart without img'		=> 'standart_without_img',
				'Standart list'				=> 'standart_list',
				'Standart list first big photo'	=> 'standart_list_first_big',
				'Creative list'				=> 'creative_list',
				'Creative single'			=> 'creative_single',
				'Most viewed'				=> 'most_viwed',
				'Most commented'			=> 'most_comented',
			),
		),
		array(
			'type'			=> 'vc_efa_chosen',
			'heading'		=> __( 'Custom Categories', 'nrg_premium' ),
			'param_name'	=> 'cats',
			'placeholder'	=> 'Choose category (optional)',
			'value'			=> nrg_premium_param_values( 'terms', array(
				'taxonomies'	=> 'category',
			) ),
			'std'			=> '',
			'description'	=> __( 'You can choose spesific categories for post, default is all categories', 'nrg_premium' ),
		),
		array(
			'type'			=> 'dropdown',
			'heading'		=> __( 'Post per page', 'nrg_premium' ),
			'param_name'	=> 'per_page',
			'value'			=> array(
				'Three'			=> 'three',
				'Four'			=> 'four',
			),
			'dependency'	=> array( 'element' => 'type', 'value' => array('type_1','type_2', 'type_3', 'type_4')),
		),
		array(
			'type'			=> 'textfield',
			'heading'		=> __( 'Posts limit', 'nrg_premium' ),
			'param_name'	=> 'limit',
			'value'			=> '',
			'description'	=> __( 'Default is 6 posts in slides, only for numbers', 'nrg_premium' ),
		),
		array(
			'type'			=> 'vc_link',
			'heading'		=> 'Blog url',
			'param_name'	=> 'blog_url',
			'admin_label'	=> true,
			'value'			=> '',
			'dependency'	=> array( 'element' => 'type', 'value' => array('type_1','type_2')),
		),
		array(
			'type'			=> 'dropdown',
			'heading'		=> __( 'Subtype', 'nrg_premium' ),
			'param_name'	=> 'subtype_stan_list',
			'value'			=> array(
				'Subtype 1'		=> 'subtype_1',
				'Subtype 2'		=> 'subtype_2',
			),
			'dependency'	=> array( 'element' => 'type', 'value' => 'standart_list'),
		),
		array(
			'type'			=> 'dropdown',
			'heading'		=> __( 'Subtype', 'nrg_premium' ),
			'param_name'	=> 'subtype_without',
			'value'			=> array(
				'Tall'			=> 'tall',
				'Small'			=> 'small',
			),
			'dependency'	=> array( 'element' => 'type', 'value' => 'standart_without_img'),
		),
		array(
			'type'			=> 'dropdown',
			'heading'		=> __( 'Subtype', 'nrg_premium' ),
			'param_name'	=> 'subtype_stan_img',
			'value'			=> array(
				'Left img wide content'		=> 'left_wide',
				'Left img half content'		=> 'left_half',
				'Top img standart'			=> 'top',
				'Top img big padding'		=> 'top_big',
				'Top img with author'		=> 'top_author',
				'Top img with author in img'	=> 'top_author_img',
				'Top img with author in img 2'	=> 'top_author_img_2',
			),
			'dependency'	=> array( 'element' => 'type', 'value' => 'standart_img'),
		),
		array(
			'type'			=> 'dropdown',
			'heading'		=> __( 'Subtype', 'nrg_premium' ),
			'param_name'	=> 'subtype_classic',
			'value'			=> array(
				'Post individual button'		=> 'individual_button',
				'Post individual'				=> 'new',
			),
			'dependency'	=> array( 'element' => 'type', 'value' => 'classic'),
		),
		array(
			'type'			=> 'dropdown',
			'heading'		=> __( 'Subtype', 'nrg_premium' ),
			'param_name'	=> 'subtype_crea',
			'value'			=> array(
				'Wide'			=> 'wide',
				'Wide with author'	=> 'wide_author',
				'Big & tall'	=> 'big_tall',
				'Small'			=> 'small',
				'Tall'			=> 'tall',
				'Tall 2'			=> 'tall_2',
				'Tall no author'	=> 'tall_no_author',
			),
			'dependency'	=> array( 'element' => 'type', 'value' => 'creative_single'),
		),
		array(
			'type'			=> 'dropdown',
			'heading'		=> __( 'Category visability', 'nrg_premium' ),
			'param_name'	=> 'cat_visib',
			'value'			=> array(
				'Enable'		=> 'enable',
				'Disable'		=> 'disable',
			),
		),
		array(
			'type'			=> 'dropdown',
			'heading'		=> __( 'Category type', 'nrg_premium' ),
			'param_name'	=> 'cat_type',
			'value'			=> array(
				'Type 1'		=> 'type_1',
				'Type 2'		=> 'type_2',
			),
			'dependency'	=> array( 'element' => 'cat_visib', 'value' => 'enable'),
		),

		array(
			'type'			=> 'textfield',
			'heading'		=> __( 'Extra class name', 'js_composer' ),
			'param_name'	=> 'el_class',
			'description'	=> __( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'js_composer' ),
			'value'			=> '',
		),
		array(
			'type'			=> 'css_editor',
			'heading'		=> __( 'CSS box', 'js_composer' ),
			'param_name'	=> 'css',
			'group'			=> __( 'Design options', 'js_composer' ),
		),
	) //end params
) );



class WPBakeryShortCode_nrg_premium_latest_post extends WPBakeryShortCode{
	protected function content( $atts, $content = null ) {
		extract( shortcode_atts( array(
			'el_class'  	=> '',
			'css'			=> '',
			'type'			=> 'type_1',
			'blog_url'		=> '',
			'per_page'		=> 'three',
			'limit'			=> 6,
			'cats'			=> '',
			'cat_visib'		=> 'enable',
			'cat_type'		=> 'type_1',
			'subtype_crea'		=> 'wide',
			'subtype_stan_img'	=> 'left_wide',
			'subtype_without'	=> 'tall',
			'subtype_classic'	=> 'individual_button',
			'subtype_stan_list'	=> 'subtype_1',

		), $atts ) );

		$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, $this->settings['base'], $atts );
		
		// custum css
		$css_class .= vc_shortcode_custom_css_class( $css, ' ' );

		// custum class
		$css_class .= (!empty($el_class)) ? ' '.$el_class : '';

		$latest_class = '';
		if ($type == 'type_1') {
			$blog_class = 'blog-item';
		} elseif ($type == 'type_2') {
			$blog_class = 'simple-item-1 hover-color-1';
		}
		 
		if ($blog_url) {
			$blog_link = vc_build_link($blog_url);
		}

		if ($per_page == 'three') {
			$col = 'col-md-4';
		} elseif ($per_page == 'four') {
			$col = 'col-md-3';
		}

		// limit
		$limit 	  = ( empty( $limit ) || ! is_numeric( $limit ) ) ? 6 : $limit;

		$args = array(
			'post_type'      => 'post',
			'posts_per_page' => $limit,
			'order'			 => 'DESC',
			'orderby'		 => 'date',
			'tax_query'      => array()
		);
		if( $cats ){
			$cats = explode( ',', $cats );
			$args['tax_query'][] = array(
				'taxonomy' => 'category',
				'field'    => 'id',
				'terms'    => $cats
			);
		}

		if( $type == 'most_comented' ){
			$args['orderby'] = 'comment_count';
		} elseif( $type == 'most_viwed' ){
			$args['orderby']  = 'meta_value_num';
			$args['meta_key'] = 'wpb_post_views_count';
		}

		$query = new WP_Query( $args );

		// output
		ob_start();
		do_shortcode( $content );

		if( $query->have_posts() ){ ?>
			<div class="<?php print esc_attr( $css_class ); ?>">
				<?php if ($type == 'type_1' || $type == 'type_2' || $type == 'type_3' || $type == 'type_4' ) { ?>
					<div class="row">
						<?php
						$args = array( 'posts_per_page' => $limit);
						$query = new WP_Query( $args );
						while ( $query->have_posts() ) {
						$query->the_post() ?>
							<div class="<?php echo $col ?>">
								<?php if ($type == 'type_1' || $type == 'type_2') { ?>
									<div class="hover-block <?php echo esc_html($blog_class); ?>">
										<?php if ( has_post_thumbnail()) { ?>
											<a href="<?php the_permalink(); ?>" class="image hover-layer bg-col-2">
												<?php the_post_thumbnail(); ?>
											</a>
										<?php } ?>
										<div class="text">
											<?php
											if ($type == 'type_1') { ?>
												<div class="empty-sm-20 empty-xs-20"></div>
											<?php } elseif ($type == 'type_2') { ?>
												<div class="empty-sm-25 empty-xs-25"></div>
												<p class="sub-title sm col-3"><?php echo the_time(get_option('date_format')); echo esc_html__(' by '); the_author(); ?></p>
												<div class="empty-sm-5 empty-xs-5"></div> 
											<?php } ?>
											<h6 class="h6 title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h6>
											<div class="empty-sm-15 empty-xs-15"></div>
												<div class="simple-text"><p><?php echo wp_trim_words( get_the_excerpt(), 25, ' ...' ); ?></p></div>
											<?php if ($type == 'type_1') { ?>
												<div class="empty-sm-25 empty-xs-25"></div>
												<a href="<?php the_permalink(); ?>" class="main-link link-style-7 type-2"><span><?php echo esc_html__('read more', 'nrg_premium'); ?></span></a>
											<?php } ?>
										</div>
									</div>
									<div class="empty-sm-30 empty-xs-30"></div>
								<?php } elseif ($type == 'type_3') { ?>
									<div class="simple-item-2">
										<div class="bg layer-hold type-4" style="background-image: url(<?php echo the_post_thumbnail_url(); ?>)"></div> 
										<div class="text type-2">
											<p class="sub-title sm col-6"><?php echo the_time(get_option('date_format')); echo esc_html__(' by '); the_author(); ?></p>
											<div class="empty-sm-5 empty-xs-5"></div> 
											<h3 class="h6 title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
											<div class="empty-sm-15 empty-xs-15"></div> 
											<div class="simple-text col-3">
												<p><?php echo wp_trim_words( get_the_excerpt(), 25, ' ...' ); ?></p>
											</div>
										</div>
									</div>  
								<?php } elseif ($type == 'type_4') { ?>
									<div class="simple-item-1 hover-block">
										<a href="<?php the_permalink(); ?>" class="image hover-layer bg-col-2">
											<img src="<?php echo the_post_thumbnail_url(); ?>" alt="" class="resp-img">
										</a> 
										<div class="empty-sm-20 empty-xs-20"></div>
										<div class="text">
											<?php
												$get_the_category = get_the_category();
												if( $get_the_category ){
													$i = 1;
													echo '<span class="sub-title sm ls tt">';
													foreach( $get_the_category as $category ){
														echo $category->cat_name;
														echo ( $i >= 1 && sizeof($get_the_category) != $i ? ', ' : '' );
														$i++;
													}
													echo '</span>';
												}
											?>
											<div class="empty-sm-5 empty-xs-5"></div>
											<h3 class="h5 title">
												<a href="<?php the_permalink(); ?>" class="link-hover-1"><?php the_title(); ?></a>
											</h3>
											<div class="empty-sm-15 empty-xs-15"></div> 
											<div class="simple-text col-1">
												<p><?php echo wp_trim_words( get_the_excerpt(), 25, ' ...' ); ?></p>
											</div>
											<div class="empty-sm-30 empty-xs-30"></div>
										</div>
									</div>
								<?php } ?>
							</div>

						<?php }
						wp_reset_postdata();
						?>
						<?php if ($type == 'type_2') {
							if (isset($blog_link)) { ?>
								<div class="col-md-12">
									<div class="text-center">
										<a href="<?php print esc_html($blog_link['url'])?>" class="main-link wh-lg link-style-5" data-text="all posts"><span><?php echo esc_html__('all posts', 'nrg_premium'); ?></span></a> 
									</div>
								</div>
							<?php } 
						}?>  
					</div>
				<?php } elseif ($type == 'type_5') { ?>
					<div class="row">
						<?php
						$args = array( 'posts_per_page' => $limit);
						$query = new WP_Query( $args );
						while ( $query->have_posts() ) {
						$query->the_post() ?>
							<div class="<?php echo $col ?>">
								<div class="blog-item hover-block">
									<a href="<?php the_permalink(); ?>" class="image hover-layer bg-col-6">
										<img src="<?php the_post_thumbnail_url();?>" alt="" class="resp-img">
									</a>
									<div class="empty-sm-25 empty-xs-20"></div>
									<div class="text text-center">
										<div class="caption type-2 text-center">
											<h6 class="h6 title">
												<a href="<?php the_permalink();?>" class="link-hover-4"><?php the_title();?></a> 
											</h6>
											<div class="empty-sm-15 empty-xs-15"></div>
											<div class="simple-text col-2">
												<p><?php echo wp_trim_words( get_the_excerpt(), 25, ' ...' ); ?></p>
											</div>
											<div class="empty-sm-25 empty-xs-20"></div>
											<a href="<?php the_permalink();?>" class="main-link link-style-1 color-7 type-3 wh-smx"><span><?php echo esc_html__('learn more', 'nrg_premium');?></span></a>
										</div>
									</div>
								</div>
								<div class="empty-sm-30 empty-xs-30"></div> 
							</div>
						<?php }
						wp_reset_postdata();
						?>
					</div>
				<?php } elseif ($type == 'classic') { ?>
					<?php if ($subtype_classic == 'individual_button') { ?>
						<div class="padd-15">
							<div class="row col-no-padding">
								<?php
								$args = array( 'posts_per_page' => $limit);
								$query = new WP_Query( $args );
								while ( $query->have_posts() ) {
								$query->the_post() ?>
									<div class="col-md-3 col-sm-6 col-xs-12">
										<div class="mag-item-1 hover-block type-4">
											<a href="<?php the_permalink(); ?>" class="image hover-layer bg-col-5">
												<img src="<?php the_post_thumbnail_url();?>" alt="" class="resp-img">  
											</a>
											<div class="text">
												<div class="sub-title sm col-13 second-font"><i><?php echo the_time(get_option('date_format')); ?></i></div>
													<div class="empty-sm-5 empty-xs-5"></div>
													<div class="caption">
													<h3 class="h6 title no-tr">
														<a href="<?php the_permalink();?>" class="text-line-animate sm"><?php the_title();?></a>
													</h3>
												</div>
												<div class="empty-sm-15 empty-xs-15"></div>
												<div class="simple-text sm col-1">
													<p><?php echo wp_trim_words( get_the_excerpt(), 25, ' ...' ); ?></p>
												</div>
												<div class="empty-sm-20 empty-xs-20"></div>
												<a href="<?php the_permalink();?>" class="news-link"><?php echo esc_html__('read more', 'nrg_premium'); ?></a> 
												<div class="empty-sm-20 empty-xs-20"></div>
											</div>
										</div>
										<div class="empty-sm-30 empty-xs-30"></div>  
									</div>
								<?php }
								wp_reset_postdata();
								?>
							</div>
						</div>
					<?php } ?>
				<?php } elseif ($type == 'standart_without_img') { ?>
					<?php while ( $query->have_posts() ) {
					$query->the_post();?>
						<?php if ($subtype_without == 'tall') { ?>
							<div class="mag-item min-h-md style-2">
								<?php 
									$term_list = get_the_terms(get_the_ID(), 'category' );
									if( $term_list ){
										echo '<div class="mag-item-cat-wr">';
										foreach( $term_list as $value ){
											$bg_color = '';
											$term_data = get_term_meta( $value->term_id, '_custom_category_options', true );
											if(isset($term_data['post_cat_color'])){
												$bg_color = 'style="background-color:'.$term_data['post_cat_color'].';"';
											}
											echo '<div class="mag-item-cat '.($cat_type=="type_2"?"type-2": "").'" '.($cat_type=="type_1"?"$bg_color": "").'><a href="'.get_term_link($value->term_id).'">'.$value->name.'</a></div>';
										}
										echo '</div>';
									}
								?>
								<div class="mag-item-content">
									<div class="sub-title sm"><i><?php the_time(get_option('date_format')); ?></i></div>
									<div class="empty-sm-5 empty-xs-5"></div>
									<div class="caption">
										<h3 class="h3 lg title h-no-transform">
											<a href="<?php the_permalink();?>" class="text-line-animate no-tr"><?php the_title(); ?></a>
										</h3>
									</div>
									<div class="empty-sm-15 empty-xs-15"></div>
									<div class="simple-text sm col-8">
										<p><?php echo wp_trim_words( get_the_excerpt(), 25, ' ...' ); ?></p>
									</div>
									<div class="empty-sm-20 empty-xs-20"></div>
									<div class="info-bar">
										<?php
											nrg_premium_get_simple_likes_button(get_the_ID());
											$comments_count = wp_count_comments(get_the_ID());
											echo wp_kses_post( '<div><i class="fa fa-comment-o"></i><span>'.$comments_count->total_comments.'</span></div>' );
										?>
									</div>
									<div class="empty-sm-30 empty-xs-30"></div>
									<div class="user-bar">
										<?php echo get_avatar( get_the_author_meta( 'ID' ), 32 ); ?>
										<h6 class="h8"><a href="<?php echo get_author_posts_url( get_the_ID(), get_the_author_meta( "user_nicename" ) ); ?>"><?php the_author(); ?></a></h6>
									</div>
								</div>
							</div>
						<?php } elseif ($subtype_without == 'small') { ?>
							<div class="mag-item-1 min-sm-height no-img">
								<div class="text">
									<div class="sub-title sm col-13"><i><?php the_time(get_option('date_format')); ?></i></div>
									<div class="empty-sm-10 empty-xs-10"></div>
									<div class="caption">
										<h3 class="h5 title sm no-tr">
											<a href="<?php the_permalink();?>" class="text-line-animate sm"><?php the_title();?></a>
										</h3>
									</div>
									<div class="empty-sm-15 empty-xs-15"></div>
									<div class="simple-text sm col-1">
										<p><?php echo wp_trim_words( get_the_excerpt(), 25, ' ...' ); ?></p>
									</div>
									<?php
										$term_list = get_the_terms(get_the_ID(), 'category' );
										if( $term_list ){
											echo '<div class="mag-item-cat-wr bottom">';
											foreach( $term_list as $value ){
												$bg_color = $col = '';
												$term_data = get_term_meta( $value->term_id, '_custom_category_options', true );
												if(isset($term_data['post_cat_color'])){
													$bg_color = 'style="background-color:'.$term_data['post_cat_color'].';"';
													$col = 'style="color:'.$term_data['post_cat_color'].';"';
												}
												echo '<div class="mag-item-cat '.($cat_type=="type_2"?"type-2": "").'" '.($cat_type=="type_1"?"$bg_color": "$col").'><a href="'.get_term_link($value->term_id).'">'.$value->name.'</a></div>';
											}
											echo '</div>';
										}
									?>
								</div>
							</div>
						<?php } ?>
					<?php }
					wp_reset_postdata();
					?>
				<?php } elseif ($type == 'standart_img') { ?>
					<?php while ( $query->have_posts() ) {
					$query->the_post();
					$right_img = 'right-img'; 
						if ($subtype_stan_img == 'left_wide') { ?>
							<div class="mag-item-1 <?php if (has_post_thumbnail()) {echo $right_img;} ?> ">
								<?php if ( has_post_thumbnail()) { ?>
									<div class="image">
										<div class="bg" style="background-image: url(<?php the_post_thumbnail_url(); ?>)"></div> 
									</div>
								<?php } ?>
								<div class="text">
									<?php 
										$term_list = get_the_terms(get_the_ID(), 'category' );
										if( $term_list ){
											foreach( $term_list as $value ){
												$bg_color = '';
												$term_data = get_term_meta( $value->term_id, '_custom_category_options', true );
												if(isset($term_data['post_cat_color'])){
													$bg_color = 'style="background-color:'.$term_data['post_cat_color'].';"';
												}
												echo '<div class="mag-item-cat '.($cat_type=="type_2"?"type-2": "").'" '.($cat_type=="type_1"?"$bg_color": "").'><a href="'.get_term_link($value->term_id).'">'.$value->name.'</a></div>';
											}
										}
									?>
									<div class="empty-sm-30 empty-xs-30"></div>
									<div class="sub-title sm col-13"><i><?php the_time(get_option('date_format')); ?></i></div>
									<div class="empty-sm-5 empty-xs-5"></div>
									<div class="caption">
										<h3 class="h5 title">
											<a href="<?php the_permalink(); ?>" class="text-line-animate no-tr"><?php the_title(); ?></a>
										</h3>
									</div>
									<div class="empty-sm-25 empty-xs-25"></div>
									<div class="simple-text sm col-1">
										<p><?php echo wp_trim_words( get_the_excerpt(), 25, ' ...' ); ?></p>
									</div>
								</div>
							</div>
						<?php } elseif ($subtype_stan_img == 'left_half') { ?>
							<div class="mag-item-1 right-img">
								<div class="image">
									<div class="bg" style="background-image: url(<?php the_post_thumbnail_url(); ?>)"></div> 
								</div>
								<div class="text">
									<div class="caption">
										<h3 class="h5 sm title tt">
											<a href="<?php the_permalink();?>" class="text-line-animate sm"><?php the_title();?></a>
										</h3>
									</div>
									<div class="empty-sm-5 empty-xs-5"></div>
									<div class="sub-title sm col-13"><i><?php the_time(get_option('date_format')); ?></i></div>
									<div class="empty-sm-15 empty-xs-15"></div>
									<div class="simple-text sm col-1">
										<p><?php echo wp_trim_words( get_the_excerpt(), 25, ' ...' ); ?></p>
									</div>
								</div> 
							</div>
						<?php } elseif ($subtype_stan_img == 'top') { ?>
							<div class="mag-item-1 hover-block mx-height">
								<a href="<?php the_permalink();?>" class="image hover-layer bg-col-5">
									<img src="<?php the_post_thumbnail_url(); ?>" alt="">  
								</a>
								<div class="text">
									<?php 
										$term_list = get_the_terms(get_the_ID(), 'category' );
										if( $term_list ){
											foreach( $term_list as $value ){
												$bg_color = $col = '';
												$term_data = get_term_meta( $value->term_id, '_custom_category_options', true );
												if(isset($term_data['post_cat_color'])){
													$bg_color = 'style="background-color:'.$term_data['post_cat_color'].';"';
													$col = 'style="color:'.$term_data['post_cat_color'].';"';
												}
												echo '<div class="mag-item-cat '.($cat_type=="type_2"?"type-2": "").'" '.($cat_type=="type_1"?"$bg_color": "$col").'><a href="'.get_term_link($value->term_id).'">'.$value->name.'</a></div>';
											}
										}
									?>
									<div class="empty-sm-25 empty-xs-25"></div>
									<div class="caption">
										<h3 class="h5 sm title tt">
											<a href="<?php the_permalink();?>" class="text-line-animate sm"><?php the_title();?></a>
										</h3>
									</div>
									<div class="empty-sm-5 empty-xs-5"></div>
									<div class="sub-title sm col-13"><i><?php the_time(get_option('date_format')); ?></i></div>
									<div class="empty-sm-15 empty-xs-15"></div>
									<div class="simple-text sm col-1">
										<p><?php echo wp_trim_words( get_the_excerpt(), 25, ' ...' ); ?></p>
									</div>
								</div>
							</div>
						<?php } elseif ($subtype_stan_img == 'top_big') { ?>
							<div class="mag-item-1 min-h-md no-img">
								<div class="image">
									<img src="<?php the_post_thumbnail_url();?>" alt="">
								</div>
								<div class="text">
									<?php 
										$term_list = get_the_terms(get_the_ID(), 'category' );
										if( $term_list ){
											foreach( $term_list as $value ){
												$bg_color = $col = '';
												$term_data = get_term_meta( $value->term_id, '_custom_category_options', true );
												if(isset($term_data['post_cat_color'])){
													$bg_color = 'style="background-color:'.$term_data['post_cat_color'].';"';
													$col = 'style="color:'.$term_data['post_cat_color'].';"';
												}
												echo '<div class="mag-item-cat '.($cat_type=="type_2"?"type-2": "").'" '.($cat_type=="type_1"?"$bg_color": "$col").'><a href="'.get_term_link($value->term_id).'">'.$value->name.'</a></div>';
											}
										}
									?>
									<div class="empty-sm-20 empty-xs-20"></div>
									<div class="sub-title sm col-13"><i><?php the_time(get_option('date_format')); ?></i></div>
									<div class="empty-sm-5 empty-xs-5"></div>
									<div class="caption">
										<h3 class="h4 lg title no-tr">
											<a href="<?php the_permalink();?>" class="text-line-animate sm"><?php the_title();?></a>
										</h3>
									</div>
									<div class="empty-sm-15 empty-xs-15"></div>
									<div class="simple-text sm col-1">
										<p><?php echo wp_trim_words( get_the_excerpt(), 25, ' ...' ); ?></p>
									</div>
								</div> 
							</div>
						<?php } elseif ($subtype_stan_img == 'top_author') { ?>
							<div class="mag-item-1 hover-block">
								<?php
									$term_list = get_the_terms(get_the_ID(), 'category' );
									if( $term_list ){
										echo '<div class="mag-item-cat-wr top">';
										foreach( $term_list as $value ){
											$bg_color = '';
											$term_data = get_term_meta( $value->term_id, '_custom_category_options', true );
											if(isset($term_data['post_cat_color'])){
												$bg_color = 'style="background-color:'.$term_data['post_cat_color'].';"';
											}
											echo '<div class="mag-item-cat '.($cat_type=="type_2"?"type-2": "").'" '.($cat_type=="type_1"?"$bg_color": "").'><a href="'.get_term_link($value->term_id).'">'.$value->name.'</a></div>';
										}
										echo '</div>';
									}
								?>
								<a href="<?php the_permalink();?>" class="image hover-layer bg-col-5">
									<img src="<?php the_post_thumbnail_url();?>" alt="" class="resp-img">  
								</a>
								<div class="text">
									<div class="sub-title sm col-13"><i><?php the_time(get_option('date_format')); ?></i></div>
									<div class="empty-sm-5 empty-xs-5"></div>
									<div class="caption">
										<h3 class="h5 sm title no-tr">
											<a href="<?php the_permalink();?>" class="text-line-animate sm"><?php the_title();?></a>
										</h3>
									</div>
									<div class="empty-sm-15 empty-xs-15"></div>
									<div class="simple-text sm col-1">
										<p><?php echo wp_trim_words( get_the_excerpt(), 25, ' ...' ); ?></p>
									</div>
									<div class="empty-sm-30 empty-xs-30"></div>
									<div class="user-bar">
										<?php echo get_avatar( get_the_author_meta( 'ID' ), 32 ); ?>
										<h6 class="h8 bold"><a href="<?php echo get_author_posts_url( get_the_ID(), get_the_author_meta( "user_nicename" ) ); ?>"><?php the_author(); ?></a></h6>
									</div> 
								</div>
							</div>
						<?php } elseif ($subtype_stan_img == 'top_author_img') { ?>
							<div class="mag-item-1 type-4">
								<div class="image img-info layer-hold">
									<div class="info-bar type-2">
										<?php
											nrg_premium_get_simple_likes_button(get_the_ID());
											$comments_count = wp_count_comments(get_the_ID());
											echo wp_kses_post( '<div><i class="fa fa-comment-o"></i><span>'.$comments_count->total_comments.'</span></div>' );
										?>
									</div>
									<div class="user-bar type-2">
										<?php echo get_avatar( get_the_author_meta( 'ID' ), 32 ); ?>
										<h6 class="h8 title"><a href="<?php echo get_author_posts_url( get_the_ID(), get_the_author_meta( "user_nicename" ) ); ?>"><?php the_author(); ?></a></h6>
									</div>
									<img src="<?php the_post_thumbnail_url();?>" alt="" class="resp-img">  
								</div>
								<div class="text">
									<div class="sub-title sm col-13 second-font"><i><?php the_time(get_option('date_format')); ?></i></div>
									<div class="empty-sm-10 empty-xs-10"></div>
									<div class="caption">
										<h3 class="h6 title">
											<a href="<?php the_permalink();?>" class="text-line-animate sm"><?php the_title();?></a>
										</h3>
									</div>
									<div class="empty-sm-15 empty-xs-15"></div>
									<div class="simple-text sm col-1">
										<p><?php echo wp_trim_words( get_the_excerpt(), 25, ' ...' ); ?></p>
									</div>
									<div class="empty-sm-20 empty-xs-20"></div>
									<a href="<?php the_permalink();?>" class="news-link"><?php echo esc_html__('read more', 'nrg_premium'); ?></a> 
								</div>
							</div>
						<?php } elseif ($subtype_stan_img == 'top_author_img_2') { ?>
							<div class="mag-item-1 hover-block type-4 padd-inset padd-inset-md">
								<a href="<?php the_permalink();?>" class="image hover-layer bg-col-5">
									<img src="<?php the_post_thumbnail_url();?>" alt="" class="resp-img">  
								</a>
								<div class="text">
									<div class="sub-title sm col-13 second-font"><i><?php the_time(get_option('date_format')); ?></i></div>
									<div class="empty-sm-5 empty-xs-5"></div>
									<div class="caption">
										<h3 class="h6 title no-tr">
											<a href="<?php the_permalink();?>" class="text-line-animate sm"><?php the_title();?></a>
										</h3>
									</div>
									<div class="empty-sm-15 empty-xs-15"></div>
									<div class="simple-text sm col-1">
										<p><?php echo wp_trim_words( get_the_excerpt(), 25, ' ...' ); ?></p>
									</div>
									<div class="empty-sm-20 empty-xs-20"></div>
									<a href="<?php the_permalink();?>" class="news-link"><?php echo esc_html__('read more', 'nrg_premium');?></a> 
								</div>
                            </div>
						<?php } ?>
					<?php }
					wp_reset_postdata();
					?>
				<?php } elseif ($type == 'standart_list') { ?>
					<div class="recommend-block">
						<?php while ( $query->have_posts() ) {
						$query->the_post();
							if ($subtype_stan_list == 'subtype_1') { ?>
								<div class="item">
									<div class="img">
										<a href="<?php the_permalink();?>">
											<img src="<?php the_post_thumbnail_url();?>" alt="">
										</a>
									</div>
									<div class="txt">
										<h6 class="h7 sm"><a href="<?php the_permalink();?>"><?php the_title();?></a></h6>
										<div class="empty-sm-15 empty-xs-15"></div>
										<div class="sub-title xs col-13 second-font"><i><?php the_time(get_option('date_format')); ?></i></div>     
									</div>
								</div>
							<?php }
							if ($subtype_stan_list == 'subtype_2') { ?>
								<div class="item type-2">
									<div class="img">
										<a href="<?php the_permalink();?>">
											<img src="<?php the_post_thumbnail_url();?>" alt="">
										</a>
									</div>
									<div class="txt">
										<h6 class="h7"><a href="<?php the_permalink();?>"><?php the_title();?></a></h6>
									</div>
								</div>
							<?php }
						}
						wp_reset_postdata();
						?>
					</div>
				<?php } elseif ($type == 'standart_list_first_big') { 
					$i = 0; ?>
					<div class="mag-item-1 type-4 sm">
						<?php while ( $query->have_posts() ) {
						$query->the_post(); 
							if ($i == 0) { ?>
								<div class="image img-info layer-hold">
									<div class="info-bar type-2">
										<?php
											nrg_premium_get_simple_likes_button(get_the_ID());
											$comments_count = wp_count_comments(get_the_ID());
											echo wp_kses_post( '<div><i class="fa fa-comment-o"></i><span>'.$comments_count->total_comments.'</span></div>' );
										?>
									</div>
									<div class="caption type-2">
										<h6 class="h6 title">
											<a href="<?php the_permalink();?>" class="text-line-animate sm">
												<?php the_title();?>
											</a>
										</h6>
									</div>
									<img src="<?php the_post_thumbnail_url();?>" alt="" class="resp-img">  
								</div>
								<div class="text">
							<?php } else { ?>
									<div class="item">
										<div class="img">
											<a href="<?php the_permalink(); ?>">
												<img src="<?php the_post_thumbnail_url();?>" alt="">
											</a>
										</div>
										<div class="txt">
											<h6 class="h7 sm"><a href="<?php the_permalink();?>"><?php the_title();?></a></h6>    
										</div>
									</div>
							<?php } 
						$i++;
						} ?>
							<a href="#" class="news-link"><?php echo esc_html__('view all posts', 'nrg_premium');?></a> 
						</div>
						<?php wp_reset_postdata();
						 ?>
					</div>
				<?php } elseif ($type == 'creative_list') { ?>
					<?php while ( $query->have_posts() ) {
					$query->the_post(); ?>
						<div class="mag-img-item flex-align">
							<div class="bg layer-hold type-2" style="background-image: url(<?php the_post_thumbnail_url();?>)"></div>
							<div class="caption type-2">
								<h6 class="h7 sm title">
									<a href="<?php the_permalink();?>" class="text-line-animate"><?php the_title();?></a>
								</h6>
								<div class="empty-sm-5 empty-xs-5"></div>
								<div class="sub-title sm col-2"><?php the_time(get_option('date_format')); ?></div>
							</div>
						</div>
					<?php }
					wp_reset_postdata();
					?>
				<?php } elseif ($type == 'creative_single') { ?>
					<?php while ( $query->have_posts() ) {
					$query->the_post(); ?>
						<?php if ($subtype_crea == 'wide') { ?>
							<div class="mag-item-1 type-img">
								<div class="bg layer-hold type-4" style="background-image: url(<?php the_post_thumbnail_url();?>)"></div> 
									<div class="text">
									<?php
										$term_list = get_the_terms(get_the_ID(), 'category' );
										if( $term_list ){
											echo '<div class="mag-item-cat-wr">';
											foreach( $term_list as $value ){
												$bg_color = '';
												$term_data = get_term_meta( $value->term_id, '_custom_category_options', true );
												if(isset($term_data['post_cat_color'])){
													$bg_color = 'style="background-color:'.$term_data['post_cat_color'].';"';
												}
												echo '<div class="mag-item-cat '.($cat_type=="type_2"?"type-2": "").'" '.($cat_type=="type_1"?"$bg_color": "").'><a href="'.get_term_link($value->term_id).'">'.$value->name.'</a></div>';
											}
											echo '</div>';
										}
									?>
									<div class="empty-sm-30 empty-xs-30"></div>
									<div class="sub-title sm col-2"><i><?php the_time(get_option('date_format')); ?></i></div>
									<div class="caption type-2">
										<h3 class="h5 title">
											<a href="<?php the_permalink();?>" class="text-line-animate"><?php the_title(); ?></a>
										</h3>
									</div>
									<div class="empty-sm-15 empty-xs-15"></div>
									<div class="simple-text sm col-6">
										<p><?php echo wp_trim_words( get_the_excerpt(), 25, ' ...' ); ?></p>
									</div>
								</div>
							</div>
						<?php } elseif ($subtype_crea == 'big_tall') { ?>
							<div class="mag-item min-h-md item-type-2">
								<div class="bg layer-hold type-4" style="background-image: url(<?php the_post_thumbnail_url();?>)"></div>
								<?php
									$term_list = get_the_terms(get_the_ID(), 'category' );
									if( $term_list ){
										echo '<div class="mag-item-cat-wr '.($cat_type=="type_2"?"type-2": "").'">';
										foreach( $term_list as $value ){
											$bg_color = '';
											$term_data = get_term_meta( $value->term_id, '_custom_category_options', true );
											if(isset($term_data['post_cat_color'])){
												$bg_color = 'style="background-color:'.$term_data['post_cat_color'].';"';
											}
											echo '<div class="mag-item-cat top '.($cat_type=="type_2"?"type-2": "").'" '.($cat_type=="type_1"?"$bg_color": "").'><a href="'.get_term_link($value->term_id).'">'.$value->name.'</a></div>';
										}
									echo '</div>';
									}
								?>
								<div class="mag-item-content">
									<div class="sub-title sm col-1"><i><?php the_time(get_option('date_format'));?></i></div>
									<div class="empty-sm-5 empty-xs-5"></div>
									<div class="caption type-2">
										<h3 class="h4 lg title no-tr">
											<a href="<?php the_permalink();?>" class="text-line-animate sm"><?php the_title();?></a>
										</h3>
									</div>
									<div class="empty-sm-15 empty-xs-15"></div>
									<div class="simple-text col-6">
										<p><?php echo wp_trim_words( get_the_excerpt(), 25, ' ...' ); ?></p>
									</div>
								</div>
							</div>
						<?php } elseif ($subtype_crea == 'small') { ?>
							<div class="mag-item-1 type-img min-sm-height">
								<div class="bg layer-hold type-4" style="background-image: url(<?php the_post_thumbnail_url();?>)"></div> 
								<div class="text">
									<div class="sub-title sm col-1">
										<i><?php the_time(get_option('date_format'));?></i>
									</div>
									<div class="empty-sm-10 empty-xs-10"></div>
									<div class="caption type-2">
										<h3 class="h5 sm title no-tr">
											<a href="<?php the_permalink();?>" class="text-line-animate sm "><?php the_title();?></a>
										</h3>
									</div>
									<?php
										$term_list = get_the_terms(get_the_ID(), 'category' );
										if( $term_list ){
											echo '<div class="mag-item-cat-wr bottom '.($cat_type=="type_2"?"type-2": "").'">';
												foreach( $term_list as $value ){
													$bg_color = '';
													$term_data = get_term_meta( $value->term_id, '_custom_category_options', true );
													if(isset($term_data['post_cat_color'])){
														$bg_color = 'style="background-color:'.$term_data['post_cat_color'].';"';
													}
													echo '<div class="mag-item-cat '.($cat_type=="type_2"?"type-2": "").'" '.($cat_type=="type_1"?"$bg_color": "").'><a href="'.get_term_link($value->term_id).'">'.$value->name.'</a></div>';
												}
											echo '</div>';
										}
									?>
								</div> 
							</div>
						<?php } elseif ($subtype_crea == 'tall') { ?>
							<div class="mag-item-1 min-md-height">
								<?php
									$term_list = get_the_terms(get_the_ID(), 'category' );
									if( $term_list ){
										echo '<div class="mag-item-cat-wr top '.($cat_type=="type_2"?"type-2": "").'">';
										foreach( $term_list as $value ){
											$bg_color = '';
											$term_data = get_term_meta( $value->term_id, '_custom_category_options', true );
											if(isset($term_data['post_cat_color'])){
												$bg_color = 'style="background-color:'.$term_data['post_cat_color'].';"';
											}
											echo '<div class="mag-item-cat top '.($cat_type=="type_2"?"type-2": "").'" '.($cat_type=="type_1"?"$bg_color": "").'><a href="'.get_term_link($value->term_id).'">'.$value->name.'</a></div>';
										}
									echo '</div>';
									}
								?>
								<div class="bg layer-hold type-4" style="background-image: url(<?php the_post_thumbnail_url();?>)"></div>
								<div class="mag-item-content">
									<div class="sub-title sm col-1"><i><?php the_time(get_option('date_format'));?></i></div>
									<div class="empty-sm-5 empty-xs-5"></div>
									<div class="caption type-2">
										<h3 class="h5 sm title no-tr">
											<a href="<?php the_permalink();?>" class="text-line-animate sm"><?php the_title();?></a>
										</h3>
									</div>
									<div class="empty-sm-15 empty-xs-15"></div>
									<div class="simple-text sm col-6">
										<p><?php echo wp_trim_words( get_the_excerpt(), 25, ' ...' ); ?></p>
									</div>
									<div class="empty-sm-30 empty-xs-30"></div>
									<div class="user-bar type-2">
										<?php echo get_avatar( get_the_author_meta( 'ID' ), 32 ); ?>
										<h6 class="h8 bold"><a href="<?php echo get_author_posts_url( get_the_ID(), get_the_author_meta( "user_nicename" ) ); ?>"><?php the_author(); ?></a></h6>
									</div> 
								</div>
							</div>
						<?php } elseif ($subtype_crea == 'tall_2') { ?>
							<div class="news-item lg flex-align text-center">   
								<div class="bg layer-hold type-4" style="background-image: url(<?php the_post_thumbnail_url();?>)"></div>
								<div class="caption type-2">
									<div class="sub-title sm col-2 second-font"><i><?php the_time(get_option('date_format'));?></i></div>
									<div class="empty-sm-5 empty-xs-5"></div>
									<h4 class="h4 lg title">
										<a href="<?php the_permalink();?>" class="text-line-animate"><?php the_title();?></a>
									</h4>
									<div class="empty-sm-15 empty-xs-15"></div>
									<div class="sub-title col-2"><i><p><?php echo wp_trim_words( get_the_excerpt(), 25, ' ...' ); ?></p></i></div>
									<div class="empty-sm-35 empty-xs-30"></div>
									<div class="user-bar">
										<?php echo get_avatar( get_the_author_meta( 'ID' ), 32 ); ?>
										<h6 class="h8 title"><a href="<?php echo get_author_posts_url( get_the_ID(), get_the_author_meta( "user_nicename" ) ); ?>"><?php the_author(); ?></a></h6>
									</div>
								</div>
							</div>
						<?php } elseif ($subtype_crea == 'tall_no_author') { ?>
							<div class="mag-item min-h-sm">
								<div class="bg layer-hold type-4" style="background-image: url(<?php the_post_thumbnail_url();?>)"></div>
								<div class="info-bar type-2 top-align">
									<?php
										nrg_premium_get_simple_likes_button(get_the_ID());
										$comments_count = wp_count_comments(get_the_ID());
										echo wp_kses_post( '<div><i class="fa fa-comment-o"></i><span>'.$comments_count->total_comments.'</span></div>' );
									?>
								</div>
								<div class="mag-item-content">
									<div class="sub-title sm col-2"><i><?php the_time(get_option('date_format'));?></i></div>
									<div class="empty-sm-5 empty-xs-5"></div>
									<div class="caption type-2">
										<h3 class="h6 title">
											<a href="<?php the_permalink();?>" class="text-line-animate"><?php the_title();?></a>
										</h3>
									</div>
									<div class="empty-sm-15 empty-xs-15"></div>
									<div class="simple-text col-6 sm">
										<p><i><p><?php echo wp_trim_words( get_the_excerpt(), 25, ' ...' ); ?></p></i></p>
									</div>
								</div>
							</div>
						<?php } elseif ($subtype_crea == 'wide_author') { ?>
							<div class="news-item md border-b flex-align text-center"> 
								<div class="bg layer-hold" style="background-image: url(<?php the_post_thumbnail_url();?>)"></div>  
								<div class="caption type-2">


									<?php
									$term_list = get_the_terms(get_the_ID(), 'category' );
									if( $term_list ){
										foreach( $term_list as $value ){
											$bg_color = '';
											$term_data = get_term_meta( $value->term_id, '_custom_category_options', true );
											if(isset($term_data['post_cat_color'])){
												$bg_color = 'style="background-color:'.$term_data['post_cat_color'].';"';
											}
											echo '<div class="sub-title mdx col-2" '.($cat_type=="type_1"?"$bg_color": "").'><a href="'.get_term_link($value->term_id).'">'.$value->name.'</a></div>';
										}
									}
								?>
									<div class="empty-sm-5 empty-xs-5"></div>
									<h4 class="h4 title">
										<a href="<?php the_permalink();?>" class="text-line-animate"><?php the_title ();?></a>
									</h4>
									<div class="empty-sm-15 empty-xs-15"></div>
									<div class="user-bar type-2">
										<?php echo get_avatar( get_the_author_meta( 'ID' ), 32 ); ?>
										<h6 class="h8 title"><a href="<?php echo get_author_posts_url( get_the_ID(), get_the_author_meta( "user_nicename" ) ); ?>"><?php the_author(); ?></a></h6>
									</div>
								</div>
							</div>  
						<?php } ?>
					<?php }
					wp_reset_postdata();
					?>
				<?php } elseif ($type == 'standart_img_gall') { ?>
					<?php while ( $query->have_posts() ) {
					$query->the_post(); ?>
						<div class="mag-item-1">
							<div class="image">
								<div class="swiper-container" data-mode="horizontal" data-autoplay="0" data-effect="slide" data-slides-per-view="1" data-loop="0" data-speed="800" >
									<div class="swiper-wrapper">
										<div class="swiper-slide">
											<div class="video-open">
												<img src="<?php the_post_thumbnail_url();?>" alt="">
												<div class="play-button sm" data-video="https://www.youtube.com/embed/REqZelREwM8?autoplay=1">
													<i class="fa fa-play"></i>
												</div>
												<div class="video-item">
													<div class="video-wrapper">
														<div class="video-iframe"></div>
														<div class="close close-video"><span>+</span></div>
													</div>
												</div>
											</div>
										</div>
					
										<div class="swiper-slide">
											<img src="<?php the_post_thumbnail_url();?>" alt="">
										</div>
										<div class="swiper-slide">
											<img src="<?php the_post_thumbnail_url();?>" alt="">
										</div>
										<div class="swiper-slide">
											<img src="<?php the_post_thumbnail_url();?>" alt="">
										</div>
									</div>
									<div class="pagination type-2 align-left-bottom colo-type-5"></div>
								</div> 
							</div>
							<div class="text">
								<?php
									$term_list = get_the_terms(get_the_ID(), 'category' );
									if( $term_list ){
										foreach( $term_list as $value ){
											$bg_color = '';
											$term_data = get_term_meta( $value->term_id, '_custom_category_options', true );
											if(isset($term_data['post_cat_color'])){
												$bg_color = 'style="background-color:'.$term_data['post_cat_color'].';"';
											}
											echo '<div class="mag-item-cat '.($cat_type=="type_2"?"type-2": "").'" '.($cat_type=="type_1"?"$bg_color": "").'><a href="'.get_term_link($value->term_id).'">'.$value->name.'</a></div>';
										}
									}
								?>
								<div class="empty-sm-20 empty-xs-20"></div>
								<div class="caption">
									<h3 class="h3 title">
										<a href="<?php the_permalink();?>" class="text-line-animate"><?php the_title();?></a>
									</h3>
								</div>
								<div class="empty-sm-25 empty-xs-25"></div>
								<div class="simple-text sm col-1">
									<p><?php echo wp_trim_words( get_the_excerpt(), 25, ' ...' ); ?></p>
								</div> 
							</div> 
						</div>
					<?php }
					wp_reset_postdata();
					?>
				<?php } elseif ($type == 'most_viwed') { ?>
					<?php while ( $query->have_posts() ) {
					$query->the_post(); ?>
						<div class="news-item md border-b flex-align text-center hover-bg"> 
							<div class="bg" style="background-image: url(<?php the_post_thumbnail_url();?>)"></div>  
							<div class="caption">
								<div class="sub-title mdx col-9"><i><?php echo esc_html__('Most Viwed', 'nrg_premium') ?></i></div>
								<div class="empty-sm-5 empty-xs-5"></div>
								<h4 class="h4 title"><a href="<?php the_permalink();?>" class="text-line-animate"><?php the_title();?></a></h4>
								<div class="empty-sm-15 empty-xs-15"></div>
								<div class="sub-title sm col-13 second-font"><i><?php the_time(get_option('date_format')); ?></i></div>
							</div>
						</div>
					<?php }
					wp_reset_postdata();
					?>
				<?php } elseif ($type == 'most_comented') { ?>
					<?php while ( $query->have_posts() ) {
					$query->the_post(); ?>
						<div class="news-item md border-b flex-align text-center hover-bg"> 
							<div class="bg" style="background-image: url(<?php the_post_thumbnail_url();?>)"></div>
							<div class="caption">
								<div class="sub-title mdx col-9"><i><?php echo esc_html__('Most Comment', 'nrg_premium') ?></i></div>
								<div class="empty-sm-5 empty-xs-5"></div>
								<h4 class="h4 title"><a href="<?php the_permalink();?>" class="text-line-animate"><?php the_title();?></a></h4>
								<div class="empty-sm-20 empty-xs-20"></div>
								<div class="info-bar">
									<?php
										nrg_premium_get_simple_likes_button(get_the_ID());
										$comments_count = wp_count_comments(get_the_ID());
										echo wp_kses_post( '<div><i class="fa fa-comment-o"></i><span>'.$comments_count->total_comments.'</span></div>' );
									?>
								</div>
							</div>
						</div>
					<?php }
					wp_reset_postdata();
					?>
				<?php } ?>
			</div>
		<?php }
		return  ob_get_clean();
	}
}