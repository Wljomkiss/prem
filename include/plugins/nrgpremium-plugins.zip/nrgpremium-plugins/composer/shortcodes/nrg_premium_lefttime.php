<?php 
/*
** Left time
** Author: NRGTHEMES
** Author URI: http://nrgthemes.com
** Version: 1.0.0 
*/

vc_map( array(
	'name'						=> __( 'Left Time', 'nrg_premium' ),
	'base'						=> 'nrg_premium_left_time_sh',
	'category'					=> __( 'NRGPremium', 'nrg_premium' ),
	'content_element'			=> true,
	'show_settings_on_create'	=> true,
	'description'				=> __( 'Time left shortcode', 'nrg_premium' ),
	'params'					=> array(
		array(
			'type'			=> 'dropdown',
			'heading'		=> __( 'Color type', 'nrg_premium' ),
			'param_name'	=> 'color_type',
			'value'			=> array(
				'Dark'			=> 'dark',
				'Light'			=> 'light',
			),
		),
		array(
			'type'			=> 'textfield',
			'heading'		=> 'Title',
			'param_name'	=> 'title',
			'admin_label'	=> true,
			'value'			=> '',
		),
		array(
			'type'			=> 'textfield',
			'heading'		=> 'Subtitle',
			'param_name'	=> 'subtitle',
			'value'			=> '',
		),
		array(
			'type'			=> 'textarea',
			'heading'		=> 'Short description',
			'param_name'	=> 'short_desc',
			'value'			=> '',
		),
		array(
			'type'			=> 'colorpicker',
			'heading'		=> __( 'Background color', 'nrg_premium' ),
			'param_name'	=> 'bg_col',
			'value'			=> '',
			'group'			=> 'Counter',
		),
		array(
			'type'			=> 'colorpicker',
			'heading'		=> __( 'Color', 'nrg_premium' ),
			'param_name'	=> 'col',
			'value'			=> '',
			'group'			=> 'Counter',
		),
		array(
			'type'			=> 'textfield',
			'heading'		=> __( 'Final date', 'nrg_premium' ),
			'param_name'	=> 'f_date',
			'value'			=> '',
			'description'	=> __( 'Write final date like "Sep,1,2018"', 'nrg_premium' ),
			'group'			=> 'Counter',
		),
		array(
			'type'			=> 'textfield',
			'heading'		=> __( 'Extra class name', 'nrg_premium' ),
			'param_name'	=> 'el_class',
			'description'	=> __( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'nrg_premium' ),
			'value'			=> '',
		),
		array(
			'type'			=> 'css_editor',
			'heading'		=> __( 'CSS box', 'nrg_premium' ),
			'param_name'	=> 'css',
			'group'			=> __( 'Design options', 'nrg_premium' ),
		),
	) //end params
) );

class WPBakeryShortCode_nrg_premium_left_time_sh extends WPBakeryShortCode {
	protected function content( $atts, $content = null) {

		extract( shortcode_atts( array(
			'el_class'		=> '',
			'css'			=> '',
			'title'			=> '',
			'subtitle'		=> '',
			'short_desc'	=> '',
			'color_type'	=> 'dark',
			'bg_col'		=> '',
			'col'			=> '',
			'f_date'		=> '',

 		), $atts ) );

		$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, $this->settings['base'], $atts );
		
		// custum css
		$css_class .= vc_shortcode_custom_css_class( $css, ' ' );

		// custum class
		$css_class .= (!empty($el_class)) ? ' '.$el_class : '';

 		// output
		ob_start();
		do_shortcode( $content ); 
		//--Button--//
		?>
		<div class="<?php print esc_attr( $css_class ); ?>">	
			<div class="caption text-center <?php echo ($color_type == 'light' ? 'type-2' : '');?>">
				<?php if ($subtitle) { ?>
					<div class="sub-title <?php echo ($color_type == 'light' ? 'col-1' : '');?> ls tt"><?php echo esc_html($subtitle); ?></div>
					<div class="empty-sm-5 empty-xs-5"></div> 
				<?php } 
				if ($title) { ?>
					<h2 class="h3 title"><?php echo esc_html($title); ?></h2>
				<?php }
				if ($short_desc) { ?>
					<div class="empty-sm-10 empty-xs-10"></div> 
					<div class="simple-text second-font <?php echo ($color_type == 'light' ? 'col-3' : '');?> md">
						<p><i><?php echo wp_kses_post($short_desc); ?></i></p>
					</div>
				<?php } ?>
				<div class="empty-sm-50 empty-xs-40"></div>
				<?php if (isset($f_date) && $f_date) { ?>
					<div class="countdown countdown-type-3" data-line="0.03" data-end="<?php echo $f_date; ?>" data-fgcolor="<?php echo (isset($shortcode_atts['f_date']) ? esc_html($shortcode_atts['f_date']) : '#e37420');?>" data-bgcolor="<?php echo (isset($shortcode_atts['bg_col']) ? esc_html($shortcode_atts['bg_col']) : 'rgba(255,255,255,0.1)');?>">
					</div>
				<?php } ?>
			</div>
			<div class="empty-lg-0 empty-md-0 empty-sm-60 empty-xs-40"></div>
		</div>
		<?php 
		return  ob_get_clean();
	}

}
