<?php 
/*
** Banner Slider
** Version: 1.0.0 
*/


vc_map( array(
	'name'                    => __( 'Banner with slider', 'nrg_premium' ),
	'base'                    => 'nrg_premium_banner_slider',
	'as_parent'               => array('only' => 'nrg_premium_banner_slider_item'),
	'content_element'         => true,
	'show_settings_on_create' => true,
	'category' 				  => __( 'NRGPremium', 'nrg_premium' ),
	'description'             => __( 'Banner with 1/3 right slider', 'nrg_premium'),
	'js_view'                 => 'VcColumnView',
	'params'          => array(
		array(
			'type'        => 'dropdown',
			'heading'     => __( 'Text slider align', 'nrg_premium' ),
			'param_name'  => 'text_align',
			'value'       => array(
				'Align left'   => 'align_left',
				'Align right'  => 'align_right',
				)
		),
		array(
			'type'        => 'attach_image',
			'heading'     => __( 'Image', "nrg_premium" ),
			'param_name'  => 'image',
			'admin_label' => true,
			'description' => 'Upload your image.'
		),
		array(
			'type' 		  => 'checkbox',
			'heading'	  => __( 'Paralax efect image', 'nrg_premium' ),
			'param_name'  => 'img_paralax',
		),
		array(
			'type'        => 'dropdown',
			'heading'     => __( 'Main text', 'nrg_premium' ),
			'param_name'  => 'main_txt',
			'value'       => array(
				'Enable'   => 'enable',
				'Disable'  => 'disable',
			)
		),
		array(
			'type' 		  => 'checkbox',
			'heading'	  => __( 'Text border', 'nrg_premium' ),
			'param_name'  => 'txt_border',
			'dependency'  => array( 'element' => 'main_txt', 'value' => 'enable'),
		),
		array(
			'type'        => 'textfield',
			'heading'     => __( "Subtitle", "nrg_premium" ),
			'param_name'  => 'subtitle',
			'admin_label' => true,
			'value'       => '',
			'dependency'  => array( 'element' => 'main_txt', 'value' => 'enable'),
		),
		array(
			'type'        => 'textfield',
			'heading'     => __( "Title", "nrg_premium" ),
			'param_name'  => 'title',
			'admin_label' => true,
			'value'       => '',
			'dependency'  => array( 'element' => 'main_txt', 'value' => 'enable'),
		),
		array(
			'type'        => 'textarea',
			'heading'     => __( 'Short Description', 'nrg_premium' ),
			'param_name'  => 'short_desc',
			'dependency'  => array( 'element' => 'main_txt', 'value' => 'enable'),
		),
		array(
			'type' => 'textfield',
			'heading' => __( 'Extra class name', 'nrg_premium' ),
			'param_name' => 'el_class',
			'description' => __( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'nrg_premium' ),
			'value' => '',
		),
		array(
			'type' => 'css_editor',
			'heading' => __( 'CSS box', 'nrg_premium' ),
			'param_name' => 'css',
			'group' => __( 'Design options', 'nrg_premium' ),
		),
	) //end params
) );

class WPBakeryShortCode_nrg_premium_banner_slider extends WPBakeryShortCodesContainer {

	protected function content( $atts, $content = null) {

		extract( shortcode_atts( array(
			'el_class'     => '',
			'css'          => '',
			'image'        => '',
			'title'        => '',
			'subtitle'     => '',
			'short_desc'   => '',
			'content_desc' => '',
			'text_align'   => 'align_left',
			'txt_border'   => false,
			'main_txt'	   => 'enable',
			'img_paralax'  => false,
		
		), $atts ) );


		$no_border = '';
		if ($txt_border == false) {
			$no_border = 'no-txt-border';
		}

		$image_align = '';
		if ($text_align == 'align_left') {
			$image_align = 'offset-33';
		} else {
			$image_align = 'offset-33-right';
		}

		$img_paralax_n = '';
		if ($img_paralax == true ) {
			$img_paralax_n = 'fix ';
		}

		$image_html = '';
		if ($image) {
			$image_full = wp_get_attachment_image_url( $image, 'full' );
			$image_html = '<div class="bg layer-hold hide-mobile' .esc_html($img_paralax_n) .' '. esc_html($image_align) .'" style="background-image: url('. esc_url( $image_full ).')"></div>';
		}


		global $_banner_sliders_items;
		$_banner_sliders_items = array();

		$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, $this->settings['base'], $atts );

		// custum css
		$css_class .= vc_shortcode_custom_css_class( $css, ' ' );

		// custum class
		$css_class .= (!empty($el_class)) ? ' '.$el_class : '';
		
		// output
		ob_start();
		do_shortcode( $content );
		?>
		<div class="section <?php print esc_attr( $css_class ); ?>">
			<?php print $image_html; ?>
			<div class="vertical-wrap col-no-padding step-section">
				<?php if ($text_align == 'align_left') {
					if ($_banner_sliders_items) { ?>
						<div class="col-md-4 col-sm-12 col-xs-12">
							<div class="arrow-closest styled-block">
								<div class="swiper-container full-h step-slider" data-mode="horizontal" data-autoplay="0" data-effect="slide" data-slides-per-view="1" data-loop="0" data-speed="800">
									<div class="swiper-wrapper">
										<?php 
											foreach ($_banner_sliders_items as $key => $shortcode):
											$shortcode_atts = $shortcode['atts'];
											$icon_html = '';
											if (isset($shortcode_atts['icon'])) {
												$icon_full = wp_get_attachment_image_url( $shortcode_atts['icon'], 'full' );
												$icon_html = '<img src="'. esc_url( $icon_full ).'" alt="icon"><div class="empty-sm-20 empty-xs-20"></div>';
											} ?>
											<div class="swiper-slide">
												<div class="empty-lg-140 empty-md-100 empty-sm-60 empty-xs-60"></div>
												<div class="caption type-2 text-center">
													<?php print $icon_html; ?>
													<?php if ($shortcode_atts['subtitle_sl']) { ?>
														<span class="sub-title col-2 sm"><?php print esc_html($shortcode_atts['subtitle_sl']); ?></span>
													<?php } ?>
													<?php if ($shortcode_atts['title_sl']){ ?>
														<div class="empty-sm-5 empty-xs-5"></div>
														<h4 class="h4 title"><?php print esc_html($shortcode_atts['title_sl']); ?></h4>
													<?php } ?>
													<div class="empty-sm-25 empty-xs-25"></div>
													<div class="title-separator-1"><span></span></div>
													<?php if ($shortcode_atts['content_desc']) { ?>
														<div class="empty-sm-30 empty-xs-30"></div>
														<div class="simple-text col-2">
															<p><?php print wp_kses_post($shortcode_atts['content_desc']); ?></p>
														</div>
													<?php } ?>
													<?php $button_link = vc_build_link($shortcode_atts['button_url']);
														if($shortcode_atts['button_title'] && $button_link) { ?>
														<div class="empty-sm-35 empty-xs-30"></div>
														<a href="<?php print esc_html($button_link['url']); ?>" class="main-link link-style-1 type-3"><span><?php print esc_html($shortcode_atts['button_title']); ?></span></a>
													<?php }?>
												</div>
												<div class="empty-lg-200 empty-md-100 empty-sm-40 empty-xs-40"></div>       
											</div>
										<?php endforeach; ?>
									</div>
									<div class="pagination"></div>
								</div>
							</div> 
						</div>
					<?php } 
				} ?>
				<div class="col-md-8 col-sm-12 col-xs-12">
					<?php if ($main_txt == 'enable') { ?>
						<div class="style-caption-1 type-2 style-1 <?php print esc_html($no_border); ?>">
							<div class="empty-sm-100 empty-xs-80"></div>
							<div class="empty-sm-20 empty-xs-20"></div>
							<?php if ($subtitle) { ?>
								<span class="sub-title col-1"><?php print esc_html($subtitle) ?></span>
							<?php }; 
							if ($title){ ?>
								<div class="empty-sm-10 empty-xs-10"></div>
								<h2 class="h2 title"><?php print esc_html($title) ?></h2>
							<?php }; 
							if ($short_desc){ ?>
								<div class="empty-sm-15 empty-xs-15"></div>
								<div class="simple-text col-3 md">
									<p><?php print wp_kses_post($short_desc); ?></p>
								</div>
							<?php } ?>
							<div class="empty-sm-20 empty-xs-20"></div>      
							<div class="empty-sm-100 empty-xs-80"></div>
						</div> 
					<?php } ?>
				</div>
				<?php if ($text_align == 'align_right') { ?>
					<?php if ($_banner_sliders_items) { ?>
						<div class="col-md-4 col-sm-12 col-xs-12">
							<div class="arrow-closest styled-block">
								<div class="swiper-container full-h step-slider" data-mode="horizontal" data-autoplay="0" data-effect="slide" data-slides-per-view="1" data-loop="0" data-speed="800">
									<div class="swiper-wrapper">
										<?php 
											// $shortcode_atts['content_desc'] = '';
											foreach ($_banner_sliders_items as $key => $shortcode):
											$shortcode_atts = $shortcode['atts'];
											$icon_html = '';
											if (isset($shortcode_atts['icon'])) {
												$icon_full = wp_get_attachment_image_url( $shortcode_atts['icon'], 'full' );
												$icon_html = '<img src="'. esc_url( $icon_full ).'" alt="icon"><div class="empty-sm-20 empty-xs-20"></div>';
											} ?>
											<div class="swiper-slide">
												<div class="empty-lg-140 empty-md-100 empty-sm-60 empty-xs-60"></div>
												<div class="caption type-2 text-center">
													<?php print $icon_html; ?>
													<?php if ($shortcode_atts['subtitle_sl']) { ?>
														<span class="sub-title col-2 sm"><?php print esc_html($shortcode_atts['subtitle_sl']); ?></span>
													<?php } ?>
													<?php if ($shortcode_atts['title_sl']){ ?>
														<div class="empty-sm-5 empty-xs-5"></div>
														<h4 class="h4 title"><?php print esc_html($shortcode_atts['title_sl']); ?></h4>
													<?php } ?>
													<div class="empty-sm-25 empty-xs-25"></div>
													<div class="title-separator-1"><span></span></div>
													<?php if ($shortcode_atts['content_desc']) { ?>
														<div class="empty-sm-30 empty-xs-30"></div>
														<div class="simple-text col-2">
															<p><?php print wp_kses_post($shortcode_atts['content_desc']); ?></p>
														</div>
													<?php } ?>
													<?php $button_link = vc_build_link($shortcode_atts['button_url']);
														if($shortcode_atts['button_title'] && $button_link) { ?>
														<div class="empty-sm-35 empty-xs-30"></div>
														<a href="<?php print esc_html($button_link['url']); ?>" class="main-link link-style-1 type-3"><span><?php print esc_html($shortcode_atts['button_title']); ?></span></a>
													<?php }?>
												</div>
												<div class="empty-lg-200 empty-md-100 empty-sm-40 empty-xs-40"></div>       
											</div>
										<?php endforeach; ?>
									</div>
									<div class="pagination"></div>
								</div>
							</div> 
						</div>
					<?php }
				} ?>
			</div>
			<div class="col-60">
			</div>
		</div> 
		<?php 
		return  ob_get_clean();
	}

}
/* Shortvode Item */

vc_map( array(
  'name'            => 'Banner with slider item',
  'base'            => 'nrg_premium_banner_slider_item',
  'as_child' 		=> array('only' => 'nrg_premium_banner_slider'),
  'content_element' => true,
  'show_settings_on_create' => true,
  'description'     => 'Image, title and text',
  'params'          => array(
		array(
			'type'        => 'attach_image',
			'heading'     => __( 'Icon', 'nrg_premium' ),
			'param_name'  => 'icon',
			'admin_label' => true,
			'description' => 'Upload your image.'
		),
		array(
			'type'			=> 'dropdown',
			'heading'		=> __( 'Button width', 'nrg_premium' ),
			'param_name'	=> 'b_width',
			'value'			=> array(
				'Standart'		=> 'standart',
				'Small'			=> 'small',
			),
		),
		array(
			'type'			=> 'colorpicker',
			'class'			=> '',
			'heading'		=> __( 'Main color', 'nrg_premium' ),
			'param_name'	=> 'm_color',
			'value'			=> '#84694e',
		),
		array(
			'type'        => 'textfield',
			'heading'     => __( 'Title', 'nrg_premium' ),
			'param_name'  => 'title_sl',
			'admin_label' => true,
			'value'       => '',
		),
		array(
			'type'        => 'textfield',
			'heading'     => __( 'Subtitle', 'nrg_premium' ),
			'param_name'  => 'subtitle_sl',
			'admin_label' => true,
			'value'       => '',
		),
		array(
			'type'        => 'textarea',
			'heading'     => __( 'Short Description', 'nrg_premium' ),
			'param_name'  => 'content_desc',
		),
		array(
			'type'        => 'textfield',
			'heading'     => __( "Button title", "nrg_premium" ),
			'param_name'  => 'button_title',
			'admin_label' => true,
			'value'       => '',
		),
		array(
			'type'        => 'vc_link',
			'heading'     => __( "Button url", "nrg_premium" ),
			'param_name'  => 'button_url',
			'admin_label' => true,
			'value'       => '#',
		),
	) //end params
) );


class WPBakeryShortCode_nrg_premium_banner_slider_item extends WPBakeryShortCode{
	protected function content( $atts, $content = null ) {

		global $_banner_sliders_items;
		$atts['b_width'] = 'standart';
		$atts['m_color'] = '#84694e';
		$_banner_sliders_items[] = array( 'atts' => $atts, 'content' => $content, 'css_class' => '');
		return;
	}
}