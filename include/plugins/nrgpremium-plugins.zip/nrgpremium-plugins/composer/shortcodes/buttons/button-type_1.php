<?php 

$button_link  = vc_build_link($template_args['but_url']);
$button_class = uniqid('button-');
if ($template_args['title'] && $button_link) { ?>
	<div class=" <?php echo esc_html($template_args['but_align']); ?>">
		<a href="<?php echo esc_html($button_link['url'])?>" class="main-link link-style-1 <?php echo $button_class.' '.($template_args['but_width']=='small' ? 'wh-md': ''); ?>" data-text="<?php echo esc_html($template_args['title'])?>"><span <?php echo ( isset($template_args['main_color']) && $template_args['main_color'] ? 'style="color:'.$template_args['main_color'].';"' : '' ); ?>><?php echo esc_html($template_args['title'])?></span></a>
	</div>

<?php }
$custom_css = '';
if( isset($template_args['main_color']) && $template_args['main_color'] ){
	$custom_css.= '.'.$button_class.'.link-style-1:before {border-color:'.$template_args['main_color'].';}';
	$custom_css.= '.'.$button_class.'.link-style-1:after {background:'.$template_args['main_color'].';}';
	$custom_css.= '.'.$button_class.'.link-style-1 span {color: '.$template_args['main_color'].' !important;}';
	$custom_css.= '.'.$button_class.'.link-style-1:hover span {color: #fff !important;}';
}
if( $custom_css ){ ?>
<style type="text/css"><?php echo $custom_css; ?></style>
<?php } 