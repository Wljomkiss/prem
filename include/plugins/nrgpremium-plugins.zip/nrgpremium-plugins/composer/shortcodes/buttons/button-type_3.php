<?php 

$button_link = vc_build_link($template_args['but_url']);
$button_class = uniqid('button-');
if ($template_args['title'] && $button_link) { ?>
	<div class=" <?php print esc_html($template_args['but_align']); ?>">
		<a href="<?php print esc_html($button_link['url'])?>" class="main-link link-style-1 type-4 <?php echo $button_class?> <?php echo ($template_args['but_width']=='small' ? 'wh-md': ''); ?>" data-text="<?php print esc_html($template_args['title'])?>"><span><?php print esc_html($template_args['title'])?></span></a>
	</div>
<?php }
	$custom_css = '';
	if( isset($template_args['main_color']) && $template_args['main_color'] ){
		$custom_css.= '.'.$button_class.'.link-style-1.type-4:hover span{color:'.$template_args['main_color'].'!important;}';
		$custom_css.= '.'.$button_class.'.link-style-1.type-4:before{border-color:'.$template_args['main_color'].';}';
		$custom_css.= '.'.$button_class.'.link-style-1.type-4:after{background:'.$template_args['main_color'].';}';
	}
	if( $custom_css ){echo '<style type="text/css">'.$custom_css.'</style>';}