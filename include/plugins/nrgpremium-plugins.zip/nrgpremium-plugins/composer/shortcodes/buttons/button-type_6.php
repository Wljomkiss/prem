<?php 

$button_link = vc_build_link($template_args['but_url']);
$button_class = uniqid('button-');
if ($template_args['title'] && $button_link) { ?>
	<div class=" <?php print esc_html($template_args['but_align']); ?>">
		<a href="<?php print esc_html($button_link['url'])?>" class="main-link link-style-5 wh-lg <?php echo $button_class;?>" data-text="<?php print esc_html($template_args['title'])?>"><span><?php print esc_html($template_args['title'])?></span></a>
	</div>

<?php }
	$custom_css = '';
	$custom_css.= '.'.$button_class.'.link-style-5:before{background:'.$template_args['main_color'].';}';
?>
<style type="text/css"><?php echo $custom_css; ?></style>