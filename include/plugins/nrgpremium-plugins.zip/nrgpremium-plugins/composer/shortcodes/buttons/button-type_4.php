<?php 
$button_link = vc_build_link($template_args['but_url']);
$button_class = uniqid('button-');
if ($template_args['title'] && $button_link) { ?>
	<div class=" <?php print esc_html($template_args['but_align']); ?>">
		<a href="<?php print esc_html($button_link['url'])?>" class="main-link link-style-7 <?php echo $button_class;?>" data-text="<?php print esc_html($template_args['title'])?>"><span><?php print esc_html($template_args['title'])?></span></a>
	</div>

<?php }
	$custom_css = '';
	$custom_css.= '.'.$button_class.'.link-style-7:hover{color:'.$template_args['main_color'].';}';
	$custom_css.= '.'.$button_class.'.link-style-7{border-color:'.$template_args['main_color'].';}';
	$custom_css.= '.'.$button_class.'.link-style-7:before{border-color:'.$template_args['main_color'].';}';
?>
<style type="text/css"><?php echo $custom_css; ?></style>