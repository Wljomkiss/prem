<?php 
/*
** Proposals
** Author: NRGTHEMES
** Author URI: http://nrgthemes.com
** Version: 1.0.0 
*/

vc_map( array(
	'name'                    => __( 'Proposals', 'nrg_premium' ),
	'base'                    => 'nrg_premium_proposals',
	'category' 				  => __( 'NRGPremium', 'nrg_premium' ),
	'content_element'         => true,
	'show_settings_on_create' => true,
	'description' 		      => __( 'Add your proposals', 'nrg_premium' ),
	'params'          => array(
		array(
			'type'        => 'textfield',
			'heading'     => __( 'Main link title', "nrg_premium" ),
			'param_name'  => 'main_link_title',
			'admin_label' => true,
			'value'       => '',
		),
		array(
			'type'        => 'vc_link',
			'heading'     => __( 'Main link', "nrg_premium" ),
			'param_name'  => 'main_url',
			'admin_label' => true,
			'value'       => '#',
		),

		// Proposal 1
		array(
			'type'        => 'attach_image',
			'heading'     => __( "Proposal 1 image", "nrg_premium" ),
			'param_name'  => 'poroposal_1_image',
			'admin_label' => true,
			'description' => 'Upload your image.',
			'group'		  => __( "Proposal 1", "nrg_premium" ),
		),
		array(
			'type'        => 'vc_link',
			'heading'     => __( 'Proposal 1 link', "nrg_premium" ),
			'param_name'  => 'proposal_1_url',
			'admin_label' => true,
			'value'       => '#',
			'group'		  => __( "Proposal 1", "nrg_premium" ),
		),
		array(
			'type'        => 'textfield',
			'heading'     => __( 'Proposal 1 title', "nrg_premium" ),
			'param_name'  => 'proposal_1_title',
			'admin_label' => true,
			'value'       => '',
			'group'		  => __( "Proposal 1", "nrg_premium" ),
		),
		array(
			'type' => 'textarea',
			'heading' => __( 'Proposal 1 description', 'nrg_premium' ),
			'param_name' => 'proposal_1_desc',
			'group'		 => __( "Proposal 1", "nrg_premium" ),
		),

		// Proposal 2
		array(
			'type'        => 'attach_image',
			'heading'     => __( "Proposal 2 image", "nrg_premium" ),
			'param_name'  => 'poroposal_2_image',
			'admin_label' => true,
			'description' => 'Upload your image.',
			'group'		  => __( "Proposal 2", "nrg_premium" ),
		),
		array(
			'type'        => 'vc_link',
			'heading'     => __( 'Proposal 2 link', "nrg_premium" ),
			'param_name'  => 'proposal_2_url',
			'admin_label' => true,
			'value'       => '#',
			'group'		  => __( "Proposal 2", "nrg_premium" ),
		),
		array(
			'type'        => 'textfield',
			'heading'     => __( 'Proposal 2 title', "nrg_premium" ),
			'param_name'  => 'proposal_2_title',
			'admin_label' => true,
			'value'       => '',
			'group'		  => __( "Proposal 2", "nrg_premium" ),
		),
		array(
			'type' => 'textarea',
			'heading' => __( 'Proposal 2 description', 'nrg_premium' ),
			'param_name'  => 'proposal_2_desc',
			'group'		  => __( "Proposal 2", "nrg_premium" ),
		),

		// Proposal 3
		array(
			'type'        => 'attach_image',
			'heading'     => __( "Proposal 3 image", "nrg_premium" ),
			'param_name'  => 'poroposal_3_image',
			'admin_label' => true,
			'description' => 'Upload your image.',
			'group'		  => __( "Proposal 3", "nrg_premium" ),
		),
		array(
			'type'        => 'vc_link',
			'heading'     => __( 'Proposal 3 link', "nrg_premium" ),
			'param_name'  => 'proposal_3_url',
			'admin_label' => true,
			'value'       => '#',
			'group'		  => __( "Proposal 3", "nrg_premium" ),
		),
		array(
			'type'        => 'textfield',
			'heading'     => __( 'Proposal 3 title', "nrg_premium" ),
			'param_name'  => 'proposal_3_title',
			'admin_label' => true,
			'value'       => '',
			'group'		  => __( "Proposal 3", "nrg_premium" ),
		),
		array(
			'type' => 'textarea',
			'heading' => __( 'Proposal 3 description', 'nrg_premium' ),
			'param_name' => 'proposal_3_desc',
			'group'		  => __( "Proposal 3", "nrg_premium" ),
		),

		// Proposal 4
		array(
			'type'        => 'attach_image',
			'heading'     => __( "Proposal 4 image", "nrg_premium" ),
			'param_name'  => 'poroposal_4_image',
			'admin_label' => true,
			'description' => 'Upload your image.',
			'group'		  => __( "Proposal 4", "nrg_premium" ),
		),
		array(
			'type'        => 'vc_link',
			'heading'     => __( 'Proposal 4 link', "nrg_premium" ),
			'param_name'  => 'proposal_4_url',
			'admin_label' => true,
			'value'       => '#',
			'group'		  => __( "Proposal 4", "nrg_premium" ),
		),
		array(
			'type'        => 'textfield',
			'heading'     => __( 'Proposal 4 title', "nrg_premium" ),
			'param_name'  => 'proposal_4_title',
			'admin_label' => true,
			'value'       => '',
			'group'		  => __( "Proposal 4", "nrg_premium" ),
		),
		array(
			'type' => 'textarea',
			'heading' => __( 'Proposal 4 description', 'nrg_premium' ),
			'param_name' => 'proposal_4_desc',
			'group'		  => __( "Proposal 4", "nrg_premium" ),
		),




		array(
			'type' => 'textfield',
			'heading' => __( 'Extra class name', 'nrg_premium' ),
			'param_name' => 'el_class',
			'description' => __( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'nrg_premium' ),
			'value' => '',
		),
		array(
			'type' => 'css_editor',
			'heading' => __( 'CSS box', 'nrg_premium' ),
			'param_name' => 'css',
			'group' => __( 'Design options', 'nrg_premium' ),
		),
	) //end params
) );

class WPBakeryShortCode_nrg_premium_proposals extends WPBakeryShortCode {
	protected function content( $atts, $content = null) {

		extract( shortcode_atts( array(
			'el_class'			=> '',
			'css'				=> '',
			'main_link_title'	=> '',
			'main_url'			=> '',
			'poroposal_1_image'	=> '',
			'proposal_1_title'	=> '',
			'proposal_1_url'	=> '',
			'proposal_1_desc'	=> '',
			'poroposal_2_image'	=> '',
			'proposal_2_title'	=> '',
			'proposal_2_url'	=> '',
			'proposal_2_desc'	=> '',
			'poroposal_3_image'	=> '',
			'proposal_3_title'	=> '',
			'proposal_3_url'	=> '',
			'proposal_3_desc'	=> '',
			'poroposal_4_image'	=> '',
			'proposal_4_title'	=> '',
			'proposal_4_url'	=> '',
			'proposal_4_desc'	=> '',

 		), $atts ) );

		$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, $this->settings['base'], $atts );
		
		// custum css
		$css_class .= vc_shortcode_custom_css_class( $css, ' ' );

		// custum class
		$css_class .= (!empty($el_class)) ? ' '.$el_class : '';


		// IMAGES
		// proposal image 1
		$poroposal_1_image_html = '';
		if (!empty($poroposal_1_image)) {
			$poroposal_1_image_full = wp_get_attachment_image_url( $poroposal_1_image, 'full' );
			$poroposal_1_image_html = '<div class="bg layer-hold type-2 type-6" style="background-image: url('.esc_url( $poroposal_1_image_full ).')"></div>';
		}
		// proposal image 2
		$poroposal_2_image_html = '';
		if (!empty($poroposal_2_image)) {
			$poroposal_2_image_full = wp_get_attachment_image_url( $poroposal_2_image, 'full' );
			$poroposal_2_image_html = '<div class="bg layer-hold type-2 type-6" style="background-image: url('.esc_url( $poroposal_2_image_full ).')"></div>';
		}
		// proposal image 3
		$poroposal_3_image_html = '';
		if (!empty($poroposal_3_image)) {
			$poroposal_3_image_full = wp_get_attachment_image_url( $poroposal_3_image, 'full' );
			$poroposal_3_image_html = '<div class="bg layer-hold type-2 type-6" style="background-image: url('.esc_url( $poroposal_3_image_full ).')"></div>';
		}
		// proposal image 4
		$poroposal_4_image_html = '';
		if (!empty($poroposal_4_image)) {
			$poroposal_4_image_full = wp_get_attachment_image_url( $poroposal_4_image, 'full' );
			$poroposal_4_image_html = '<div class="bg layer-hold type-2 type-6" style="background-image: url('.esc_url( $poroposal_4_image_full ).')"></div>';
		}

		// LINKS
		$main_link = vc_build_link($main_url); 
		$proposal_1_link = vc_build_link($proposal_1_url);
		$proposal_2_link = vc_build_link($proposal_2_url);
		$proposal_3_link = vc_build_link($proposal_3_url);
		$proposal_4_link = vc_build_link($proposal_4_url);


		// output
		ob_start();
		do_shortcode( $content );
		?>
		<!--CONTACT INFO-->
		<div class="<?php print esc_attr( $css_class ); ?>">
			<div class="relative-wrap">
				<div class="col-50 col-md-100">
					<div class="special-item hover-block">
						<?php echo $poroposal_1_image_html ?>
						<?php if ($proposal_1_link) {?>  
							<a href="<?php echo esc_html($proposal_1_link['url'])?>" class="hover-layer-2">
								<div class="vertical-align full">
									<?php if ($proposal_1_title || $proposal_1_desc) {?>
										<div class="caption type-2 text-center">
											<?php if ($proposal_1_title) { ?>
												<h4 class="h4 title"><?php echo esc_html($proposal_1_title);?></h4>
												<div class="empty-sm-10 empty-xs-10"></div>
											<?php } 
											if ($proposal_1_desc) { ?>
												<div class="simple-text col-3">
													<p><?php echo wp_kses_post($proposal_1_desc);?></p>
												</div>
											<?php } ?>
										</div>
										<?php } ?>
								</div>
							</a>
						<?php } ?> 
					</div> 
				</div>
				<div class="col-50 col-md-100">
					<div class="special-item hover-block">
						<?php echo $poroposal_2_image_html ?>  
						<?php if ($proposal_2_link) {?>  
							<a href="<?php echo esc_html($proposal_2_link['url'])?>" class="hover-layer-2">
								<div class="vertical-align full">
									<?php if ($proposal_2_title || $proposal_2_desc) {?>
										<div class="caption type-2 text-center">
											<?php if ($proposal_2_title) { ?>
												<h4 class="h4 title"><?php echo esc_html($proposal_2_title);?></h4>
												<div class="empty-sm-10 empty-xs-10"></div>
											<?php } 
											if ($proposal_2_desc) { ?>
												<div class="simple-text col-3">
													<p><?php echo wp_kses_post($proposal_2_desc);?></p>
												</div>
											<?php } ?>
										</div>
										<?php } ?>
								</div>
							</a>
						<?php } ?>
					</div> 
				</div>
				<div class="col-50 col-md-100">
					<div class="special-item hover-block">
						<?php echo $poroposal_3_image_html ?>  
						<?php if ($proposal_3_link) {?>  
							<a href="<?php echo esc_html($proposal_3_link['url'])?>" class="hover-layer-2">
								<div class="vertical-align full">
									<?php if ($proposal_3_title || $proposal_3_desc) {?>
										<div class="caption type-2 text-center">
											<?php if ($proposal_3_title) { ?>
												<h4 class="h4 title"><?php echo esc_html($proposal_3_title);?></h4>
												<div class="empty-sm-10 empty-xs-10"></div>
											<?php } 
											if ($proposal_3_desc) { ?>
												<div class="simple-text col-3">
													<p><?php echo wp_kses_post($proposal_3_desc);?></p>
												</div>
											<?php } ?>
										</div>
										<?php } ?>
								</div>
							</a>
						<?php } ?>
					</div>
				</div>
				<div class="col-50 col-md-100">
					<div class="special-item hover-block">
						<?php echo $poroposal_4_image_html ?>  
						<?php if ($proposal_4_link) {?>  
							<a href="<?php echo esc_html($proposal_4_link['url'])?>" class="hover-layer-2">
								<div class="vertical-align full">
									<?php if ($proposal_4_title || $proposal_4_desc) {?>
										<div class="caption type-2 text-center">
											<?php if ($proposal_4_title) { ?>
												<h4 class="h4 title"><?php echo esc_html($proposal_4_title);?></h4>
												<div class="empty-sm-10 empty-xs-10"></div>
											<?php } 
											if ($proposal_4_desc) { ?>
												<div class="simple-text col-3">
													<p><?php echo wp_kses_post($proposal_4_desc);?></p>
												</div>
											<?php } ?>
										</div>
										<?php } ?>
								</div>
							</a>
						<?php } ?>
					</div> 
				</div>
				<?php if ($main_link_title && $main_url) {?>
					<a href="<?php echo esc_html($main_link['url'])?>" class="center-all-special flex-align">
						<span><?php print esc_html($main_link_title)?></span>
					</a>
				<?php } ?>
			</div>
		</div>
		<?php 
		return  ob_get_clean();
	}
}