<?php 
/*
** Sale banner
** Author: NRGTHEMES
** Author URI: http://nrgthemes.com
** Version: 1.0.0 
*/

vc_map( array(
	'name'                    => __( 'Sale banner', 'nrg_premium' ),
	'base'                    => 'nrg_premium_sale_banner',
	'category' 				  => __( 'NRGPremium', 'nrg_premium' ),
	'content_element'         => true,
	'show_settings_on_create' => true,
	'description' 		      => __( 'Sale mini banner', 'nrg_premium' ),
	'params'          => array(
		array(
			'type'        => 'attach_image',
			'heading'     => __( "Image", "nrg_premium" ),
			'param_name'  => 'image',
			'admin_label' => true,
			'description' => 'Upload your image.'
		),
		array(
			'type'        => 'textfield',
			'heading'     => 'Subtitle',
			'param_name'  => 'subtitle',
			'admin_label' => true,
			'value'       => '',
		),
		array(
			'type'        => 'textfield',
			'heading'     => 'Title',
			'param_name'  => 'title',
			'admin_label' => true,
			'value'       => '',
		),
		array(
			'type' 		  => 'textarea',
			'heading'	  => __( 'Short Description', 'nrg_premium' ),
			'param_name'  => 'short_desc',
		),
		array(
			'type' => 'textfield',
			'heading' => __( 'Extra class name', 'nrg_premium' ),
			'param_name' => 'el_class',
			'description' => __( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'nrg_premium' ),
			'value' => '',
		),
		array(
			'type' => 'css_editor',
			'heading' => __( 'CSS box', 'nrg_premium' ),
			'param_name' => 'css',
			'group' => __( 'Design options', 'nrg_premium' ),
		),
	) //end params
) );

class WPBakeryShortCode_nrg_premium_sale_banner extends WPBakeryShortCode {
	protected function content( $atts, $content = null) {

		extract( shortcode_atts( array(
			'el_class'      => '',
			'css'           => '',
			'image'	 		=> '',
			'title' 		=> '',
			'subtitle'    	=> '',
			'short_desc'	=> '',

 		), $atts ) );

		$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, $this->settings['base'], $atts );
		
		// custum css
		$css_class .= vc_shortcode_custom_css_class( $css, ' ' );

		// custum class
		$css_class .= (!empty($el_class)) ? ' '.$el_class : '';

		$image_html = '';
		if ($image) {
			$image_full = wp_get_attachment_image_url( $image, 'full' );
			$image_html = '<div class="bg" style="background-image: url('.esc_url( $image_full ).')"></div>';
		}
 		// output
		ob_start();
		do_shortcode( $content );
		?>
		<!--Sale banner-->
		<div class="<?php print esc_attr( $css_class ); ?>">
			<div class="promo-item-1 flex-align">
				<?php print $image_html ?>
				<?php if ($subtitle || $title || $short_desc) { ?>
					<div class="custome-padd-100">
						<div class="caption text-center type-2">

							<?php if ($subtitle) { ?>
								<span class="sub-title col-2"><?php print esc_html($subtitle)?></span>
								<div class="empty-sm-10 empty-xs-10"></div>
							<?php }

							if ($title) { ?>
								<h2 class="h2 title"><?php print esc_html($title)?></h2>
							<?php }

							if ($short_desc) { ?>
								<div class="empty-sm-15 empty-xs-15"></div>
								<div class="simple-text md col-2">
									<p><i><?php print wp_kses_post($short_desc); ?></i></p>
								</div>
							<?php } ?>

						</div>
					</div>
				<?php } ?> 
			</div>
			<div class="empty-lg-0 empty-md-0 empty-sm-30 empty-xs-30"></div> 
		</div>
		<?php return  ob_get_clean();
	}
}
