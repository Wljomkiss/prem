<?php 
/*
 * ONEPAGE
 * Version: 1.0.0 
 */

vc_map( 
	array(
		'name'			=> __( 'Onepage', 'nrg_premium' ),
		'base'			=> 'nrg_premium_onepage',
		'description'	=> __( 'Onepage', 'nrg_premium' ),
		'category'		=> __( 'NRGPremium', 'nrg_premium' ),
		'params'		=> array(
			array(
				'type'			=> 'vc_efa_chosen',
				'heading'		=> __( 'Custom Categories', 'nrg_premium' ),
				'param_name'	=> 'pages',
				'placeholder'	=> 'Choose page for onepage (optional)',
				'value'			=> nrg_premium_param_values( 'pages', array( 'post_type' => 'page', 'numberposts' => -1, 'orderby' => 'title', 'order' => 'ASC' ) ),
				'std'			=> '',
			),
			array(
				'type' 		  => 'textfield',
				'heading' 	  => __( 'Extra class name', 'nrg_premium' ),
				'param_name'  => 'el_class',
				'description' => __( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'nrg_premium' ),
				'value' 	  => ''
			),
			/* CSS editor */
			array(
				'type' 		  => 'css_editor',
				'heading' 	  => __( 'CSS box', 'nrg_premium' ),
				'param_name'  => 'css',
				'group' 	  => __( 'Design options', 'nrg_premium' )
			),
		)
	)
);

class WPBakeryShortCode_nrg_premium_onepage extends WPBakeryShortCode{
	protected function content( $atts, $content = null ) {
		extract( shortcode_atts( array(
			'pages'			=> '',
			'el_class'		=> '',
			'css'			=> '',

		), $atts ) );

		$class  = ( ! empty( $el_class ) ) ? $el_class : '';
		$class.= vc_shortcode_custom_css_class( $css, ' ' );



		if( $pages ){
			$pages = explode(',', $pages);
			$args = array(
				'post_type' 	 => 'page',
				'post__in' 		 => $pages,
				'posts_per_page' => -1,
				'orderby' 		 => 'menu_order',
				'post_status' 	 => 'publish',
				'order'			 => 'ASC'
			);
			$query = new WP_Query( $args );
			$css = '';
			if( $query->have_posts() ){
				wp_enqueue_script('anchors.nav');
				while( $query->have_posts() ){ $query->the_post();
					$css.= get_post_meta( get_the_ID(), '_wpb_post_custom_css', true );
					$css.= get_post_meta( get_the_ID(), '_wpb_shortcodes_custom_css', true );
					global $post; ?>
					<section class="onepage-<?php echo $post->post_name; ?>" id="onepage-<?php echo $post->post_name; ?>">
						<?php the_content(); ?>
					</section>
				<?php
				}
			}
			wp_reset_postdata();
	        if( $css ){
	          	$css = strip_tags( $css );
	          	echo '<style type="text/css" data-type="vc_shortcodes-custom-css">'.$css.'</style>';
	        }
		}
	}
}


