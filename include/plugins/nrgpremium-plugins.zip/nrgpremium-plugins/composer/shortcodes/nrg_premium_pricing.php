<?php 
/*
** Pricing
** Author: NRGTHEMES
** Author URI: http://nrgthemes.com
** Version: 1.0.0 
*/

vc_map( array(
	'name'						=> __( 'Pricing', 'nrg_premium' ),
	'base'						=> 'nrg_premium_pricing',
	'category'					=> __( 'NRGPremium', 'nrg_premium' ),
	'content_element'			=> true,
	'show_settings_on_create'	=> true,
	'description'				=> __( 'Pricing for restaurant', 'nrg_premium' ),
	'params'					=> array(
		array(
			'type'			=> 'dropdown',
			'heading'		=> __( 'Pricing type', 'nrg_premium' ),
			'param_name'	=> 'type',
			'value'			=> array(
				'Type 1'		=> 'type_1',
				'Type 2'		=> 'type_2',
			),
		),
		array(
			'type'			=> 'dropdown',
			'heading'		=> __( 'Pricing subtype', 'nrg_premium' ),
			'param_name'	=> 'subtype',
			'value'			=> array(
				'Subtype 1'		=> 'subtype_1',
				'Subtype 2'		=> 'subtype_2',
			)
		),
		array(
			'type'			=> 'checkbox',
			'heading'		=> __( "Best", "nrg_premium" ),
			'param_name'	=> 'best',
			'description'	=> 'Choose this price as the best?',
			'value'			=> false,
			'dependency'	=> array( 'element' => 'type', 'value' => 'type_2' ),
		),
		array(
			'type'			=> 'attach_image',
			'heading'		=> __( "Image", "nrg_premium" ),
			'param_name'	=> 'image',
			'description'	=> 'Upload your image.',
			'dependency'	=> array( 'element' => 'type', 'value' => 'type_1' ),
		),
		array(
			'type'			=> 'textfield',
			'heading'		=> 'Price',
			'param_name'	=> 'price',
			'value'			=> '',
			'description'	=> 'Only for numbers',
		),
		array(
			'type'			=> 'textfield',
			'heading'		=> 'Period',
			'param_name'	=> 'period',
			'value'			=> '',
			'dependency'	=> array( 'element' => 'type', 'value' => 'type_2' ),
		),
		array(
			'type'			=> 'textfield',
			'heading'		=> 'Title',
			'param_name'	=> 'title',
			'admin_label'	=> true,
			'value'			=> '',
		),
		array(
			'type'			=> 'textfield',
			'heading'		=> 'Subtitle',
			'param_name'	=> 'subtitle',
			'admin_label'	=> true,
			'value'			=> '',
			'dependency'	=> array( 'element' => 'type', 'value' => 'type_2' ),
		),
		array(
			'type'			=> 'vc_link',
			'heading'		=> 'Link',
			'param_name'	=> 'url',
			'value'			=> '',
		),
		array(
			'type'			=> 'textarea',
			'heading'		=> __( 'Short Description', 'nrg_premium' ),
			'param_name'	=> 'short_desc',
			'dependency'	=> array( 'element' => 'type', 'value' => 'type_1' ),
		),
		array(
			'type'			=> 'param_group',
			'js_view'		=> 'VcColumnView',
			'heading'		=> __( 'List', 'nrg_premium' ),
			'param_name'	=> 'list',
			'params'		=> array(
				array(
					'type'			=> 'textfield',
					'heading'		=> __( "List item", "nrg_premium" ),
					'param_name'	=> 'list_item',
					'value'			=> '',
				),
			),
			'dependency'	=> array( 'element' => 'type', 'value' => 'type_2' ),
		),
		array(
			'type'			=> 'textfield',
			'heading'		=> __( 'Extra class name', 'nrg_premium' ),
			'param_name'	=> 'el_class',
			'description'	=> __( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'nrg_premium' ),
			'value'			=> '',
		),
		array(
			'type'			=> 'css_editor',
			'heading'		=> __( 'CSS box', 'nrg_premium' ),
			'param_name'	=> 'css',
			'group'			=> __( 'Design options', 'nrg_premium' ),
		),
		
	) //end params
) );

class WPBakeryShortCode_nrg_premium_pricing extends WPBakeryShortCode {
	protected function content( $atts, $content = null) {

		extract( shortcode_atts( array(
			'el_class'      => '',
			'css'           => '',
			'type'			=> 'type_1',
			'image'	 		=> '',
			'title' 		=> '',
			'subtitle'		=> '',
			'url'    		=> '',
			'short_desc'	=> '',
			'price'			=> '',
			'period'		=> '',
			'list'			=> '',
			'best'			=> false,
			'subtype'		=> 'subtype_1'

 		), $atts ) );

		$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, $this->settings['base'], $atts );
		
		// custum css
		$css_class .= vc_shortcode_custom_css_class( $css, ' ' );

		// custum class
		$css_class .= (!empty($el_class)) ? ' '.$el_class : '';

		if (isset($url)) {
			$link = vc_build_link($url);
		}

		if ($list) {
			$values = vc_param_group_parse_atts( $atts['list']);
		}

		$image_html = '';
		if ($image) {
		$image_full = wp_get_attachment_image_url( $image, 'full' );
		$image_html = '<div class="bg layer-hold type-2 type-6" style="background-image: url('. esc_url( $image_full ). ')"></div>';
		}
 		// output
		ob_start();
		do_shortcode( $content );
		?>
		<!--Pricing-->
		<div class="<?php print esc_attr( $css_class ); ?>">
			<?php if ($type == 'type_1') { ?>
				<div class="hover-block item-h-500 menu-type-item">
					<?php print $image_html ?>
					<a href="<?php print esc_html($link['url'])?>" class="hover-layer-2">
						<div class="vertical-align full">
							<div class="caption type-2 text-center">
								<?php if ($price) { ?>
									<span class="dish-price"><?php print esc_html__('From ', 'nrg_premium'); print esc_html($price) ?></span>
									<div class="empty-sm-5 empty-xs-5"></div>
								<?php } ?>
								<?php if ($title) { ?>
									<h4 class="h4 title tt"><?php print esc_html($title)?></h4>
								<?php } ?>
								<?php if ($short_desc) { ?>
									<div class="empty-sm-15 empty-xs-15"></div>
									<div class="simple-text col-3">
										<p><?php print wp_kses_post($short_desc); ?></p>
									</div>
								<?php } ?>
							</div>
						</div>
					</a>
				</div>
			<?php } elseif ($type == 'type_2') { ?> 
				<div class="price-item <?php echo ($best == true && $subtype == 'subtype_1' ? 'align-top ' : ' '); echo ($best == true ? 'special ' : ' '); echo ($subtype == 'subtype_2' ? 'price-type-2' : ''); ?> ">
					<?php if ($best == true) { ?>
						<div class="best-stiker">
							<span><?php echo esc_html__('best', 'nrg_premium'); ?></span>
						</div>
					<?php }
					if ($title || $subtitle) { ?>   
						<div class="price-header">
							<?php if ($subtype == 'subtype_1') { ?>
								<div class="empty-sm-70 empty-xs-40"></div>
							<?php } elseif ($subtype == 'subtype_2') { ?>
								<div class="empty-sm-60 empty-xs-40"></div> 
							<?php } 
							if ($subtitle)  { ?>
								<div class="sub-desc"><?php echo esc_html($subtitle); ?></div>
								<div class="empty-sm-10 empty-xs-10"></div>
							<?php } 
							if ($title) { ?>
								<h4 class="h4 title"><?php echo esc_html($title); ?></h4>
							<?php } 
							if ($subtype == 'subtype_1') { ?>
								<div class="empty-sm-70 empty-xs-40"></div>
							<?php } elseif ($subtype == 'subtype_2') { ?>
								<div class="empty-sm-60 empty-xs-40"></div>
							<?php } ?>
						</div>
					<?php } ?>
					<div class="price-list">
						<div class="price-number">
							<span>$</span>
							<b><?php echo esc_html($price);?></b>
							<p>/<?php echo esc_html($period); ?></p> 
						</div>
						<?php if (isset($values)) { ?>
							<div class="empty-sm-40 empty-xs-40"></div>
							<ul>
							<?php foreach ($values as $value) { ?>
								<li><?php echo esc_html($value['list_item']); ?></li>
							<?php } ?>
							</ul>
						<?php } 
						if (isset($link)) { ?>
							<div class="empty-sm-25 empty-xs-20"></div>
							<a href="<?php echo esc_url($link['url']); ?>" class="main-link wh-lg link-style-5" data-text="learn more"><span><?php echo esc_html__('order now', 'nrg_premium'); ?></span></a>
						<?php } ?>
					</div>
				</div>
				<div class="empty-sm-30 empty-xs-30"></div>
			<?php } ?>
		</div>

		<?php return  ob_get_clean();
	}
}
