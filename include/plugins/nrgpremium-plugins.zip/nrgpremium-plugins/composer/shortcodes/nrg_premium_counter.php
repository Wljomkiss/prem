<?php 
/*
** Counter
** Author: NRGTHEMES
** Author URI: http://nrgthemes.com
** Version: 1.0.0 
*/

vc_map( array(
	'name'					=> __( 'Counter', 'nrg_premium' ),
	'base'					=> 'nrg_premium_counter',
	'content_element'		=> true,
	'show_settings_on_create'	=> true,
	'description'			=> __( 'Counter', 'nrg_premium' ),
	'category'				=> __( 'NRGPremium', 'nrg_premium' ),
	'params'				=> array(
		array(
			'type'			=> 'dropdown',
			'heading'		=> __( 'FAQ type', 'nrg_premium' ),
			'param_name'	=> 'count_type',
			'value'			=> array(
				'Type 1'		=> 'type_1',
				'Type 2'		=> 'type_2',
				'Type 3'		=> 'type_3',
				'Type 4'		=> 'type_4',
			),
		),
		array(
			'type'			=> 'param_group',
			'js_view'		=> 'VcColumnView',
			'heading'		=> __( 'Counter', 'nrg_premium' ),
			'description'	=> __( 'Counter', 'nrg_premium' ),
			'param_name'	=> 'counter_wrap',
			'params'		=> array(
				array(
					'type'			=> 'textfield',
					'heading'		=> 'Title',
					'param_name'	=> 'title',
					'value'			=> '',
				),
				array(
					'type'			=> 'textfield',
					'heading'		=> 'Count number',
					'param_name'	=> 'counter',
					'value'			=> '',
				),
			),
			'dependency'  => array( 'element' => 'count_type', 'value' => 'type_1'),
		),
		array(
			'type'			=> 'textfield',
			'heading'		=> 'Count number',
			'param_name'	=> 'counter',
			'admin_label'	=> true,
			'value'			=> '',
			'dependency'	=> array( 'element' => 'count_type', 'value' =>  array('type_2', 'type_3', 'type_4')),
		),
		array(
			'type'			=> 'textfield',
			'heading'		=> 'Title',
			'param_name'	=> 'title',
			'admin_label'	=> true,
			'value'			=> '',
			'dependency'	=> array( 'element' => 'count_type', 'value' => array('type_2', 'type_3', 'type_4')),
		),
		array(
			'type'			=> 'textfield',
			'heading'		=> 'Subitle',
			'param_name'	=> 'subtitle',
			'value'			=> '',
			'dependency'	=> array( 'element' => 'count_type', 'value' => array('type_2', 'type_3', 'type_4')),
		),
		array(
			'type'			=> 'dropdown',
			'heading'		=> __( 'Bottom line', 'nrg_premium' ),
			'param_name'	=> 'line',
			'value'			=> array(
				'Type 1'		=> 'type_1',
				'Type 2'		=> 'type_2',
			),
			'dependency'	=> array( 'element' => 'count_type', 'value' => 'type_3'),
		),
		array(
			'type'			=> 'param_group',
			'js_view'		=> 'VcColumnView',
			'heading'		=> __( 'List', 'nrg_premium' ),
			'description'	=> __( 'list', 'nrg_premium' ),
			'param_name'	=> 'list',
			'params'		=> array(
				array(
					'type'			=> 'textfield',
					'heading'		=> 'List item',
					'param_name'	=> 'list_item',
					'value'			=> '',
				),
			),
			'dependency'	=> array( 'element' => 'count_type', 'value' => 'type_4'),
		),
		array(
			'type'			=> 'textarea',
			'heading'		=> 'Short description',
			'param_name'	=> 'short_desc',
			'value'			=> '',
			'dependency'	=> array( 'element' => 'count_type', 'value' => 'type_2'),
		),

		array(
			'type'			=> 'textfield',
			'heading'		=> __( 'Extra class name', 'nrg_premium' ),
			'param_name'	=> 'el_class',
			'description'	=> __( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'nrg_premium' ),
			'value'			=> '',
		),
		array(
			'type'			=> 'css_editor',
			'heading'		=> __( 'CSS box', 'nrg_premium' ),
			'param_name'	=> 'css',
			'group'			=> __( 'Design options', 'nrg_premium' ),
		),
	) //end params
) );

class WPBakeryShortCode_nrg_premium_counter extends WPBakeryShortCode {
	protected function content( $atts, $content = null) {

		extract( shortcode_atts( array(
			'el_class'		=> '',
			'css'			=> '',
			'counter_wrap'	=> '',
			'count_type'	=> 'type_1',
			'title'			=> '',
			'subtitle'		=> '',
			'short_desc'	=> '',
			'counter'		=> '',
			'list'			=> '',
			'line'			=> 'type_1',

 		), $atts ) );

		$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, $this->settings['base'], $atts );
		
		// custum css
		$css_class .= vc_shortcode_custom_css_class( $css, ' ' );
		$id = uniqid();
		// custum class
		$css_class .= (!empty($el_class)) ? ' '.$el_class : '';

		if (isset($counter_wrap) && $counter_wrap ) { 
			$values = vc_param_group_parse_atts( $atts['counter_wrap']);
		}

		if (isset($list) && $list) {
			$val_list = vc_param_group_parse_atts( $atts['list']);
		}

 		// output
		ob_start();
		do_shortcode( $content );

		if ($count_type == 'type_1' && isset($counter_wrap)) {
		?>
			<!--COUNTER TYPE 1-->
				<div class="time-line start-line <?php print esc_attr( $css_class ); ?>"> 
					<?php $i = 0;
					if (isset($values)) {
					foreach ($values as $value) { 
						if (isset($value['counter']) && isset($value['title'])) {
						$i++ ?> 
							<div class="skill-block full-w">
								<h6 class="title second-font"><?php print esc_html($value['title']); ?></h6>
								<div class="skill-line">
									<div data-width-pb="<?php print esc_html($value['counter']); ?>%"><span class="line-animate"><h5 data-to="<?php print esc_html($value['counter']); ?>" class="timer" data-speed="2000">0</h5><span>%</span></span></div>
									</div>
								</div>
								<div class="empty-sm-50 empty-xs-30"></div>
							<?php } ?>
						<?php } 
					} ?>
				</div>
			<!--COUNTER TYPE 1 END-->
		<?php } elseif ($count_type == 'type_2' && $counter) { ?>
			<!--COUNTER TYPE 2-->
				<div class="time-line <?php print esc_attr( $css_class ); ?>">
					<div class="service-icon-box style-3 flex-align w-counter text-center-xs">
						<div class="image">
							<span class="timer style-1" data-to="<?php echo esc_html($counter); ?>" data-speed="1000">0</span>
						</div>
						<?php if ($title || $subtitle) { ?>
							<div class="caption">
								<?php if ($title) { ?>
									<h6 class="h6 title"><?php echo esc_html($title);?></h6>
								<?php }
								if ($subtitle) { ?>
									<span class="sub-desc"><?php echo esc_html($subtitle);?></span> 
								<?php } ?>
							</div>
						<?php }
						if ($short_desc) { ?>
							<div class="hover-text flex-align">
								<div class="simple-text col-3">
									<p><?php echo wp_kses_post($short_desc);?></p>
								</div>
							</div>
						<?php } ?>
					</div>
				</div>
			<!--COUNTER TYPE 2 END-->
		<?php } elseif ($count_type == 'type_3' && $counter) { ?>
			<!--COUNTER TYPE 3-->
				<div class="time-line <?php print esc_attr( $css_class ); ?>">
					<?php if ($title || $subtitle) { ?>
						<div class="caption text-center type-2">
							<?php if ($title) { ?>
								<h6 class="h6 title"><?php echo esc_html($title);?></h6>
								<div class="empty-sm-5 empty-xs-5"></div>
							<?php }
							if ($subtitle) { ?>
							<span class="sub-desc col-3"><?php echo esc_html($subtitle);?></span>
							<?php } ?>
							<div class="empty-sm-30 empty-xs-30"></div>
							<span class="timer style-2 <?php echo ($line == 'type_2'? 'col-1' : ''); ?>" data-to="<?php echo esc_html($counter); ?>" data-speed="1000">0</span> 
						</div>
					<?php } ?>
					<div class="empty-sm-30 empty-xs-30"></div>
				</div>
			<!--COUNTER TYPE 3 END-->
		<?php } elseif ($count_type == 'type_4' && $counter) { ?>
			<!--COUNTER TYPE 4-->
				<div class="<?php print esc_attr( $css_class ); ?>">
					<div class="skill-block full-w text-center-xs">
						<div class="skill-circle" data-border="false" data-dimension="130" data-bgcolor="#f6f6f6" data-width="2" data-percent="<?php echo esc_html($counter); ?>" data-fgcolor="#e48850" data-animationstep="1">
							<div class="skill-number vertical-align full">
								<span class="timer" data-to="<?php echo esc_html($counter); ?>" data-speed="1000">0</span>%
							</div>
						</div>
						<?php if ($title) { ?>
							<div class="empty-sm-15 empty-xs-15"></div>
							<h4 class="h6"><?php echo esc_html($title);?></h4>
						<?php } 
						if ($subtitle) { ?>
							<div class="empty-sm-10 empty-xs-10"></div>
							<div class="simple-text">
								<p><?php echo wp_kses_post($subtitle); ?></p>
							</div>
						<?php } 
						if (isset($val_list)) { ?>
							<div class="empty-sm-25 empty-xs-25"></div>
							<ul class="simple-list type-2">
								<?php foreach ($val_list as $v_list) { 
									if (isset($v_list['list_item'])) { ?>
										<li><?php print esc_html($v_list['list_item']); ?></li>
									<?php } 
								} ?>
							</ul>
						<?php } ?>
					</div>
					<div class="empty-sm-30 empty-xs-30"></div>   
				</div>

			<!--COUNTER TYPE 4 END-->
		<?php }
		return  ob_get_clean();
	}

}

