<?php 
/*
** Counter Big
** Version: 1.0.0 
*/


vc_map( array(
	'name'                    => __( 'Counter big', 'nrg_premium' ),
	'base'                    => 'nrg_premium_counter_big',
	'as_parent'               => array('only' => 'nrg_premium_counter_big_item'),
	'content_element'         => true,
	'show_settings_on_create' => true,
	'category' 				  => __( 'NRGPremium', 'nrg_premium' ),
	'description'             => __( 'Banner with 1/3 right slider', 'nrg_premium'),
	'js_view'                 => 'VcColumnView',
	'params'          => array(
		array(
			'type' => 'colorpicker',
			'heading' => __( 'Counter color', 'nrg_premium' ),
			'param_name' => 'color',
			'description' => __( 'Choose your counter colour, default is ', 'nrg_premium' ),
			'value' => '',
		),
		array(
			'type' => 'textfield',
			'heading' => __( 'Extra class name', 'nrg_premium' ),
			'param_name' => 'el_class',
			'description' => __( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'nrg_premium' ),
			'value' => '',
		),
		array(
			'type' => 'css_editor',
			'heading' => __( 'CSS box', 'nrg_premium' ),
			'param_name' => 'css',
			'group' => __( 'Design options', 'nrg_premium' ),
		),
	) //end params
) );

class WPBakeryShortCode_nrg_premium_counter_big extends WPBakeryShortCodesContainer {

	protected function content( $atts, $content = null) {

		extract( shortcode_atts( array(
			'el_class'	=> '',
			'css'		=> '',
			'color'		=> '#f6f6f6',
		
		), $atts ) );

		global $_counter_big_items;
		$_counter_big_items = array();

		$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, $this->settings['base'], $atts );

		// custum css
		$css_class .= vc_shortcode_custom_css_class( $css, ' ' );

		// custum class
		$css_class .= (!empty($el_class)) ? ' '.$el_class : '';
		
		// output
		ob_start();
		do_shortcode( $content );


		$list_t = $act = $tab_item = $step_item = $first = '';

		if ($_counter_big_items) { 
			$i = 1;
			if ($i == 1) {
				$act = 'class="active"';
			}
			
			foreach ($_counter_big_items as $key => $shortcode) { 
				$shortcode_atts = $shortcode['atts'];
				$list_t .= '<li '.$act.'>'.esc_html($shortcode_atts['title']).'</li>';
				if ($i == 1) {
					$first .= $shortcode_atts['title'];
				}
				$tab_item .= '<div class="tab-item">';
				$tab_item .= '<div class="step-item-wrapper">';
				if (isset($shortcode_atts['step'])) {
					$values = vc_param_group_parse_atts( $shortcode_atts['step'] );
					$n = 1; $p =0; $r=25;
					foreach ($values as $value) {
						$p = $p + $r;
						$step_item .= '<div class="step-item">';
						$step_item .= '<div class="circle-block">';
						$step_item .= '<div class="skill-circle" data-border="false" data-dimension="130" data-bgcolor="'.esc_html($color).'" data-width="2" data-percent="'.$p.'" data-fgcolor="#e48850" data-animationstep="1"></div>';
						$step_item .= '<div class="vertical-align full">';
						$step_item .= '<span>'.$n.'</span>';
						$step_item .= '</div>';
						$step_item .= '</div>';
						$step_item .= '<div class="empty-sm-20 empty-xs-20"></div>';
						$step_item .= '<h5 class="h5 tt bold">'.esc_html($value['title']).'</h5>';
						$step_item .= '<div class="empty-sm-10 empty-xs-10"></div>';
						$step_item .= '<div class="sub-title col-3 sm tt ls">'.esc_html($value['subtitle']).'</div>';
						$step_item .= '<div class="empty-sm-15 empty-xs-15"></div>';
						$step_item .= '<div class="simple-text col-1">';
						$step_item .= '<p>'.wp_kses_post($value['short_desc']).'</p>';
						$step_item .= '</div>';
						$step_item .= '<div class="empty-sm-30 empty-xs-30"></div>';
						$step_item .= '</div>';								
						$n++;
					}
				}
				$tab_item .= $step_item;
				$tab_item .= '</div>';
				$tab_item .= '</div>';

				$act = $step_item = ''; 
				$i++;
			}						
		}
?>


		<div class="tabs-block <?php print esc_attr( $css_class ); ?>">
			<div class="container-fluid">
				<div class="filter-list-mobile">
					<div class="select-txt"><p><?php echo esc_html($first);?></p><i class="fa fa-angle-down"></i></div>      
					<ul class="filter-list style-1 col-2 tabs-link">
						<?php echo ($list_t); ?>
					</ul>
				</div>
			</div>
			<div class="empty-md-90 empty-sm-60 empty-xs-40"></div>
			<div class="row">
				<div class="tabs-container">
					<?php echo $tab_item; ?>
				</div>
			</div>
		</div>

		<?php 
		return  ob_get_clean();
	}

}
/* Shortvode Item */

vc_map( array(
  'name'            => 'Counter steps',
  'base'            => 'nrg_premium_counter_big_item',
  'as_child' 		=> array('only' => 'nrg_premium_counter_big'),
  'content_element' => true,
  'show_settings_on_create' => true,
  'description'     => 'title and description',
  'params'          => array(
		array(
			'type'        => 'textfield',
			'heading'     => __( 'Step Title', 'nrg_premium' ),
			'param_name'  => 'title',
			'admin_label' => true,
			'value'       => '',
		),
		array(
			'type'    => 'param_group',
			'js_view'   => 'VcColumnView',
			'heading'   => __( 'Step', 'nrg_premium' ),
			'description' => __( 'Step', 'nrg_premium' ),
			'param_name'  => 'step',
			'params'  => array(
				array(
					'type'        => 'textfield',
					'heading'     => __( 'Title', 'nrg_premium' ),
					'param_name'  => 'title',
					'admin_label' => true,
					'value'       => '',
				),
				array(
					'type'        => 'textfield',
					'heading'     => __( 'Subtitle', 'nrg_premium' ),
					'param_name'  => 'subtitle',
					'admin_label' => true,
					'value'       => '',
				),
				array(
					'type'        => 'textarea',
					'heading'     => __( 'Short Description', 'nrg_premium' ),
					'param_name'  => 'short_desc',
				),
			),
		),
	) //end params
) );


class WPBakeryShortCode_nrg_premium_counter_big_item extends WPBakeryShortCode{
	protected function content( $atts, $content = null ) {

		global $_counter_big_items;
		$_counter_big_items[] = array( 'atts' => $atts, 'content' => $content, 'css_class' => '');
		return;
	}
}