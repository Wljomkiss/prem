<?php 
/*
** Pricing slider 2
** Version: 1.0.0 
*/


vc_map( array(
	'name'						=> __( 'Pricing slider Type 2', 'nrg_premium' ),
	'base'						=> 'nrg_premium_pricing_slider_2',
	'as_parent'					=> array('only' => 'nrg_premium_pricing_slider_2_item'),
	'content_element'			=> true,
	'show_settings_on_create'	=> false,
	'category'					=> __( 'NRGPremium', 'nrg_premium' ),
	'description'				=> __( 'Pricing slider Type 2', 'nrg_premium'),
	'js_view'					=> 'VcColumnView',
	'params'					=> array(
		array(
			'type'			=> 'textfield',
			'heading'		=> __( 'Extra class name', 'nrg_premium' ),
			'param_name'	=> 'el_class',
			'description'	=> __( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'nrg_premium' ),
			'value'			=> '',
		),
		array(
			'type'			=> 'css_editor',
			'heading'		=> __( 'CSS box', 'nrg_premium' ),
			'param_name'	=> 'css',
			'group'			=> __( 'Design options', 'nrg_premium' ),
		),
	) //end params
) );

class WPBakeryShortCode_nrg_premium_pricing_slider_2 extends WPBakeryShortCodesContainer {

	protected function content( $atts, $content = null) {

		extract( shortcode_atts( array(
			'el_class'		=> '',
			'css'			=> '',
		
		), $atts ) );

		global $_pricing_sliders_2_items;
		$_pricing_sliders_2_items = array();

		$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, $this->settings['base'], $atts );

		// custum css
		$css_class .= vc_shortcode_custom_css_class( $css, ' ' );

		// custum class
		$css_class .= (!empty($el_class)) ? ' '.$el_class : '';
		
		// output
		ob_start();
		do_shortcode( $content );
		?>
		<div class="<?php print esc_attr( $css_class ); ?> container-fluid ">
			<div class="arrow-closest mobile-pagination arrow-hover">
				<div class="swiper-container gutter-15" data-mode="horizontal" data-autoplay="0" data-effect="slide" data-slides-per-view="responsive" data-loop="0" data-speed="800" data-add-slides="4" data-lg-slides="4" data-md-slides="3" data-sm-slides="2" data-xs-slides="1">
					<div class="swiper-wrapper">
						<?php foreach ($_pricing_sliders_2_items as $key => $shortcode) {
						$shortcode_atts = $shortcode['atts'];
						$link = vc_build_link($shortcode_atts['url']); ?>
							<div class="swiper-slide">
								<div class="simple-item-1 hover-block text-center simple-style-2">
									<?php if (isset($shortcode_atts['image'])) { ?>
										<a href="<?php echo esc_html($link['url'])?>" class="image hover-layer bg-col-3">
											<img src="<?php echo esc_url(wp_get_attachment_image_url( $shortcode_atts['image'], 'full' )); ?>" alt="" class="resp-img">
										</a>
										<div class="empty-sm-40 empty-xs-30"></div>
									<?php } 
									if (isset($shortcode_atts['title']) || isset($shortcode_atts['subtitle'])) { ?>
										<div class="text">
											<?php if (isset($shortcode_atts['subtitle'])) { ?>
												<div class="sub-title col-9 ls"><i><?php echo esc_html($shortcode_atts['subtitle']); ?></i></div>
												<div class="empty-sm-10 empty-xs-10"></div> 
											<?php } 
											if (isset($shortcode_atts['title'])) { ?>
												<h3 class="h5 sm title tt">
													<a href="<?php echo esc_html($link['url'])?>" class="link-hover-2"><?php echo esc_html($shortcode_atts['title']); ?></a>
												</h3>
											<?php } 
											if (isset($shortcode_atts['short_desc'])) { ?>
												<div class="empty-sm-10 empty-xs-10"></div> 
												<div class="simple-text col-1">
													<p><?php echo wp_kses_post($shortcode_atts['short_desc']); ?></p>
												</div>
											<?php } ?>
										</div>
									<?php } ?>
									<div class="empty-sm-40 empty-xs-30"></div>
								</div>
							</div>
						<?php } ?>
					</div>
				</div>
				<div class="swiper-arrow-left slider-arrow-1 left-15 top-offset-55"><i class="fa fa-angle-left"></i></div>
				<div class="swiper-arrow-right slider-arrow-1 right-15 top-offset-55"><i class="fa fa-angle-right"></i></div>
			</div>
		</div>

		<?php 
		return  ob_get_clean();
	}

}
/* Shorctcode Item */

vc_map( array(
  'name'            => 'Pricing slider type 2 item',
  'base'            => 'nrg_premium_pricing_slider_2_item',
  'as_child' 		=> array('only' => 'nrg_premium_pricing_slider_2'),
  'content_element' => true,
  'show_settings_on_create' => true,
  'description'     => 'Image, title and text',
  'params'          => array(
		array(
			'type'        => 'attach_image',
			'heading'     => __( "Image", "nrg_premium" ),
			'param_name'  => 'image',
			'description' => 'Upload your image.'
		),
		array(
			'type'			=> 'textfield',
			'heading'		=> 'Title',
			'param_name'	=> 'title',
			'admin_label'	=> true,
			'value'			=> '',
		),
		array(
			'type'			=> 'textfield',
			'heading'		=> 'Subitle',
			'param_name'	=> 'subtitle',
			'admin_label'	=> true,
			'value'			=> '',
		),
		array(
			'type'			=> 'textfield',
			'heading'		=> 'Short description',
			'param_name'	=> 'short_desc',
			'value'			=> '',
		),
  		array(
			'type'			=> 'vc_link',
			'heading'		=> 'Link',
			'param_name'	=> 'url',
			'value'			=> '',
		),
	) //end params
) );


class WPBakeryShortCode_nrg_premium_pricing_slider_2_item extends WPBakeryShortCode{
	protected function content( $atts, $content = null ) {

		global $_pricing_sliders_2_items;
		$_pricing_sliders_2_items[] = array( 'atts' => $atts, 'content' => $content, 'css_class' => '');
		return;
	}
}