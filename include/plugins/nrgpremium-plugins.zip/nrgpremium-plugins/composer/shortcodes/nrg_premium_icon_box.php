<?php 
/*
** Icon Box
** Author: NRGTHEMES
** Author URI: http://nrgthemes.com
** Version: 1.0.0 
*/

vc_map( array(
	'name'						=> __( 'Icon Box', 'nrg_premium' ),
	'base'						=> 'nrg_premium_icon_box_1',
	'category'					=> __( 'NRGPremium', 'nrg_premium' ),
	'content_element'			=> true,
	'show_settings_on_create'	=> true,
	'description'				=> __( 'icon, title, subtitle, short description', 'nrg_premium' ),
	'params'					=> array(
		array(
			'type'			=> 'dropdown',
			'heading'		=> __( 'Icon box type', 'nrg_premium' ),
			'param_name'	=> 'ic_b_type',
			'value'			=> array(
				'Type 1'		=> 'type_1',
				'Type 2'		=> 'type_2',
				'Type 3'		=> 'type_3',
				'Type 4'		=> 'type_4',
				'Type 5'		=> 'type_5',
				'Type 6'		=> 'type_6',
				'Type 7'		=> 'type_7',
				'Type 8'		=> 'type_8',
				'Type 9'		=> 'type_9',
				'Type 10'		=> 'type_10',
				'Type 11'		=> 'type_11',
				'Type 12'		=> 'type_12',
				'Type 13'		=> 'type_13',
				'Type 14'		=> 'type_14',
				'Type 15'		=> 'type_15',
				'Type 16'		=> 'type_16'
			),
		),
		array(
			'type'			=> 'dropdown',
			'heading'		=> __( 'Icon box 5 Subtype', 'nrg_premium' ),
			'param_name'	=> 'ic_b_type_5_sub',
			'value'			=> array(
				'Subtype 1'		=> 'subtype_1',
				'Subtype 2'		=> 'subtype_2',
			),
			'dependency'	=> array( 'element' => 'ic_b_type', 'value' => 'type_5'),
		),
		array(
			'type'			=> 'dropdown',
			'heading'		=> __( 'Icon box type 1 style', 'nrg_premium' ),
			'param_name'	=> 'ic_b_type_st',
			'value'			=> array(
				'Style 1'		=> 'style_1',
				'Style 2'		=> 'style_2',
				),
			'dependency'	=> array( 'element' => 'ic_b_type', 'value' => 'type_1'),
		),
		array(
			'type'        => 'dropdown',
			'heading'     => __( 'Icon box type 4 style', 'nrg_premium' ),
			'param_name'  => 'ic_b_type_4_st',
			'value'       => array(
				'Style 1'   => 'style_1',
				'Style 2'   => 'style_2',
				),
			'dependency'  => array( 'element' => 'ic_b_type', 'value' => 'type_4'),
		),
		array(
			'type'        => 'attach_image',
			'heading'     => __( "Icon", "nrg_premium" ),
			'param_name'  => 'icon',
			'admin_label' => true,
			'description' => 'Upload your image.',
			'dependency'  => array( 'element' => 'ic_b_type', 'value' => array('type_1', 'type_2', 'type_3', 'type_4', 'type_5', 'type_6','type_7', 'type_8', 'type_9', 'type_10', 'type_11', 'type_12', 'type_13', 'type_14', 'type_16') ),
		),
		array(
			'type'        => 'dropdown',
			'heading'     => __( 'Button type', 'nrg_premium' ),
			'param_name'  => 'btn_type',
			'value'       => array(
				'Type 1'   => 'type_1',
				'Type 2'   => 'type_2',
				'Type 3'   => 'type_3',
				'Type 4'   => 'type_4',
				'Type 5'   => 'type_5',
				'Type 6'   => 'type_6',
			),
			'dependency'  => array( 'element' => 'ic_b_type', 'value' => array('type_8', 'type_12')),
		),
		array(
			'type'			=> 'dropdown',
			'heading'		=> __( 'Button width', 'nrg_premium' ),
			'param_name'	=> 'b_width',
			'value'			=> array(
				'Standart'		=> 'standart',
				'Small'			=> 'small',
			),
			'dependency'  => array( 'element' => 'ic_b_type', 'value' => array('type_8', 'type_12')),
		),
		array(
			'type'			=> 'colorpicker',
			'class'			=> '',
			'heading'		=> __( 'Main color', 'nrg_premium' ),
			'param_name'	=> 'm_color',
			'value'			=> '#84694e',
			'dependency'  => array( 'element' => 'ic_b_type', 'value' => array('type_8', 'type_12')),
		),
		array(
			'type'        => 'textfield',
			'heading'     =>  __( "Button title", "nrg_premium" ),
			'param_name'  => 'button_title',
			'admin_label' => true,
			'value'       => '',
			'dependency'  => array( 'element' => 'ic_b_type', 'value' => array('type_8', 'type_13', 'type_14', 'type_15')),
		),
		array(
			'type'        => 'vc_link',
			'heading'     => 'Link',
			'param_name'  => 'button_url',
			'admin_label' => true,
			'value'       => '',
			'dependency'  => array( 'element' => 'ic_b_type', 'value' => array('type_5','type_8', 'type_13', 'type_14', 'type_15')),
		),
		array(
			'type'        => 'dropdown',
			'heading'     => __( 'Button Align', 'nrg_premium' ),
			'param_name'  => 'btn_align',
			'value'       => array(
				'Align left'    => 'align_left',
				'Align center'  => 'align_center',
				),
			'dependency'  => array( 'element' => 'ic_b_type', 'value' => 'type_8'),
		),
		array(
			'type'        => 'dropdown',
			'heading'     => __( 'Icon Align', 'nrg_premium' ),
			'param_name'  => 'icon_align',
			'value'       => array(
				'Align right'	=> 'right',
				'Align left'	=> 'left',
				),
			'dependency'  => array( 'element' => 'ic_b_type', 'value' => 'type_9'),
		),
		array(
			'type'		  => 'colorpicker',
			'heading'     => __( "Bg icon color", "nrg_premium" ),
			'param_name'  => 'bg_ic_color',
			'description' => 'Choose bg color to icon',
			'value'       => '#fff',
			'dependency'  => array( 'element' => 'ic_b_type', 'value' => array('type_2', 'type_8', 'type_9')),
		),
		array(
			'type'        => 'textfield',
			'heading'     =>  __( "Title", "nrg_premium" ),
			'param_name'  => 'title',
			'admin_label' => true,
			'value'       => '',
		),
		array(
			'type'		  => 'colorpicker',
			'heading'     => __( "Color title", "nrg_premium" ),
			'param_name'  => 'c_title',
			'description' => 'Choose title color',
			'value'       => '',
			'dependency'  => array( 'element' => 'ic_b_type', 'value' => 'type_4'),
		),
		array(
			'type'        => 'textfield',
			'heading'     =>  __( "Subtitle", "nrg_premium" ),
			'param_name'  => 'subtitle',
			'admin_label' => true,
			'value'       => '',
		),
		array(
			'type'        => 'textfield',
			'heading'     =>  __( "Symbol", "nrg_premium" ),
			'param_name'  => 'symbol',
			'value'       => '',
			'dependency'  => array( 'element' => 'ic_b_type', 'value' => array('type_13', 'type_15')),
		),
		array(
			'type'		  => 'colorpicker',
			'heading'     => __( "Color subtitle", "nrg_premium" ),
			'param_name'  => 'c_subtitle',
			'description' => 'Choose subtitle color',
			'value'       => '',
			'dependency'  => array( 'element' => 'ic_b_type', 'value' => 'type_4'),
		),
		array(
			'type'			=> 'param_group',
			'js_view'		=> 'VcColumnView',
			'heading'		=> __( 'List', 'nrg_premium' ),
			'param_name'	=> 'list',
			'params'		=> array(
				array(
					'type'        => 'textfield',
					'heading'     =>  __( "List item", "nrg_premium" ),
					'param_name'  => 'list_item',
					'admin_label' => true,
					'value'       => '',
				),
			),
			'dependency'	=> array( 'element' => 'ic_b_type', 'value' => 'type_6'),
		),
		array(
			'type'        => 'attach_image',
			'heading'     => __( "Image", "nrg_premium" ),
			'param_name'  => 'image',
			'admin_label' => true,
			'description' => 'Upload your image.',
			'dependency'	=> array( 'element' => 'ic_b_type', 'value' => 'type_12'),
		),
		array(
			'type' => 'textarea',
			'heading' => __( 'Short Description', 'nrg_premium' ),
			'param_name' => 'short_desc',
			'dependency'  => array( 'element' => 'ic_b_type', 'value' => array('type_1', 'type_2', 'type_3', 'type_7', 'type_8', 'type_9', 'type_10', 'type_11', 'type_12', 'type_14', 'type_15') ),
		),
		array(
			'type' => 'textfield',
			'heading' => __( 'Extra class name', 'nrg_premium' ),
			'param_name' => 'el_class',
			'description' => __( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'nrg_premium' ),
			'value' => '',
		),
		array(
			'type' => 'css_editor',
			'heading' => __( 'CSS box', 'nrg_premium' ),
			'param_name' => 'css',
			'group' => __( 'Design options', 'nrg_premium' ),
		),
	) //end params
) );

class WPBakeryShortCode_nrg_premium_icon_box_1 extends WPBakeryShortCode {
	protected function content( $atts, $content = null) {

		extract( shortcode_atts( array(
			'el_class'			=> '',
			'css'				=> '',
			'subtitle'			=> '',
			'title'				=> '',
			'short_desc'		=> '',
			'icon'				=> '',
			'ic_b_type'			=> 'type_1',
			'bg_ic_color'		=> '#fff',
			'c_title'			=> '',
			'c_subtitle'		=> '',
			'ic_b_type_st'		=> 'style_1',
			'ic_b_type_4_st'	=> 'style_1',
			'button_url'		=> '',
			'list'				=> '',
			'button_title'		=> '',
			'btn_type'			=> 'type_1',
			'btn_align'			=> 'align_left',
			'icon_align'		=> 'right',
			'image'				=> '',
			'symbol'			=> '',
			'm_color'			=> '',
			'b_width'			=> 'standart',
			'ic_b_type_5_sub'	=> 'subtype_1',


 		), $atts ) );

		$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, $this->settings['base'], $atts );
		
		// custum css
		$css_class .= vc_shortcode_custom_css_class( $css, ' ' );

		// custum class
		$css_class .= (!empty($el_class)) ? ' '.$el_class : '';

		if ($list) {
			$values = vc_param_group_parse_atts( $atts['list']);
		}

		$button_link = vc_build_link($button_url);

		// button align
		$btn_align_n = '';
		if ($btn_align == 'align_left') {
			$btn_align_n = 'text-left';
		} else {
			$btn_align_n = 'text-center';
		}

 		// output
		ob_start();
		do_shortcode( $content );
		?>
		<!--ICON BOX-->
		<div class="<?php print esc_attr($css_class); ?>">
			<?php if ($ic_b_type == 'type_1') { ?>
				<div class="service-icon-box <?php echo ($ic_b_type_st  == 'style_2' ? 'style-2' : ''); ?>">
					<?php if (!empty($icon)) { ?>
						<div class="image">
							<img src="<?php echo esc_url(wp_get_attachment_image_url( $icon, 'full' )); ?>" alt="icon">
						</div>
					<?php } ?>
					<div class="caption">
						<?php if ($title) { ?>
							<h6 class="title second-font"><?php print esc_html($title) ?></h6>
						<?php } if ($subtitle) { ?>
							<span class="sub-title col-3 tt sm"><?php print esc_html($subtitle) ?></span> 
						<?php } ?>
					</div>
					<?php if ($short_desc) { ?>
						<div class="empty-sm-15 empty-xs-15"></div>
						<div class="simple-text col-1">
							<p><?php print wp_kses_post($short_desc); ?></p>
						</div>
					<?php } ?>
				</div>
			<?php } elseif ($ic_b_type == 'type_2') { ?>
				<div class="best-item flex-align" >
					<?php if (!empty($icon)) { ?>
						<div class="image" style="background: <?php echo esc_attr($bg_ic_color);?>">
							<img src="<?php echo esc_url(wp_get_attachment_image_url( $icon, 'full' )); ?>" alt="icon">
						</div>
					<?php } ?>
					<div class="caption type-2">
						<?php if ($title) { ?>
							<h6 class="title h6 "><?php print esc_html($title) ?></h6>
						<?php } ?>
						<?php if ($subtitle) { ?>
							<span class="sub-title sm ls"><?php print esc_html($subtitle) ?></span> 
						<?php } ?>
						<?php if ($short_desc) { ?>
							<div class="empty-sm-15 empty-xs-15"></div>
							<div class="simple-text col-3">
								<p><?php print wp_kses_post($short_desc); ?></p>
							</div>
						<?php } ?>
					</div>
				</div>
			<?php } elseif ($ic_b_type == 'type_3') { ?>
				<div class="service-item-sm">
					<?php if (!empty($icon)) { ?>
						<div class="image">
							<img src="<?php echo esc_url(wp_get_attachment_image_url( $icon, 'full' )); ?>" alt="icon">
						</div>
					<?php } ?>
					<div class="text type-2">
						<?php if ($title) { ?>
							<h6 class="title h6"><?php print esc_html($title) ?></h6>
						<?php } ?>
						<?php if ($subtitle) { ?>
							<span class="sub-title sm ls col-4"><?php print esc_html($subtitle) ?></span> 
						<?php } ?>
						<?php if ($short_desc) { ?>
							<div class="simple-text col-2">
								<p><?php print wp_kses_post($short_desc); ?></p>
							</div>
						<?php } ?>
					</div>
				</div>
			<?php } elseif ($ic_b_type == 'type_4') { ?>
				<div class="flex-align <?php echo ($ic_b_type_4_st == 'style_2' ? 'style-3 service-icon-box' : 'service-icon-box-2'); ?>">
					<?php if (!empty($icon)) { ?>
						<div class="image">
							<img src="<?php echo esc_url(wp_get_attachment_image_url( $icon, 'full' )); ?>" alt="icon">
						</div>
					<?php } ?>
					<div class="caption">
						<?php if ($title) { ?>
							<h6 class="title h6" style="color:<?php echo esc_attr($c_title);?>"><?php print esc_html($title) ?></h6>
						<?php } ?>
						<?php if ($subtitle) { ?>
							<span class=" <?php echo ($ic_b_type_4_st == 'style_2' ? 'sub-desc' : 'sub-title sm' ); ?>" style="color: <?php if ( $ic_b_type == 'type_4'){print esc_attr($c_subtitle);}?>"><?php print esc_html($subtitle) ?></span> 
						<?php } ?>
					</div>
				</div>
			<?php } elseif ($ic_b_type == 'type_5') { ?>
				<a href="<?php echo esc_html($button_link['url']); ?>" class="service-icon-box sm style-3 flex-align">
					<?php if ($ic_b_type_5_sub == 'subtype_2') { ?>
						<div class="text-center">
					<?php } ?>
						<?php if (!empty($icon)) { ?>
							<div class="image">
								<img src="<?php echo esc_url(wp_get_attachment_image_url( $icon, 'full' )); ?>" alt="icon">
							</div>
						<?php } ?>
						<div class="caption">
							<?php if ($title) { ?>
								<h6 class="title h6"><?php print esc_html($title) ?></h6>
							<?php } ?>
							<?php if ($subtitle) { ?>
								<span class="sub-desc type-1"><?php print esc_html($subtitle) ?></span> 
							<?php } ?>
							<?php if ($short_desc) { ?>
								<div class="empty-sm-15 empty-xs-15"></div>
								<div class="simple-text col-2">
									<p><?php print wp_kses_post($short_desc); ?></p>
								</div>
							<?php } ?>
						</div>
					<?php if ($ic_b_type_5_sub == 'subtype_2') { ?>
						</div>
					<?php } ?>
				</a>
			<?php } elseif ($ic_b_type == 'type_6') { ?>
				<div class="service-icon-box style-4">
					<?php if (!empty($icon)) { ?>
						<div class="image">
							<img src="<?php echo esc_url(wp_get_attachment_image_url( $icon, 'full' )); ?>" alt="icon">
						</div>
					<?php } ?>
					<div class="caption">
						<?php if ($title) { ?>
							<h6 class="title h6"><?php print esc_html($title) ?></h6>
						<?php } ?>
						<?php if ($subtitle) { ?>
							<span class="sub-desc"><?php print esc_html($subtitle) ?></span> 
						<?php } ?>
						<?php if ( isset($values) ) { ?>
							<div class="empty-sm-20 empty-xs-20"></div>
							<ul class="simple-list type-2">
								<?php foreach ($values as $value) { ?>
									<?php if (isset($value['list_item'])) {
										echo '<li>'.esc_html($value['list_item']).'</li>';
									} ?>
								<?php } ?>
							</ul>
						<?php } ?>
					</div>
				</div>
			<?php } elseif ($ic_b_type == 'type_7') { ?>
				<div class="service-icon-box lg-padd left-absolute">
					<div class="image border-icon">
						<?php if (!empty($icon)) { ?>
							<div class="vertical-align full">  
								<img src="<?php echo esc_url(wp_get_attachment_image_url( $icon, 'full' )); ?>" alt="">
							</div>     
						<?php } ?>
					</div>
					<?php if ($title || $subtitle) { ?>
						<div class="caption">
							<?php if ($title) { ?>
								<h6 class="h7 tt title"><?php echo esc_html($title) ?></h6>
							<?php }
							if ($subtitle) { ?>
								<div class="sub-title mdx col-5 ls"><?php echo esc_html($subtitle) ?></div>
							<?php }
							if($short_desc) { ?>
								<div class="empty-sm-10 empty-xs-10"></div>
								<div class="simple-text col-1">
									<p><?php print wp_kses_post($short_desc); ?></p>
								</div>
							<?php } ?>
						</div>
					<?php } ?>
				</div>
			<?php } elseif ($ic_b_type == 'type_8') { ?>
				<div class="best-item flex-align type-2">
					<div class="relative-wrap">
						<div class="empty-sm-50 empty-xs-30"></div>
						<?php if (!empty($icon)) { ?> 
							<div class="icon" style="background: <?php echo esc_attr($bg_ic_color);?>">
								<img src="<?php echo esc_url(wp_get_attachment_image_url( $icon, 'full' )); ?>" alt="" class="center-align">
							</div>
						<?php } ?>
						<div class="empty-sm-30 empty-xs-30"></div>
						<?php if ($title || $subtitle) { ?>
							<div class="caption type-2">
								<?php if ($title) { ?>
									<h6 class="h5 tt title"><?php echo esc_html($title) ?></h6>
								<?php }
								if ($subtitle) { ?>
									<div class="sub-title sm ls col-4 tt"><?php echo esc_html($subtitle) ?></div>
								<?php }
								if($short_desc) { ?>
									<div class="empty-sm-15 empty-xs-15"></div>
									<div class="simple-text col-2">
										<p><?php print wp_kses_post($short_desc); ?></p>
									</div>
								<?php } ?>
								<div class="empty-sm-25 empty-xs-25"></div>
								<?php hm_get_template_part('composer/shortcodes/buttons/button-'.$btn_type, [ 'title' => $button_title, 'but_url' => $button_url, 'but_align' =>  $btn_align_n, 'but_width' => $b_width, 'main_color' => $m_color ]); ?>
							</div>
						<?php } ?> 
						<div class="empty-sm-35 empty-xs-25"></div> 
					</div>     
				</div>
			<?php } elseif ($ic_b_type == 'type_9') { ?>
				<div class="service-icon-box text-center-xs <?php echo ($icon_align == 'right' ? 'right-align' : ''); ?>">
					<?php if (!empty($icon)) { ?>
						<div class="image">
							<div class="icon-box">
								<div class="vertical-align full">
									<img src="<?php echo esc_url(wp_get_attachment_image_url( $icon, 'full' )); ?>" alt="">
								</div>
							</div>
						</div>
					<?php } 
					if ($title || $subtitle) { ?>
						<div class="caption">
							<?php if ($title) { ?>
								<h6 class="h7 tt title"><?php print esc_html($title) ?></h6>
							<?php } 
							if ($subtitle) { ?>
								<span class="sub-title col-3 tt sm"><?php print esc_html($subtitle) ?></span>
							<?php } ?>
						</div>
					<?php }
					if ($short_desc) { ?>
						<div class="empty-sm-15 empty-xs-15"></div>
						<div class="simple-text col-1">
							<p><?php print wp_kses_post($short_desc); ?></p>
						</div>
					<?php } ?>
				</div>
			<?php } elseif ($ic_b_type == 'type_10') { ?>
				<div class="best-item type-3 flex-align bottom-align ">
					<?php if (!empty($icon)) { ?>
						<div class="icon"><img src="<?php echo esc_url(wp_get_attachment_image_url( $icon, 'full' )); ?>" alt=""></div>
					<?php } if ($title || $subtitle || $short_desc) { ?>
						<div class="caption type-2">
							<?php if ($title) { ?>
								<h6 class="h5 sm title tt"><?php print esc_html($title) ?></h6>
							<?php } 
							if ($subtitle) { ?>
								<div class="empty-sm-5 empty-xs-5"></div>
								<i class="sub-title sm ls col-11 tt"><?php print esc_html($subtitle) ?></i>
							<?php } 
							if ($short_desc) { ?>
								<div class="empty-sm-15 empty-xs-15"></div>
								<div class="simple-text col-3">
									<p><?php print wp_kses_post($short_desc); ?></p>
								</div>
							<?php } ?>
						</div>
					<?php } ?>
				</div>
			<?php } elseif ($ic_b_type == 'type_11') { ?>
				<div class="service-icon-box style-8 left-absolute border">
					<?php if (!empty($icon)) { ?>
						<div class="image">
							<img src="<?php echo esc_url(wp_get_attachment_image_url( $icon, 'full' )); ?>" alt="">   
						</div>
					<?php } if ($title || $subtitle || $short_desc) { ?>
						<div class="caption">
							<?php if ($title) { ?>
								<h6 class="h7 tt title"><?php print esc_html($title) ?></h6>
							<?php } 
							if ($subtitle) { ?>
								<div class="empty-sm-10 empty-xs-10"></div>
								<div class="sub-title sm col-5 ls"><i><?php print esc_html($subtitle) ?></i></div>
							<?php } 
							if ($short_desc) { ?>
								<div class="empty-sm-10 empty-xs-10"></div>
								<div class="simple-text col-1">
									<p><?php print wp_kses_post($short_desc); ?></p>
								</div>
							<?php } ?>
						</div>
					<?php } ?>
				</div>
			<?php } elseif ($ic_b_type == 'type_12') { ?>
				<div class="service-icon-box style-3 flex-align bg-section-4">
					<?php if (!empty($icon)) { ?>
						<div class="image">
							<img src="<?php echo esc_url(wp_get_attachment_image_url( $icon, 'full' )); ?>" alt="">
						</div>
					<?php }
					if ($title || $subtitle) { ?>
						<div class="caption type-2">
							<?php if ($title ) { ?>
								<h6 class="h6 title"><?php print esc_html($title) ?></h6>
							<?php } 
							if ($subtitle) { ?>
								<span class="sub-title sm tt ls col-4"><?php print esc_html($subtitle) ?></span> 
							<?php } ?>
						</div>
					<?php } ?>
					<div class="hover-text bg-block-2 style-img">
						<?php if (!empty($image)) { ?>
							<div class="img">
								<div class="bg" style="background-image: url(<?php echo esc_url(wp_get_attachment_image_url( $image, 'full' )); ?>)"></div>
							</div>  
						<?php } 
						if ($short_desc) { ?> 
							<div class="txt flex-align">
								<div class="simple-text col-2">
									<p><?php print wp_kses_post($short_desc); ?></p>
								</div>
							</div>
						<?php } ?>
					</div>
				</div> 
			<?php } elseif ($ic_b_type == 'type_13') { ?>
				<div class="service-icon-box text-center padd-30">
					<?php if (!empty($icon)) { ?>
						<img src="<?php echo esc_url(wp_get_attachment_image_url( $icon, 'full' )); ?>" alt="">
					<?php } 
					if ($title) { ?>
						<div class="empty-sm-10 empty-xs-10"></div>
						<div class="caption type-2">
							<h5 class="h5 title"><?php print esc_html($title) ?></h5>  
						</div>
					<?php } 
					if ($subtitle) { ?>
						<div class="empty-sm-15 empty-xs-15"></div>
						<div class="simple-text col-2">
							<p><?php print esc_html($subtitle) ?></p>
						</div>
					<?php } 
					if ($button_title && $button_link) { ?>
						<div class="empty-sm-30 empty-xs-30"></div>
						<a href="<?php echo esc_html($button_link['url']);?>" class="main-link wh-xs col-white"><span><?php echo esc_html($button_title);?></span></a>
					<?php } 
					if ($symbol) { ?>
						<div class="empty-sm-40 empty-xs-30"></div>
						<div class="letter-item second-font"><?php echo esc_html($symbol);?></div>
					<?php } ?>
					<div class="empty-sm-30 empty-xs-30"></div>
				</div>
			<?php } elseif ($ic_b_type == 'type_14') { ?>
				<div class="service-icon-box md text-center flex-align border-2 padd-md-15">
					<div class="custome-padd-100">
						<?php if (!empty($icon)) {?>
							<img src="<?php echo esc_url(wp_get_attachment_image_url( $icon, 'full' )); ?>" alt="">
							<div class="empty-sm-20 empty-xs-20"></div>
						<?php } 
						if ($title) {?>
							<h5 class="h6"><?php echo esc_html($title);?></h5>
						<?php }
						if ($subtitle) {?>
							<div class="empty-sm-15 empty-xs-15"></div>
							<div class="simple-text col-1">
								<p><?php echo esc_html($subtitle); ?></p>
							</div>
						<?php }?>
					</div>
					<div class="hover-text bg-block-2 flex-align">
						<div class="custome-padd-50">
							<?php if ($title) {?>
								<div class="caption type-2">
									<h5 class="h6 title"><?php echo esc_html($title);?></h5>
								</div>
								<div class="empty-sm-15 empty-xs-15"></div>  
							<?php }
							if ($short_desc) {?>
								<div class="simple-text col-3">
									<p><?php echo wp_kses_post($short_desc);?></p>
								</div>
							<?php } 
							if ($button_title && $button_link) { ?>
								<div class="empty-sm-15 empty-xs-15"></div>
								<a href="<?php echo esc_html($button_link['url']);?>" class="main-link wh-xs col-white-2">
									<span><?php echo esc_html($button_title);?></span>
								</a>
							<?php }?>
						</div>
					</div>
				</div>
			<?php } elseif ($ic_b_type == 'type_15') { ?>
				<div class="custome-padd-120 padd-xs-15">
					<div class="caption-number">
						<?php if ($symbol) { ?>
							<span class="second-font"><?php echo esc_html($symbol); ?></span>
						<?php }
						if ($title) { ?>
							<h4 class="h4 lg tt title"><?php echo esc_html($title);?></h4>
						<?php }
						if ($subtitle) { ?>
							<div class="sub-title sm tt col-3 ls"><?php echo esc_html($subtitle);?></div> 
						<?php } ?>
					</div>
					<?php if ($short_desc) { ?>
						<div class="empty-sm-25 empty-xs-20"></div> 
						<div class="simple-text col-1">
							<p><?php echo wp_kses_post($short_desc);?></p>
						</div>
					<?php } ?>
					<div class="empty-sm-35 empty-xs-30"></div>
					<a href="<?php echo esc_html($button_link['url']);?>" class="main-link link-style-1 type-6 color-6"><span><?php echo esc_html($button_title);?></span></a> 
				</div>
			<?php } elseif ($ic_b_type == 'type_16') { ?>
				<div class="service-icon-box style-3 flex-align sm">
					<?php if (!empty($icon)) {?>	
						<div class="image">
							<img src="<?php echo esc_url(wp_get_attachment_image_url( $icon, 'full' )); ?>" alt="">
						</div>
					<?php } ?>
					<div class="caption">
						<? if ($title) { ?>
							<h6 class="h6 title"><?php echo esc_html($title);?></h6>
						<?php } 
						if ($subtitle) { ?>
							<span class="sub-desc"><?php echo esc_html($subtitle);?></span>
						<?php } ?>
					</div>
				</div>
			<?php } ?>
		</div>
		<?php 
		return  ob_get_clean();
	}
}
