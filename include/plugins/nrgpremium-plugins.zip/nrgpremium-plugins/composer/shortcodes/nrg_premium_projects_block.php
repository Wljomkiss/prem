<?php 
/*
 * Projects Shortcode
 * Author: Upqode
 * Author URI: http://upqode.com
 * Version: 1.0.0 
 */

vc_map( 
	array(
		'name'				=> __( 'Projects block', 'nrg_premium' ),
		'base'				=> 'nrg_premium_projects_block',
		'description'		=> __( 'Projects block', 'nrg_premium' ),
		'category'			=> __( 'NRGPremium', 'nrg_premium' ),
		'params'			=> array(
			array(
				'type'			=> 'dropdown',
				'admin_label'	=> true, 
				'heading'		=> 'Type',
				'param_name'	=> 'type',
				'value'			=> array(
					'Type 1'		=> 'type_1',
					'Type 2'		=> 'type_2',
				),
			),
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Title', 'nrg_premium' ),
				'param_name'	=> 'title',
				'admin_label'	=> true,
				'value'			=> '',
			),
			array(
				'type'			=> 'checkbox',
				'heading'		=> __( 'Separator', 'nrg_premium' ),
				'param_name'	=> 'sep',
				'value'			=> false,
			),
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Subtitle', 'nrg_premium' ),
				'param_name'	=> 'subtitle',
				'admin_label'	=> true,
				'value'			=> '',
			),
			array(
				'type'			=> 'textarea',
				'heading'		=> __( 'Short description', 'nrg_premium' ),
				'param_name'	=> 'short_desc',
				'value'			=> '',
			),
			array(
				'type'			=> 'dropdown',
				'heading'		=> __( 'Align text', 'nrg_premium' ),
				'param_name'	=> 'align_text',
				'value'			=> array(
					'Align left'	=> 'left',
					'Align center'	=> 'center',
					'Align right'	=> 'right',
				),
			),
			array(
				'type'			=> 'attach_image',
				'heading'		=> __( 'Image', 'nrg_premium' ),
				'param_name'	=> 'image',
				'description'	=> 'Upload your image.'
			),
			array(
				'type'			=> 'dropdown',
				'admin_label'	=> true, 
				'heading'		=> 'Order by',
				'param_name'	=> 'orderby',
				'value'			=> array(
					'ID'			=> 'ID',
					'Author'		=> 'author',
					'Post Title'	=> 'title',
					'Date'			=> 'date',
					'Last Modified'	=> 'modified',
					'Random Order'	=> 'rand',
					'Menu Order'	=> 'menu_order'
				)
			),
			array(
				'type'			=> 'dropdown',
				'heading'		=> 'Order',
				'param_name'	=> 'order',
				'value'			=> array(
					'Ascending'		=> 'ASC',
					'Descending'	=> 'DESC'
				)
			),
			array(
				'type'			=> 'vc_efa_chosen',
				'heading'		=> __( 'Custom Categories', 'nrg_premium' ),
				'param_name'	=> 'cats',
				'placeholder'	=> 'Choose category (optional)',
				'value'			=> nrg_premium_param_values( 'terms', array(
					'taxonomies' => 'projects_categories',
				) ),
				'std'			=> '',
				'description'	=> __( 'You can choose spesific categories for portfolio, default is all categories', 'nrg_premium' ),
			),
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Count items', 'nrg_premium' ),
				'param_name'	=> 'limit',
				'value'			=> '',
				'description'	=> __( 'Default 20 items.', 'nrg_premium' )
			),
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Extra class name', 'nrg_premium' ),
				'param_name'	=> 'el_class',
				'description'	=> __( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'nrg_premium' ),
				'value'			=> ''
			),
			array(
				'type'			=> 'css_editor',
				'heading'		=> __( 'CSS box', 'nrg_premium' ),
				'param_name'	=> 'css',
				'group'			=> __( 'Design options', 'nrg_premium' )
			),
		)
	)
);

class WPBakeryShortCode_nrg_premium_projects_block extends WPBakeryShortCode{
	protected function content( $atts, $content = null ){
		extract( shortcode_atts( array(
			'orderby'		=> 'ID',
			'order'			=> 'ASC',
			'cats'			=> '',
			'limit'			=> '',
			'title'			=> '',
			'subtitle'		=> '',
			'short_desc'	=> '',
			'image'			=> '',
			'align_text'	=> 'left',
			'sep'			=> false,
			'css'			=> '',
			'el_class'		=> '',
			'type'			=> 'type_1',

		), $atts ) );

		// Align
		$align_class = '';
		if ($align_text == 'center') {
			$align_class = 'text-center';
		} elseif ($align_text == 'right') {
			$align_class = 'text-right';
		} 

		$class  = ( ! empty( $el_class ) ) ? $el_class : '';
		$class .= vc_shortcode_custom_css_class( $css, ' ' );

		$category = '';
		$limit 	  = ( empty( $limit ) || ! is_numeric( $limit ) ) ? 6 : $limit;

		$sc_cats = $cats;
		$cats 	 = explode( ',', $cats );
		
		$category_first = $category = $tab_item = $tab = '';
		$i = 1;
		foreach( $cats as $cat ){
			$term = get_term_by( 'id', $cat, 'projects_categories' );
			if( !is_wp_error($term) ){
				//category
				if( $i =='1' )
					$category_first.= '<div class="select-txt tt text-center"><p>'.$term->name.'</p><i class="fa fa-angle-down"></i></div>  ';
				$category.= '<li'.( $i =='1' ? ' class="active"' : '' ).'><a>'.$term->name.'</a></li>';
				
				//tab_item
				$args = array(
					'post_type'      => 'projects',
					'posts_per_page' => $limit,
					'order'			 => $order,
					'orderby'		 => $orderby,
					'tax_query'      => array(
						array(
							'taxonomy' => 'projects_categories',
							'field'    => 'id',
							'terms'    => $cat
						)
					)
				);
				$query = new WP_Query( $args );
				if( $query->have_posts() ){
					while( $query->have_posts() ){ $query->the_post();
						if ($type == 'type_1') {
							$tab_item.= '<div class="col-50">';
							$tab_item.= '<div class="service-item-2 custome-padd-100 flex-align">';
							$tab_item.= '<div class="flex-wrap">';
							$tab_item.= '<h6 class="h6 title">'.get_the_title().'</h6>';
							$tab_item.= '<div class="empty-sm-20 empty-xs-20"></div>';
							$tab_item.= '<div class="simple-text col-3">';
							$tab_item.= '<p>'.get_the_excerpt().'</p>';
							$tab_item.= '</div>';
							$tab_item.= '</div>';
							$tab_item.= '</div>';
							$tab_item.= '</div>';
						} else {
							$tab_item.= '<div class="col-33 col-50-767">';
							$tab_item.= '<div class="service-item-2 custome-padd-100 flex-align" style="background-image: url('.get_the_post_thumbnail_url().'); background-size: cover; background-repeat: no-repeat;" >';
							$tab_item.= '<div class="flex-wrap">';
							$tab_item.= '<h6 class="h6 title pr_block_h">'.get_the_title().'</h6>';
							$tab_item.= '</div>';
							$tab_item.= '</div>';
							$tab_item.= '</div>';
						}


					}
					wp_reset_postdata();
				}
				//tab
				if( $tab_item )
					$tab.= '<div class="tab-item animate">';
					$tab.= '<div class="col-wrap animate-tab-content">';
						$tab.= $tab_item;
					$tab.= '</div>';
					$tab.= '</div>';
				$tab_item = '';
				$i++;
			}
		} 
		if( $tab ){  ?>
			<div class="tabs-container <?php echo ( $type=='type_2' ? 'pr_block' : '');?>">   
				<div class="container-fluid no-padd"> 
					<div class="row vertical-wrap">
						<div class="col-md-4 <?php echo ( $type=='type_2' ? 'sm-full' : '');?>">
							<div class="empty-lg-30 empty-md-30 empty-sm-60 empty-xs-60"></div> 
							<div class="custome-padd-100 xs-padd-15">
								<div class="caption text-center-xs <?php echo esc_html($align_class);?>">
									<?php if ($subtitle) { ?>
										<span class="sub-title tt"><?php echo esc_html($subtitle);?></span>
										<div class="empty-sm-5 empty-xs-5"></div>
									<?php }
									if ($title) { ?>
										<h2 class="h2 title"><?php echo esc_html($title);?></h2>
										<div class="empty-sm-25 empty-xs-20"></div>
									<?php }
									if ($sep == true) { ?>
										<div class="title-separator-3"></div>
										<div class="empty-sm-25 empty-xs-20"></div>
									<?php }
									if ($short_desc) { ?>
										<div class="simple-text md col-1">
											<p><?php echo wp_kses_post($short_desc);?></p>
										</div>
										<div class="empty-md-30 empty-sm-30 empty-xs-30"></div>
									<?php } ?>
									<div class="tabs-block"> 
										<div class="filter-list-mobile">
											<?php echo $category_first; ?>
											<ul class="tabs-link-type-3 tabs-link filter-list">
												<?php echo $category; ?>
											</ul>
										</div>
									</div>
									<div class="empty-lg-0 empty-md-0 empty-sm-40 empty-xs-30"></div>
								</div> 
							</div>
							<div class="empty-lg-30 empty-md-30 empty-sm-0 empty-xs-0"></div> 
						</div>
						<div class="col-md-8">
							<div class="bg layer-hold type-4" style="background-image: url(<?php echo esc_url(wp_get_attachment_image_url( $image, 'full' )); ?>)"></div>
							<div class="tabs-container">
								<?php echo $tab; ?>
							</div>
						</div>
					</div>
				</div>
			</div>
	<?php }
	}
}