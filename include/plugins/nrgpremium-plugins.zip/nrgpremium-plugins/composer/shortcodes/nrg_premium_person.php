<?php 
/*
** Person
** Author: NRGTHEMES
** Author URI: http://nrgthemes.com
** Version: 1.0.0 
*/

vc_map( array(
	'name'						=> __( 'Person', 'nrg_premium' ),
	'base'						=> 'nrg_premium_person',
	'category'					=> __( 'NRGPremium', 'nrg_premium' ),
	'content_element'			=> true,
	'show_settings_on_create'	=> true,
	'description'				=> __( 'Info about person (image, name itc.)', 'nrg_premium' ),
	'params'					=> array(
		array(
			'type'			=> 'attach_image',
			'heading'		=> __( "Image", "nrg_premium" ),
			'param_name'	=> 'image',
			'description'	=> 'Upload your image.'
		),
		array(
			'type'			=> 'attach_image',
			'heading'		=> __( "Sign", "nrg_premium" ),
			'param_name'	=> 'sign',
			'description'	=> 'Upload your image.'
		),
		array(
			'type'			=> 'textfield',
			'heading'		=>  __( "Position", "nrg_premium" ),
			'param_name'	=> 'position',
			'admin_label'	=> true,
			'value'			=> '',
		),
		array(
			'type'			=> 'textarea',
			'heading'		=> __( 'Short Description', 'nrg_premium' ),
			'param_name'	=> 'short_desc',
		),
		array(
			'type'			=> 'textfield',
			'heading'		=> __( 'Extra class name', 'nrg_premium' ),
			'param_name'	=> 'el_class',
			'description'	=> __( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'nrg_premium' ),
			'value'			=> '',
		),
		array(
			'type'			=> 'css_editor',
			'heading'		=> __( 'CSS box', 'nrg_premium' ),
			'param_name'	=> 'css',
			'group'			=> __( 'Design options', 'nrg_premium' ),
		),
	) //end params
) );

class WPBakeryShortCode_nrg_premium_person extends WPBakeryShortCode {
	protected function content( $atts, $content = null) {

		extract( shortcode_atts( array(
			'el_class'		=> '',
			'css'			=> '',
			'image'			=> '',
			'sign'			=> '',
			'position'		=> '',
			'short_desc'	=> '',

 		), $atts ) );

		$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, $this->settings['base'], $atts );
		
		// custum css
		$css_class .= vc_shortcode_custom_css_class( $css, ' ' );

		// custum class
		$css_class .= (!empty($el_class)) ? ' '.$el_class : '';

 		// output
		ob_start();
		do_shortcode( $content );
		?>
		<!--Person-->
		<div class="<?php print esc_attr( $css_class ); ?>">
			<div class="frame-block xs-frame col-border-1">
				<div class="custome-padd-50">
					<div class="empty-sm-60 empty-xs-40"></div>  
					<div class="caption text-center">
						<?php if ($image) { ?>
							<img src="<?php echo esc_url(wp_get_attachment_image_url( $image, 'full' )); ?>" alt="">
							<div class="empty-sm-35 empty-xs-30"></div>
						<?php } 
						if ($short_desc) { ?>
							<div class="simple-text col-2">
								<p><?php echo wp_kses_post($short_desc);?></p>
							</div>
						<?php } 
						if ($sign) { ?>
							<div class="empty-sm-25 empty-xs-20"></div>
							<img src="<?php echo esc_url(wp_get_attachment_image_url( $sign, 'full' )); ?>" alt="">
						<?php }
						if ($position) { ?>
							<div class="empty-sm-10 empty-xs-10"></div>
							<span class="sub-title sm tt ls col-4"><?php echo esc_html($position);?></span>
						<?php } ?>
					</div>
					<div class="empty-sm-60 empty-xs-40"></div>
				</div> 
			</div>
		</div>
		<?php 
		return  ob_get_clean();
	}
}