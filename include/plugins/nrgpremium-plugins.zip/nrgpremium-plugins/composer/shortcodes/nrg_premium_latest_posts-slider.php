<?php 
/*
** Latest Post slider
** Author: NRGTHEMES
** Author URI: http://nrgthemes.com
** Version: 1.0.0 
*/

vc_map( array(
	'name'						=> __( 'Latest posts slider', 'nrg_premium' ),
	'base'						=> 'nrg_premium_latest_post_slider',
	'content_element'			=> true,
	'show_settings_on_create'	=> true,
	'description'				=> __( 'Latest posts sliders', 'nrg_premium' ),
	'category'					=> __( 'NRGPremium', 'nrg_premium' ),
	'params'					=> array(
		array(
			'type'			=> 'dropdown',
			'heading'		=> __( 'View type', 'nrg_premium' ),
			'param_name'	=> 'type',
			'admin_label'	=> true, 
			'value'			=> array(
				'Classic'				=> 'classic',
				'Classic plus'			=> 'classic_plus',
				'Classic one'			=> 'classic_one',
				'Classic border'		=> 'classic_border',
				'Classic without img'	=> 'classic_without_img',
				'Creative'				=> 'creative',
				'Creative one'			=> 'creative_one',
				'Panorama'				=> 'panorama',
			),
		),
		array(
			'type'			=> 'colorpicker',
			'heading'		=> __( 'Main color', 'nrg_premium' ),
			'param_name'	=> 'main_color',
			'value'			=> '',
			'dependency'	=> array( 'element' => 'type', 'value' => 'classic'),
		),
		array(
			'type'			=> 'vc_efa_chosen',
			'heading'		=> __( 'Custom Categories', 'nrg_premium' ),
			'param_name'	=> 'cats',
			'placeholder'	=> 'Choose category (optional)',
			'value'			=> nrg_premium_param_values( 'terms', array(
				'taxonomies'	=> 'category',
			) ),
			'std'			=> '',
			'description'	=> __( 'You can choose spesific categories for post, default is all categories', 'nrg_premium' ),
		),
		array(
			'type'			=> 'textfield',
			'heading'		=> __( 'Posts limit', 'nrg_premium' ),
			'param_name'	=> 'limit',
			'value'			=> '',
			'description'	=> __( 'Default is 6 posts in slides, only for numbers', 'nrg_premium' ),
		),
		array(
			'type'			=> 'dropdown',
			'heading'		=> __( 'Creative one subtype', 'nrg_premium' ),
			'param_name'	=> 'classic_col',
			'value'			=> array(
				'col 3'			=> '3',
				'col 4'			=> '4',
			),
			'dependency'	=> array( 'element' => 'type', 'value' => 'classic'),
		),
		array(
			'type'			=> 'dropdown',
			'heading'		=> __( 'Creative one subtype', 'nrg_premium' ),
			'param_name'	=> 'subtype_cr_one',
			'value'			=> array(
				'Tall'							=> 'tall',
				'Wide & tall'					=> 'wide_tall',
				'Tall center'					=> 'tall_center',
				'Tall center content bottom'	=> 'tall_center_bottom',
			),
			'dependency'	=> array( 'element' => 'type', 'value' => 'creative_one'),
		),
		array(
			'type'			=> 'dropdown',
			'heading'		=> __( 'Category visability', 'nrg_premium' ),
			'param_name'	=> 'cat_visib',
			'value'			=> array(
				'Enable'		=> 'enable',
				'Disable'		=> 'disable',
			),
		),
		array(
			'type'			=> 'dropdown',
			'heading'		=> __( 'Category type', 'nrg_premium' ),
			'param_name'	=> 'cat_type',
			'value'			=> array(
				'Type 1'		=> 'type_1',
				'Type 2'		=> 'type_2',
			),
			'dependency'	=> array( 'element' => 'cat_visib', 'value' => 'enable'),
		),
		array(
			'type'			=> 'dropdown',
			'heading'		=> __( 'Pagination align', 'nrg_premium' ),
			'param_name'	=> 'pag_align',
			'value'			=> array(
				'Top Right'			=> 'right',
				'Top Left'			=> 'left',
				'Bottom center'		=> 'bottom_center',
			),
			'dependency'	=> array( 'element' => 'type', 'value' => 'creative_one'),
		),
		array(
			'type'			=> 'dropdown',
			'heading'		=> __( 'Likes and comments visability', 'nrg_premium' ),
			'param_name'	=> 'com_visib',
			'value'			=> array(
				'Enable'		=> 'enable',
				'Disable'		=> 'disable',
			),
			'dependency'	=> array( 'element' => 'type', 'value' => 'creative_one'),
		),
		array(
			'type'			=> 'colorpicker',
			'heading'		=> __( 'Background block color', 'nrg_premium' ),
			'param_name'	=> 'bg_color',
			'value'			=> '',
			'description'	=> __( 'Background block color', 'nrg_premium' )
		),
		array(
			'type'			=> 'textfield',
			'heading'		=> __( 'Extra class name', 'nrg_premium' ),
			'param_name'	=> 'el_class',
			'description'	=> __( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'nrg_premium' ),
			'value'			=> '',
		),
		array(
			'type'			=> 'css_editor',
			'heading'		=> __( 'CSS box', 'nrg_premium' ),
			'param_name'	=> 'css',
			'group'			=> __( 'Design options', 'nrg_premium' ),
		),
	), //end params
) );



class WPBakeryShortCode_nrg_premium_latest_post_slider extends WPBakeryShortCode{
	protected function content( $atts, $content = null ) {
		extract( shortcode_atts( array(
			'el_class'		=> '',
			'css'			=> '',
			'cats'			=> '',
			'type'			=> 'classic',
			'limit'			=> '',
			'cat_visib'		=> 'enable',
			'com_visib'		=> 'enable',
			'pag_align'		=> 'right',
			'subtype_cr_one'	=> 'tall',
			'bg_color'		=> '',
			'cat_type'		=> 'type_1',
			'classic_col'	=> '3',
			'main_color'	=> '',

		), $atts ) );

		// limit
		$limit 	  = ( empty( $limit ) || ! is_numeric( $limit ) ) ? 6 : $limit;

		$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, $this->settings['base'], $atts );
		
		// custum css
		$css_class .= vc_shortcode_custom_css_class( $css, ' ' );

		// custum class
		$css_class .= (!empty($el_class)) ? ' '.$el_class : '';

		$args = array(
			'post_type'      => 'post',
			'posts_per_page' => $limit,
			'order'			 => 'DESC',
			'orderby'		 => 'date',
			'tax_query'      => array()
		);
		if( $cats ){
			$cats = explode( ',', $cats );
			$args['tax_query'][] = array(
				'taxonomy' => 'category',
				'field'    => 'id',
				'terms'    => $cats
			);
		}

		
		$query = new WP_Query( $args );

		// output
		ob_start();
		do_shortcode( $content );
		if( $query->have_posts() ){ ?>
			<div class="<?php print esc_attr( $css_class ); ?>">
				<?php if ($type == 'classic') {
					$un_id = uniqid('col-');	
					?>
					<div class="container-fluid">
						<div class="swiper-container gutter-15 pagination-bottom" data-mode="horizontal" data-autoplay="0" data-effect="slide" data-slides-per-view="responsive" data-loop="0" data-speed="800" data-add-slides="<?php echo esc_html($classic_col);?>" data-lg-slides="3" data-md-slides="2" data-sm-slides="1" data-xs-slides="1">
							<div class="swiper-wrapper">
								<?php while ( $query->have_posts() ) {
								$query->the_post();?>
									<div class="swiper-slide">
										<div class="simple-item-1 hover-block">
											<a href="<?php the_permalink(); ?>" class="image hover-layer <?php echo $un_id;?>">
												<img src="<?php the_post_thumbnail_url(); ?>" alt="" class="resp-img">
											</a> 
											<div class="empty-sm-25 empty-xs-25"></div>
											<div class="text">
												<div class="sub-title sm col-3">
													<i><?php the_time(get_option('date_format')); echo esc_html__(' by '); the_author(); ?></i>
												</div>
												<h3 class="h6 title">
													<a href="<?php the_permalink(); ?>" class="link-hover-2"><?php the_title(); ?></a>
												</h3>
												<div class="empty-sm-15 empty-xs-15"></div> 
												<div class="simple-text col-1">
													<p><?php echo wp_trim_words( get_the_excerpt(), 25, ' ...' ); ?></p>
												</div>
											</div>
										</div>
										<div class="empty-sm-30 empty-xs-30"></div>
									</div>
								<?php }
								wp_reset_postdata();
								?>
							</div>
							<div class="empty-sm-20 empty-xs-20"></div>
							<div class="pagination type-2 <?php echo $un_id;?>"></div>
						</div>
					</div>
					<?php $custom_css = '';
					if( isset($main_color) && $main_color ){
						$custom_css.= '.'.$un_id.'.hover-layer:before {background:'.$main_color.';}';
						$custom_css.= '.'.$un_id.'.pagination .swiper-pagination-bullet:hover:before {background:'.$main_color.';}';
						$custom_css.= '.'.$un_id.'.pagination .swiper-pagination-bullet.swiper-pagination-bullet-active:before {background:'.$main_color.';}';
						$custom_css.= '.'.$un_id.'.pagination .swiper-pagination-bullet:before {background:#cfcfcf;}';
					}
					if( $custom_css ){ ?>
						<style type="text/css"><?php echo $custom_css; ?></style>
					<?php } ?>
				<?php } 
				elseif ($type == 'classic_plus') { ?>
					<section class="section arrow-closest">
						<div class="container-fluid">  
							<div class="empty-sm-50 empty-xs-50"></div>
							<ul class="list-post fl">
								<li><a href="#">Top posts</a></li>
								<li><a href="#">Most comments</a></li>
								<li><a href="#">Most viwed</a></li>
								<li><a href="#">Favorites</a></li>
							</ul>
							<div class="fr wr-slider-arrow">
								<div class="swiper-arrow-left slider-arrow-2"><i class="fa fa-angle-left"></i></div>
								<div class="swiper-arrow-right slider-arrow-2"><i class="fa fa-angle-right"></i></div>
							</div>
							<div class="empty-sm-50 empty-xs-50"></div>
							<div class="row">
								<div class="swiper-container gutter-15" data-mode="horizontal" data-autoplay="0" data-effect="slide" data-slides-per-view="responsive" data-loop="0" data-speed="800" data-add-slides="4" data-lg-slides="4" data-md-slides="3" data-sm-slides="2" data-xs-slides="1">
									<div class="swiper-wrapper">
										<?php while ( $query->have_posts() ) {
										$query->the_post() ?>
											<div class="swiper-slide">
												<div class="mag-item-1 hover-block">
													<a href="<?php the_permalink(); ?>" class="image hover-layer bg-col-5">
														<img src="<?php the_post_thumbnail_url(); ?>" alt="">  
													</a>
													<div class="text">
														<div class="sub-title sm col-13"><i><?php the_time(get_option('date_format')); ?></i></div>
														<div class="empty-sm-5 empty-xs-5"></div>
														<div class="caption">
															<h3 class="h6 title">
																<a href="#" class="text-line-animate no-tr"><?php the_title(); ?></a>
															</h3>
														</div>
														<div class="empty-sm-15 empty-xs-15"></div>
														<div class="simple-text sm col-1">
															<p><?php echo wp_trim_words( get_the_excerpt(), 25, ' ...' ); ?></p>
														</div>
													</div>
												</div>
											</div>
										<?php }
										wp_reset_postdata();
										?>
									</div>
								</div>
							</div>
						</div>
						<div class="empty-sm-30 empty-xs-30"></div> 
					</section>
				<?php }
				elseif ($type == 'classic_one') { ?>
					<div class="swiper-container" data-mode="horizontal" data-autoplay="0" data-effect="slide" data-slides-per-view="1" data-loop="0" data-speed="800" >
						<div class="swiper-wrapper">
							<?php while ( $query->have_posts() ) {
							$query->the_post() ?>
								<div class="swiper-slide">
									<div class="mag-item-1 hover-block">
										<div class="image hover-layer bg-col-5">
											<?php 
												$term_list = get_the_terms(get_the_ID(), 'category' );
												if( $term_list ){
													echo '<div class="mag-item-cat-wr">';
													foreach( $term_list as $value ){
														$bg_color = '';
														$term_data = get_term_meta( $value->term_id, '_custom_category_options', true );
														if(isset($term_data['post_cat_color'])){
															$bg_color = 'style="background-color:'.$term_data['post_cat_color'].';"';
														}
														echo '<div class="mag-item-cat '.($cat_type=="type_2"?"type-2": "").'" '.($cat_type=="type_1"?"$bg_color": "").'"><a href="'.get_term_link($value->term_id).'">'.$value->name.'</a></div>';
													}
													echo '</div>';
												}
											?>
											<img src="<?php the_post_thumbnail_url(); ?>" alt="">  
										</div>
										<div class="text">
											<div class="sub-title sm col-13"><i><?php the_time(get_option('date_format'));?></i></div>
											<div class="empty-sm-5 empty-xs-5"></div>
											<div class="caption">
												<h3 class="h6 title ">
													<a href="<?php the_permalink(); ?>" class="text-line-animate"><?php the_title(); ?></a>
												</h3>
											</div>
											<div class="empty-sm-15 empty-xs-15"></div>
											<div class="simple-text sm col-1">
												<p><?php echo wp_trim_words( get_the_excerpt(), 25, ' ...' ); ?></p>
											</div>
											<div class="empty-sm-50 empty-xs-50"></div> 
										</div>
									</div>
								</div>
							<?php }
							wp_reset_postdata();
							?>
						</div>
						<div class="pagination type-2 colo-type-6 align-bottom-30"></div>
					</div>
				<?php } 
				elseif ($type == 'classic_without_img') { ?>
					<div class="min-h-md mag-testi-slider flex-align" style="background-color:<?php echo esc_attr($bg_color)?>">
						<div class="swiper-container" data-mode="horizontal" data-autoplay="0" data-effect="slide" data-slides-per-view="1" data-loop="0" data-speed="800" >
							<div class="swiper-wrapper">
								<?php while ( $query->have_posts() ) {
								$query->the_post() ?>	
									<div class="swiper-slide">
										<?php 
											$term_list = get_the_terms(get_the_ID(), 'category' );
											if( $term_list ){
												echo '<div class="mag-item-cat-wr">';
													foreach( $term_list as $value ){
													$bg_color = '';
													$term_data = get_term_meta( $value->term_id, '_custom_category_options', true );
													if(isset($term_data['post_cat_color'])){
														$bg_color = 'style="background-color:'.$term_data['post_cat_color'].';"';
													}
														echo '<div class="mag-item-cat '.($cat_type=="type_2"?"type-2": "").'" '.($cat_type=="type_1"?"$bg_color": "").'><a href="'.get_term_link($value->term_id).'">'.$value->name.'</a></div>';
													}
												echo '</div>';
											}
										?>
										<div class="sub-title sm"><i><?php the_time(get_option('date_format'));?></i></div>
										<div class="empty-sm-5 empty-xs-5"></div>
										<div class="caption type-2">
											<h3 class="h4 lg title no-tr">
												<a href="<?php the_permalink();?>" class="text-line-animate"><?php the_title();?></a>
											</h3>
										</div>
										<div class="empty-sm-15 empty-xs-15"></div>
										<div class="simple-text">
											<p><?php echo wp_trim_words( get_the_excerpt(), 25, ' ...' ); ?></p>
										</div>
										<div class="empty-sm-35 empty-xs-30"></div>
										<div class="user-bar">
											<?php echo get_avatar( get_the_author_meta( 'ID' ), 32 ); ?>
											<h6 class="h8"><a href="<?php echo get_author_posts_url( get_the_ID(), get_the_author_meta( "user_nicename" ) ); ?>"><?php the_author(); ?></a></h6>
										</div>
									</div>
								<?php }
								wp_reset_postdata();
								?>
							</div>
							<div class="pagination type-2 align-left-bottom colo-type-5"></div> 
						</div>
					</div>
				<?php }
				elseif ($type == 'creative') { ?>
					<div class="swiper-container two-side-slider" data-mode="horizontal" data-autoplay="0" data-effect="slide" data-slides-per-view="responsive" data-loop="0" data-speed="800" data-add-slides="3" data-lg-slides="3" data-md-slides="3" data-sm-slides="2" data-xs-slides="1">
						<div class="swiper-wrapper">
							<?php while ( $query->have_posts() ) {
							$query->the_post() ?>
								<div class="swiper-slide">
									<div class="mag-item min-h-md">
										<?php 
											$term_list = get_the_terms(get_the_ID(), 'category' );
											if( $term_list ){
												echo '<div class="mag-item-cat-wr">';
												foreach( $term_list as $value ){
													$bg_color = '';
													$term_data = get_term_meta( $value->term_id, '_custom_category_options', true );
													if(isset($term_data['post_cat_color'])){
														$bg_color = 'style="background-color:'.$term_data['post_cat_color'].';"';
													}
													echo '<div class="mag-item-cat '.($cat_type=="type_2"?"type-2": "").'" '.($cat_type=="type_1"?"$bg_color": "").'><a href="'.get_term_link($value->term_id).'">'.$value->name.'</a></div>';
												}
												echo '</div>';
											}
										?>
										<div class="bg layer-hold type-4" style="background-image: url(<?php the_post_thumbnail_url(); ?>)"></div>
										<div class="mag-item-content">
											<div class="sub-title sm col-2"><i><?php echo the_time(get_option('date_format'));?></i></div>
											<div class="empty-sm-5 empty-xs-5"></div>
											<div class="caption type-2">
												<h3 class="h3 lg title h-no-transform">
													<a href="<?php the_permalink();?>" class="text-line-animate"><?php the_title();?></a>
												</h3>
											</div>
											<div class="empty-sm-15 empty-xs-15"></div>
											<div class="info-bar type-2">
												<?php
													nrg_premium_get_simple_likes_button(get_the_ID());
													$comments_count = wp_count_comments(get_the_ID());
													echo wp_kses_post( '<div><i class="fa fa-comment-o"></i><span>'.$comments_count->total_comments.'</span></div>' );
												?>
											</div>
										</div>
									</div>
								</div>
							<?php }
							wp_reset_postdata();
							?>
						</div>
					</div>
				<?php }
				elseif ($type == 'creative_one') { ?>
					<div class="swiper-container" data-mode="horizontal" data-autoplay="0" data-effect="slide" data-slides-per-view="1" data-loop="0" data-speed="800" >
						<div class="swiper-wrapper">
							<?php while ( $query->have_posts() ) {
							$query->the_post() ?>
								<div class="swiper-slide">
									<?php if ($subtype_cr_one=='wide_tall' || $subtype_cr_one=='tall' ) { ?>
										<div class="mag-item min-h-md <?php echo ($subtype_cr_one=='wide_tall'?'item-type-2':'')?>">
											<?php
												if ($cat_visib == 'enable') {  
													$term_list = get_the_terms(get_the_ID(), 'category' );
													if( $term_list ){
														$cat_align = '';
														if ($pag_align=='left'){$cat_align = 'mag-item-r';}
														echo '<div class="mag-item-cat-wr '.$cat_align.'">';
														foreach( $term_list as $value ){
															$bg_color = '';
															$term_data = get_term_meta( $value->term_id, '_custom_category_options', true );
															if(isset($term_data['post_cat_color'])){
																$bg_color = 'style="background-color:'.$term_data['post_cat_color'].';"';
															}
															echo '<div class="mag-item-cat '.($cat_type=="type_2"?"type-2": "").'" '.($cat_type=="type_1"?"$bg_color": "").'><a href="'.get_term_link($value->term_id).'">'.$value->name.'</a></div>';
														}
														echo '</div>';
													}
												}
											?>
											<div class="bg layer-hold type-4" style="background-image: url(<?php the_post_thumbnail_url(); ?>)"></div>
											<div class="mag-item-content">
												<div class="sub-title sm col-2"><i><?php the_time(get_option('date_format'));?></i></div>
												<div class="empty-sm-5 empty-xs-5"></div>
												<div class="caption type-2">
													<h3 class="h3 title <?php echo ($subtype_cr_one=='tall'? 'lg h-no-transform':'')?>">
														<a href="<?php the_permalink(); ?>" class="text-line-animate <?php echo ($subtype_cr_one=='wide_tall'?'sm':'')?>"><?php the_title(); ?></a>
													</h3>
												</div>
												<div class="empty-sm-15 empty-xs-15"></div>
												<div class="simple-text col-6 <?php echo ($subtype_cr_one=='tall'?'sm':'')?>">
													<p><?php echo wp_trim_words( get_the_excerpt(), 25, ' ...' ); ?></p>
												</div>
												<?php if ($com_visib == 'enable') {  ?>
													<div class="empty-sm-20 empty-xs-20"></div>
													<div class="info-bar type-2">
														<?php
															nrg_premium_get_simple_likes_button(get_the_ID());
															$comments_count = wp_count_comments(get_the_ID());
															echo wp_kses_post( '<div><i class="fa fa-comment-o"></i><span>'.$comments_count->total_comments.'</span></div>' );
														?>
													</div>
												<?php } ?>
											</div>
										</div>
									<?php } elseif ($subtype_cr_one=='tall_center') { ?>
										<div class="news-item lg flex-align text-center">
											<div class="bg layer-hold type-4" style="background-image: url(<?php the_post_thumbnail_url();?>)"></div>
											<div class="caption type-2">
												<div class="sub-title sm col-2 second-font"><i><?php the_time(get_option('date_format'));?></i></div>
												<div class="empty-sm-5 empty-xs-5"></div>
												<h4 class="h4 lg title"><a href="<?php the_permalink();?>" class="text-line-animate"><?php the_title();?></a></h4>
												<div class="empty-sm-20 empty-xs-20"></div>
												<div class="info-bar type-2">
													<?php
														nrg_premium_get_simple_likes_button(get_the_ID());
														$comments_count = wp_count_comments(get_the_ID());
														echo wp_kses_post( '<div><i class="fa fa-comment-o"></i><span>'.$comments_count->total_comments.'</span></div>' );
													?>
												</div>
											</div>
										</div>
									<?php } elseif ($subtype_cr_one=='tall_center_bottom') { ?>
										<div class="mag-item min-h-sm">
											<div class="bg layer-hold type-4" style="background-image: url(<?php the_post_thumbnail_url();?>)"></div>
											<div class="info-bar type-2 top-align">
												<?php
													nrg_premium_get_simple_likes_button(get_the_ID());
													$comments_count = wp_count_comments(get_the_ID());
													echo wp_kses_post( '<div><i class="fa fa-comment-o"></i><span>'.$comments_count->total_comments.'</span></div>' );
												?>
											</div>
											<div class="mag-item-content">
												<div class="sub-title sm col-2"><i><?php the_time(get_option('date_format'));?></i></div>
												<div class="empty-sm-5 empty-xs-5"></div>
												<div class="caption type-2">
													<h3 class="h6 title">
														<a href="<?php the_permalink();?>" class="text-line-animate"><?php the_title();?></a>
													</h3>
												</div>
												<div class="empty-sm-15 empty-xs-15"></div>
												<div class="simple-text col-6 sm">
													<i><p><?php echo wp_trim_words( get_the_excerpt(), 25, ' ...' ); ?></p></i>
												</div>
											</div>
										</div>
									<?php } ?>
								</div>
							<?php }
							wp_reset_postdata();
							?>
						</div>
						
						<?php $poz = '';
						if ($pag_align=='right') { 
							$poz = 'align-right-top';
						} elseif ($pag_align=='left') {
							$poz = 'align-left-top';
						} ?>
						<div class="pagination type-2 colo-type-5 <?php echo $poz; ?>"></div>
					</div>
				<?php }
				elseif ($type == 'panorama') { ?>
					<div class="arrow-closest relative">
						<div class="swiper-container full-h" data-mode="horizontal" data-autoplay="0" data-effect="slide" data-slides-per-view="1" data-loop="0" data-speed="800" >
							<div class="swiper-wrapper">
								<?php while ( $query->have_posts() ) {
								$query->the_post() ?>
									<div class="swiper-slide">
										<div class="news-item md border-b flex-align text-center"> 
											<div class="bg layer-hold" style="background-image: url(<?php the_post_thumbnail_url();?>)"></div>  
											<div class="caption type-2">
												<div class="sub-title sm col-1 second-font"><i><?php echo the_time(get_option('date_format'));?></i></div>
												<div class="empty-sm-5 empty-xs-5"></div>
												<h4 class="h4 title">
													<a href="<?php the_permalink();?>" class="text-line-animate"><?php the_title();?></a>
												</h4>
												<div class="empty-sm-15 empty-xs-15"></div>
												<div class="info-bar type-2">
													<?php
														nrg_premium_get_simple_likes_button(get_the_ID());
														$comments_count = wp_count_comments(get_the_ID());
														echo wp_kses_post( '<div><i class="fa fa-comment-o"></i><span>'.$comments_count->total_comments.'</span></div>' );
													?>
												</div>
											</div>
										</div>
									</div>
								<?php }
								wp_reset_postdata();
								?>
							</div>
						</div>
						<div class="swiper-arrow-left slider-arrow-1 type-2"><i class="fa fa-angle-left"></i></div>
						<div class="swiper-arrow-right slider-arrow-1 type-2"><i class="fa fa-angle-right"></i></div>
					</div>
				<?php }
				elseif ($type == 'classic_border') { ?>
					<div class="arrow-closest arrow-align-bottom">
						<div class="swiper-container full-h" data-mode="horizontal" data-autoplay="0" data-effect="slide" data-slides-per-view="1" data-loop="0" data-speed="800" >
							<div class="swiper-wrapper">
								<?php while ( $query->have_posts() ) {
								$query->the_post() ?>
									<div class="swiper-slide">
										<div class="mag-item-1 hover-block type-4 padd-inset">
											<a href="<?php the_permalink(); ?>" class="image hover-layer bg-col-5">
												<img src="<?php the_post_thumbnail_url();?>" alt="" class="resp-img">  
											</a>
											<div class="text">
												<div class="sub-title sm col-13 second-font"><i><?php the_time(get_option('date_format')); ?></i></div>
												<div class="empty-sm-5 empty-xs-5"></div>
												<div class="caption">
													<h3 class="h4 title no-tr">
														<a href="<? the_permalink();?>" class="text-line-animate sm"><?php the_title();?></a>
													</h3>
												</div>
												<div class="empty-sm-15 empty-xs-15"></div>
												<div class="simple-text sm col-1">
													<p><?php echo wp_trim_words( get_the_excerpt(), 25, ' ...' ); ?></p>
												</div>
												<div class="empty-sm-20 empty-xs-20"></div>
												<a href="<?php the_permalink();?>" class="news-link"><?php echo esc_html__('read more', 'nrg_premium');?></a> 
												<div class="fr">
													<div class="info-bar">
														<?php
															nrg_premium_get_simple_likes_button(get_the_ID());
															$comments_count = wp_count_comments(get_the_ID());
															echo wp_kses_post( '<div><i class="fa fa-comment-o"></i><span>'.$comments_count->total_comments.'</span></div>' );
														?>
													</div>
												</div>
												<div class="empty-sm-50 empty-xs-50"></div>
											</div>
										</div>
									</div>
								<?php }
								wp_reset_postdata();
								?>
							</div>
							<div class="pagination type-2 colo-type-6"></div>
						</div>
						<div class="swiper-arrow-left slider-arrow-1 type-5 md"><i class="fa fa-angle-left"></i></div>
						<div class="swiper-arrow-right slider-arrow-1 type-5 md"><i class="fa fa-angle-right"></i></div>
					</div>
				<?php } ?>
			</div>
	<?php }
		return  ob_get_clean();
	}
}