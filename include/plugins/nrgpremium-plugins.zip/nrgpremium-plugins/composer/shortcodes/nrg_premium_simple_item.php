<?php 
/*
** Image Box
** Author: NRGTHEMES
** Author URI: http://nrgthemes.com
** Version: 1.0.0 
*/

vc_map( array(
	'name'                    => __( 'Simple item', 'nrg_premium' ),
	'base'                    => 'nrg_premium_simple_item_1',
	'category' 				  => __( 'NRGPremium', 'nrg_premium' ),
	'content_element'         => true,
	'show_settings_on_create' => true,
	'params'          => array(
		array(
			'type'			=> 'dropdown',
			'heading'		=> __( 'Type', 'nrg_premium' ),
			'param_name'	=> 'type',
			'value'			=> array(
				'Type 1'		=> 'type_1',
				'Type 2'		=> 'type_2',
			),
		),
		array(
			'type'			=> 'attach_image',
			'heading'		=> __( "Image", "nrg_premium" ),
			'param_name'	=> 'image',
			'admin_label'	=> true,
			'description'	=> 'Upload your image.'
		),
		array(
			'type'			=> 'textfield',
			'heading'		=>  __( "Title", "nrg_premium" ),
			'param_name'	=> 'title',
			'admin_label'	=> true,
			'value'			=> '',
		),
		array(
			'type' => 'vc_link',
			'heading'		=> __( 'Item Link', 'nrg_premium' ),
			'param_name'	=> 'link',
			'value'			=> '#',
			'description'	=> __( 'Item link', 'nrg_premium' ),
		),
		array(
			'type'			=> 'textfield',
			'heading'		=>  __( "Subtitle", "nrg_premium" ),
			'param_name'	=> 'subtitle',
			'admin_label'	=> true,
			'value'			=> '',
		),
		array(
			'type'			=> 'checkbox',
			'heading'		=> __( 'Button Y/N', 'nrg_premium' ),
			'param_name'	=> 'button_y_n',
		),
		array(
			'type'			=> 'textfield',
			'heading'		=> __( 'Button text', 'nrg_premium' ),
			'param_name'	=> 'button_text',
			'admin_label'	=> true,
			'value'			=> '',
			'description'	=> __( 'Button text', 'nrg_premium' ),
			'dependency'	=> array( 'element' => 'button_y_n', 'value' => 'true'),
		),
		array(
			'type'			=> 'textarea',
			'heading'		=> __( 'Short Description', 'nrg_premium' ),
			'param_name'	=> 'short_desc',
		),
		array(
			'type'			=> 'textfield',
			'heading'		=> __( 'Extra class name', 'nrg_premium' ),
			'param_name'	=> 'el_class',
			'description'	=> __( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'nrg_premium' ),
			'value'			=> '',
		),
		array(
			'type'			=> 'css_editor',
			'heading'		=> __( 'CSS box', 'nrg_premium' ),
			'param_name'	=> 'css',
			'group'			=> __( 'Design options', 'nrg_premium' ),
		),
	) //end params
) );

class WPBakeryShortCode_nrg_premium_simple_item_1 extends WPBakeryShortCode {
	protected function content( $atts, $content = null) {

		extract( shortcode_atts( array(
			'el_class'		=> '',
			'css'			=> '',
			'title'			=> '',
			'subtitle'		=> '',
			'image'			=> '',
			'button_text'	=> '',
			'link'			=> '',
			'button_y_n'	=> false,
			'type'			=> 'type_1',
			'short_desc'	=> '',
			
 		), $atts ) );

		$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, $this->settings['base'], $atts );
		
		// custum css
		$css_class .= vc_shortcode_custom_css_class( $css, ' ' );

		// custum class
		$css_class .= (!empty($el_class)) ? ' '.$el_class : '';

		 $link_f = '#';
			if ($link) {
				$link_n = vc_build_link($link);
				$link_f = esc_html($link_n['url']);
			}
		

		$image_html = '';
			if ($image) {
			$image_full = wp_get_attachment_image_url( $image, 'full' );
			$image_html = '<div class="image"><img src="'. esc_url( $image_full ). '" alt="image" class="resp-img"></div>';
			}
 		// output
		ob_start();
		do_shortcode( $content );
		?>
		<!--ICON BOX-->
		<div class="<?php print esc_attr( $css_class ); ?>">
			<?php if ($type == 'type_1') { ?>
				<div class="image">
					<img src="<?php echo esc_url(wp_get_attachment_image_url( $image, 'full'));?>" alt="image" class="resp-img">
				</div>
				<div class="empty-sm-25 empty-xs-25"></div>
				<div class="text type-2">
					<?php if ($title) { ?>
						<h3 class="h3 title">
							<a href="<?php print $link_f ?>"><?php print esc_html($title) ?></a>
						</h3>
					<?php } ?>
					<?php if ($subtitle) { ?>
						<div class="empty-sm-15 empty-xs-15"></div> 
						<div class="sub-title col-2"><?php print wp_kses_post($subtitle) ?></div>  
					<?php } ?>
					<?php if ($button_y_n == true) { 
						if ($button_text) {  ?>
							<div class="empty-sm-30 empty-xs-30"></div> 
							<a href="<?php print $link_f ?>" class="link-style-4 main-link" data-text="<?php print esc_html($button_text);?>">
								<span><?php print esc_html($button_text);?></span>
							</a>
						<?php } ?>
					<?php } ?>
				</div>

			<?php } elseif ($type == 'type_2') { ?>
				<div class="simple-item-1">  
					<a href="<?php print $link_f ?>" class="hover-block">
						<span class="hover-layer image bg-col-7">
							<img src="<?php echo esc_url(wp_get_attachment_image_url( $image, 'full'));?>" alt="image" class="full-img">
						</span>  
					</a>
					<div class="empty-sm-25 empty-xs-25"></div>
					<div class="caption">
						<?php if ($title) { ?>
							<h5 class="h5 title link-hover-5 bold">
								<a href="<?php print $link_f ?>"><?php print esc_html($title) ?></a>
							</h5>
						<?php }
						if ($subtitle) { ?>
							<div class="empty-sm-10 empty-xs-10"></div>
							<div class="sub-desc col-4"><?php print esc_html($subtitle) ?></div>
						<?php } ?>
					</div>
					<?php if ($short_desc) { ?>
						<div class="empty-sm-15 empty-xs-15"></div> 
						<div class="simple-text col-1">
							<p><?php echo wp_kses_post($short_desc);?></p>
						</div>
					<?php } ?>
				</div>
			<?php } ?>

		</div>
		<?php 
		return  ob_get_clean();
	}
}