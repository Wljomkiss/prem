<?php 
/*
** Contact Info
** Author: NRGTHEMES
** Author URI: http://nrgthemes.com
** Version: 1.0.0 
*/

vc_map( array(
	'name'                    => __( 'Contact Info', 'nrg_premium' ),
	'base'                    => 'nrg_premium_contact_info',
	'category' 				  => __( 'NRGPremium', 'nrg_premium' ),
	'content_element'         => true,
	'show_settings_on_create' => true,
	'description' 		      => __( 'Contact info for contat form', 'nrg_premium' ),
	'params'          => array(
		array(
			'type'        => 'dropdown',
			'heading'     => __( 'Contact info type', 'nrg_premium' ),
			'param_name'  => 'c_info_type',
			'value'       => array(
				'Type 1'   => 'type_1',
				'Type 2'   => 'type_2',
				'Type 3'   => 'type_3',
				'Type 4'   => 'type_4',
				'Type 5'   => 'type_5',
			),
		),
		array(
			'type'			=> 'dropdown',
			'heading'		=> __( 'Contact info color type', 'nrg_premium' ),
			'param_name'	=> 'col_t_3',
			'value'			=> array(
				'Dark'			=> 'dark',
				'Light'			=> 'light',
			),
			'dependency'  => array( 'element' => 'c_info_type', 'value' => 'type_3'),
		),
		array(
			'type'        => 'attach_image',
			'heading'     => __( 'Address icon', "nrg_premium" ),
			'param_name'  => 'address_icon',
			'admin_label' => true,
			'description' => 'Upload your image.',
			'dependency'  => array( 'element' => 'c_info_type', 'value' => 'type_3'),
		),
		array(
			'type'        => 'textfield',
			'heading'     => __( 'Heading', 'nrg_premium' ),
			'param_name'  => 'heading',
			'admin_label' => true,
			'value'       => '',
			'dependency'  => array( 'element' => 'c_info_type', 'value' => 'type_4'),
		),
		array(
			'type'        => 'textfield',
			'heading'     => __( 'Address', 'nrg_premium' ),
			'param_name'  => 'address',
			'admin_label' => true,
			'value'       => '',
		),
		array(
			'type'        => 'attach_image',
			'heading'     => __( 'Phone icon', "nrg_premium" ),
			'param_name'  => 'phone_icon',
			'admin_label' => true,
			'description' => 'Upload your image.',
			'dependency'  => array( 'element' => 'c_info_type', 'value' => 'type_3'),
		),
		array(
			'type'        => 'textfield',
			'heading'     => __( 'Phone number', 'nrg_premium' ),
			'param_name'  => 'phone',
			'admin_label' => true,
			'value'       => '',
		),
		array(
			'type'        => 'attach_image',
			'heading'     => __( 'Email icon', "nrg_premium" ),
			'param_name'  => 'email_icon',
			'admin_label' => true,
			'description' => 'Upload your image.',
			'dependency'  => array( 'element' => 'c_info_type', 'value' => 'type_3'),
		),
		array(
			'type'        => 'textfield',
			'heading'     => __( 'Email', 'nrg_premium' ),
			'param_name'  => 'email',
			'admin_label' => true,
			'value'       => '',
		),
		array(
			'type' => 'textfield',
			'heading' => __( 'Extra class name', 'nrg_premium' ),
			'param_name' => 'el_class',
			'description' => __( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'nrg_premium' ),
			'value' => '',
		),
		array(
			'type' => 'css_editor',
			'heading' => __( 'CSS box', 'nrg_premium' ),
			'param_name' => 'css',
			'group' => __( 'Design options', 'nrg_premium' ),
		),
	) //end params
) );

class WPBakeryShortCode_nrg_premium_contact_info extends WPBakeryShortCode {
	protected function content( $atts, $content = null) {

		extract( shortcode_atts( array(
			'el_class'      => '',
			'css'           => '',
			'c_info_type'	=> 'type_1',
			'address_icon'  => '',
			'phone_icon' 	=> '',
			'email_icon'	=> '',
			'email'			=> '',
			'phone'			=> '',
			'address'		=> '',
			'heading'		=> '',
			'col_t_3'		=> 'dark',
 		), $atts ) );

		$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, $this->settings['base'], $atts );
		
		// custum css
		$css_class .= vc_shortcode_custom_css_class( $css, ' ' );

		// custum class
		$css_class .= (!empty($el_class)) ? ' '.$el_class : '';

		// address icon
		$address_icon_html = '';
		if (!empty($address_icon)) {
		$address_icon_full = wp_get_attachment_image_url( $address_icon, 'full' );
		$address_icon_html = '<div class="icon"><img src="'.esc_url( $address_icon_full ).'" alt=""></div>';
		}

		// phone icon
		$phone_icon_html = '';
		if (!empty($phone_icon)) {
		$phone_icon_full = wp_get_attachment_image_url( $phone_icon, 'full' );
		$phone_icon_html = '<div class="icon"><img src="'.esc_url( $phone_icon_full ).'" alt=""></div>';
		}

		// email icon
		$email_icon_html = '';
		if (!empty($email_icon)) {
		$email_icon_full = wp_get_attachment_image_url( $email_icon, 'full' );
		$email_icon_html = '<div class="icon"><img src="'.esc_url( $email_icon_full ).'" alt=""></div>';
		}

		// output
		ob_start();
		do_shortcode( $content );
		?>
		<!--CONTACT INFO-->
		<div class="<?php print esc_attr( $css_class ); ?>">
			<?php if ($c_info_type == 'type_1') { ?>
				<div class="row">
					<?php if ($address) { ?>
						<div class="col-md-6">
							<div class="address-item">
								<h6 class="h6 title second-font"><?php print esc_html__( 'Address', 'nrg_premium' )?></h6>
								<div class="empty-sm-15 empty-xs-15"></div>
								<p><?php print wp_kses_post($address) ?></p>
								<div class="empty-sm-20 empty-xs-20"></div>
							</div>
						</div>
					<?php } ?>
					<?php if ($phone || $email) { ?>
						<div class="col-md-6">
							<div class="address-item">
								<h6 class="h6 title second-font"><?php print esc_html__( 'Contact Us', 'nrg_premium' )?></h6>
								<div class="empty-sm-15 empty-xs-15"></div>
								<?php $output_cont = preg_replace( '/[^0-9]/', '', $phone);
									if (is_numeric($output_cont)) { ?>
									<div class="link">
										<span><?php print esc_html__( 'Phone:', 'nrg_premium' )?></span>
										<a href="tel:+<?php print esc_html($output_cont) ?>"><?php print esc_html($phone);?></a>
									</div>
									<div class="empty-sm-10 empty-xs-10"></div>
								<?php } ?>
								<?php if ($email) { ?>
									<div class="link">
										<span><?php print esc_html__( 'Email:', 'nrg_premium' )?></span>
										<a href="mailto:<?php print esc_html($email); ?>"><?php print esc_html($email); ?></a>
									</div>
								<?php } ?>
							</div>
						</div>
					<?php } ?>
				</div>
			<?php } elseif ($c_info_type == 'type_2') { ?>
				<ul class="custome-padd-120">
					<?php if ($address) { ?>
						<li class="address-item type-1">
							<div class="empty-sm-15 empty-xs-15"></div>
							<h6 class="h7 title"><?php print esc_html__( 'Address', 'nrg_premium' )?></h6>
							<div class="empty-sm-10 empty-xs-10"></div>
							<p><?php print wp_kses_post($address) ?></p> 
							<div class="empty-sm-25 empty-xs-25"></div>
						</li>
					<?php }
					$output_cont = preg_replace( '/[^0-9]/', '', $phone);
						if (is_numeric($output_cont)) { ?>
						<li class="address-item type-1">
							<div class="empty-sm-15 empty-xs-15"></div>
							<h6 class="h7 title"><?php print esc_html__( 'Reseption:', 'nrg_premium' )?></h6>
							<div class="empty-sm-10 empty-xs-10"></div>
							<div class="link">
								<a href="tel:+<?php print esc_html($output_cont) ?>"><?php print esc_html($phone);?></a>
							</div>
							<div class="empty-sm-25 empty-xs-25"></div>
						</li>
					<?php }
					if ($email) { ?>
						<li class="address-item type-1">
							<div class="empty-sm-15 empty-xs-15"></div>
							<h6 class="h7 title"><?php print esc_html__( 'Email:', 'nrg_premium' )?></h6>
							<div class="empty-sm-10 empty-xs-10"></div>
							<div class="link">
								<a href="mailto:<?php print esc_html($email) ?>"><?php print esc_html($email);?></a>
							</div>
							<div class="empty-sm-25 empty-xs-25"></div>
						</li>
					<?php } ?>
				</ul>
			<?php } elseif ($c_info_type == 'type_3') { ?> 
				<ul>
					<?php if ($address) { ?>
						<li class="address-item type-3 <?php echo esc_html($col_t_3 == 'light'? 'col-light' : '');?>">
							<?php print $address_icon_html ?>
							<div class="txt">
								<h6 class="h7 title"><?php print esc_html__( 'Address', 'nrg_premium' )?></h6>
								<p><?php print wp_kses_post($address) ?></p> 
							</div>
							<div class="empty-sm-25 empty-xs-25"></div>
						</li>
					<?php } ?>
					<?php $output_cont = preg_replace( '/[^0-9]/', '', $phone);
						if (is_numeric($output_cont)) { ?>
						<li class="address-item type-3 <?php echo esc_html($col_t_3 == 'light'? 'col-light' : '');?>">
							<div class="empty-sm-25 empty-xs-25"></div>
							<?php print $phone_icon_html ?>
							<div class="txt">
								<h6 class="h7 title"><?php print esc_html__( 'Reseption:', 'nrg_premium' )?></h6>
								<div class="link">
									<a href="tel:+<?php print esc_html($output_cont) ?>"><?php print esc_html($phone); ?></a>
								</div>
							</div>
							<div class="empty-sm-25 empty-xs-25"></div>
						</li>
					<?php } ?>
					<?php if ($email) { ?>
						<li class="address-item type-3 <?php echo ($col_t_3 == 'light'? 'col-light' : '');?>">
							<div class="empty-sm-25 empty-xs-25"></div>
							<?php print $email_icon_html ?>
							<div class="txt">
								<h6 class="h7 title"><?php print esc_html__( 'Email:', 'nrg_premium' )?></h6>
								<div class="link">
									<a href="mailto:<?php print esc_html($email) ?>"><?php print esc_html($email) ?></a>
								</div>
							</div>
							<div class="empty-sm-25 empty-xs-25"></div> 
						</li>
					<?php } ?>
				</ul>
			<?php } elseif ($c_info_type == 'type_4') { ?>
				<?php if ($heading) { ?>
					<div class="text-center">
						<div class="office-title h4"><?php echo esc_html($heading); ?></div>
						<div class="empty-sm-40 empty-xs-30"></div>
					</div>
				<?php } ?>
				<ul class="custome-padd-200">
					<?php if ($address) { ?>
						<li class="address-item type-4">
							<div class="empty-sm-15 empty-xs-15"></div>
							<h6 class="h7 title"><?php print esc_html__( 'Address: ', 'nrg_premium' )?></h6>
							<div class="empty-sm-10 empty-xs-10"></div>
							<p><?php print wp_kses_post($address) ?></p> 
							<div class="empty-sm-25 empty-xs-25"></div>
						</li>
					<?php } 
					$output_cont = preg_replace( '/[^0-9]/', '', $phone);
						if (is_numeric($output_cont)) { ?>
						<li class="address-item type-4">
							<div class="empty-sm-15 empty-xs-15"></div>
							<h6 class="h7 title"><?php print esc_html__( 'Reseption:', 'nrg_premium' )?></h6>
							<div class="empty-sm-10 empty-xs-10"></div>
							<div class="link">
							<a href="tel:+<?php print esc_html($output_cont) ?>"><?php print esc_html ($phone) ?></a>
							</div>
							<div class="empty-sm-25 empty-xs-25"></div>
						</li>
					<?php }
					if ($email) { ?>
						<li class="address-item type-4">
							<div class="empty-sm-15 empty-xs-15"></div>
							<h6 class="h7 title"><?php print esc_html__( 'Email:', 'nrg_premium' )?></h6>
							<div class="empty-sm-10 empty-xs-10"></div>
							<div class="link">
							<a href="mailto:<?php print esc_html($email) ?>"><?php print esc_html($email) ?></a>
							</div>
							<div class="empty-sm-25 empty-xs-25"></div>
						</li>
					<?php } ?>
				</ul>
            <?php } elseif ($c_info_type == 'type_5') { ?>
				<div class="row">
					<div class="col-md-4">
						<?php if ($address) { ?>
							<div class="address-item">
								<h6 class="h7 title"><?php print esc_html__( 'Address: ', 'nrg_premium' )?></h6>
								<div class="empty-sm-15 empty-xs-15"></div>
								<p><?php print wp_kses_post($address) ?></p>
								<div class="empty-sm-25 empty-xs-25"></div>
							</div>
						<?php } ?>
					</div>
					<div class="col-md-4">
						<?php $output_cont = preg_replace( '/[^0-9]/', '', $phone);
						if (is_numeric($output_cont)) { ?>
							<div class="address-item">
								<h6 class="h7 title"><?php print esc_html__( 'Phone: ', 'nrg_premium' )?></h6>
								<div class="empty-sm-15 empty-xs-15"></div>
								<div class="link sm">
									<a href="tel:<?php print esc_html($output_cont) ?>" class="link-hover-4"><?php print esc_html ($phone) ?></a>
								</div>
								<div class="empty-sm-25 empty-xs-25"></div>
							</div>
						<?php } ?>
					</div>
					<div class="col-md-4">
						<?php if ($email) { ?>
							<div class="address-item">
								<h6 class="h7 title"><?php print esc_html__( 'Email ', 'nrg_premium' )?></h6>
								<div class="empty-sm-15 empty-xs-15"></div>
								<div class="link sm">
									<a href="mailto:<?php print esc_html($email) ?>" class="link-hover-4"><?php print esc_html($email) ?></a>
								</div>
								<div class="empty-sm-25 empty-xs-25"></div>
							</div>
						<?php } ?>
					</div>
				</div>
            <?php } ?>
		</div>
		<?php 
		return  ob_get_clean();
	}
}