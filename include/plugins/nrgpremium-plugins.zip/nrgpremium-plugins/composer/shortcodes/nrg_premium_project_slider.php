<?php 
/*
** Projects
** Author: NRGTHEMES
** Author URI: http://nrgthemes.com
** Version: 1.0.0 
*/

vc_map( array(
	'name'                    => __( 'Projects slider', 'nrg_premium' ),
	'base'                    => 'nrg_premium_projects',
	'category' 				  => __( 'NRGPremium', 'nrg_premium' ),
	'content_element'         => true,
	'show_settings_on_create' => true,
	'description'             => __( 'Projects slider', 'nrg_premium'),
	'params'          => array(
		array(
			'type'        => 'textfield',
			'heading'     =>  __( 'Count of projects', 'nrg_premium' ),
			'param_name'  => 'count',
			'admin_label' => true,
			'value'       => '',
		),
		array(
			'type' => 'textfield',
			'heading' => __( 'Extra class name', 'nrg_premium' ),
			'param_name' => 'el_class',
			'description' => __( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'nrg_premium' ),
			'value' => '',
		),
		array(
			'type' => 'css_editor',
			'heading' => __( 'CSS box', 'nrg_premium' ),
			'param_name' => 'css',
			'group' => __( 'Design options', 'nrg_premium' ),
		),
	) //end params
) );

class WPBakeryShortCode_nrg_premium_projects extends WPBakeryShortCode {
	protected function content( $atts, $content = null) {

		extract( shortcode_atts( array(
			'el_class'     => '',
			'css'          => '',
			'count'		   => '5',
 		), $atts ) );

		$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, $this->settings['base'], $atts );
		
		// custum css
		$css_class .= vc_shortcode_custom_css_class( $css, ' ' );

		// custum class
		$css_class .= (!empty($el_class)) ? ' '.$el_class : '';

		$count_number = '';
		if (is_numeric($count)) {
			$count_number = $count;
		} else {
			$count_number = 5;
		}

 		// output
		ob_start();
		do_shortcode( $content );
		?>
		<!--Projects-->
		<div class="<?php print esc_attr( $css_class ); ?>">
			<div class="swiper-container" data-mode="horizontal" data-autoplay="0" data-effect="slide" data-slides-per-view="responsive" data-loop="0" data-speed="800" data-add-slides="5" data-lg-slides="5" data-md-slides="3" data-sm-slides="2" data-xs-slides="1">
				<div class="swiper-wrapper">
					<?php 	$args = array(
							'post_type' 	 => 'projects',
							'posts_per_page' => preg_replace("/[^0-9]/", "", $count_number ),
						); 
						$query = new WP_Query($args);
						$max_pages = $query->max_num_pages;
						if( $query->have_posts() ){
							while ( $query->have_posts() ){ $query->the_post();  ?>
								<div class="swiper-slide">
									<div class="project-item ">
										<?php if (has_post_thumbnail()) { ?>
											<div class="bg" style="background-image: url(<?php the_post_thumbnail_url();?>)"></div> 
										<?php } ?>
										<div class="project-item-desc flex-align">
											<div class="text type-2">
												<h6 class="h6 title"><a href="<?php the_permalink();?>"><?php the_title(); ?></a></h6>
												<?php 
													$_options = get_post_meta( get_the_ID(), '_custom_projects_options', true );
													if (isset($_options['subtitle_project'])) { ?>
														<div class="sub-title sm ls col-2">
															<?php print ( $_options['subtitle_project'] ); ?>
														</div>
													<?php }
												?>
												<div class="empty-sm-15 empty-xs-15"></div>
												<?php if (has_excerpt()) { ?>
													<div class="simple-text col-3">
														<p><?php the_excerpt();?></p>
													</div>
												<?php } ?>
											</div> 
										</div>   
									</div>
								</div>
							<?php } ?>
						<?php wp_reset_postdata(); ?>
					<?php }?>
				</div>
				<div class="pagination pagination-hide"></div>
			</div>
		</div>
		<?php 
		return  ob_get_clean();
	}
}