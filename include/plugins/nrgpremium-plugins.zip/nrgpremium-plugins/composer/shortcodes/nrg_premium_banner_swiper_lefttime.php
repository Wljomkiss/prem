<?php 
/*
** Left time slider
** Version: 1.0.0 
*/

vc_map( array(
	'name'						=> __( 'Left time slider', 'nrg_premium' ),
	'base'						=> 'nrg_premium_left_time',
	'as_parent'					=> array('only' => 'nrg_premium_left_time_item'),
	'content_element'			=> true,
	'show_settings_on_create'	=> false,
	'category'					=> __( 'NRGPremium', 'nrg_premium' ),
	'description'				=> __( 'Time left slider', 'nrg_premium'),
	'js_view'					=> 'VcColumnView',
	'params'					=> array(
		array(
			'type'			=> 'dropdown',
			'heading'		=> __( 'Pagination enable', 'nrg_premium' ),
			'param_name'	=> 'pagination_enable',
			'value'			=> array(
				'Enable'		=> 'enable',
				'Disable'		=> 'disable',
			),
		),
		array(
			'type'			=> 'textfield',
			'heading'		=> __( 'Extra class name', 'nrg_premium' ),
			'param_name'	=> 'el_class',
			'description'	=> __( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'nrg_premium' ),
			'value'			=> '',
		),
		array(
			'type'			=> 'css_editor',
			'heading'		=> __( 'CSS box', 'nrg_premium' ),
			'param_name'	=> 'css',
			'group'			=> __( 'Design options', 'nrg_premium' ),
		),
	) //end params
) );

class WPBakeryShortCode_nrg_premium_left_time extends WPBakeryShortCodesContainer {

	protected function content( $atts, $content = null) {

		extract( shortcode_atts( array(
			'el_class'				=> '',
			'css'					=> '',
			'pagination_enable'		=> 'enable',

		), $atts ) );

		global $left_time_items;
		$left_time_items = array();

		$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, $this->settings['base'], $atts );

		// custum css
		$css_class .= vc_shortcode_custom_css_class( $css, ' ' );

		// custum class
		$css_class .= (!empty($el_class)) ? ' '.$el_class : '';

		// output
		ob_start();
		do_shortcode( $content );
		?>
		<div class="<?php print esc_attr( $css_class ); ?>">
			<div class="swiper-container gutter-15 pagination-bottom" data-mode="horizontal" data-autoplay="0" data-effect="slide" data-slides-per-view="responsive" data-loop="0" data-speed="800" data-add-slides="2" data-lg-slides="2" data-md-slides="2" data-sm-slides="1" data-xs-slides="1">
				<div class="swiper-wrapper">
					<?php $i = 0;
					foreach ($left_time_items as $key => $shortcode) {
						$shortcode_atts = $shortcode['atts'];
						$image_html = '';
						if (!empty($shortcode_atts['image'])) {
							$image_full = wp_get_attachment_image_url( $shortcode_atts['image'], 'full' );
							$image_html = '<div class="bg layer-hold" style="background-image: url('. esc_url( $image_full ). ')"></div>';
						} ?>
						<div class="swiper-slide">

							<div class="service-item lg-height style-2">
								<?php echo $image_html; ?> 
								<div class="vertical-align full">
									<div class="caption text-center type-2">
										<?php if(isset($shortcode_atts['subtitle'])) { ?>
											<div class="sub-title col-1 ls"><?php echo esc_html($shortcode_atts['subtitle']);?></div>
											<div class="empty-sm-10 empty-xs-10"></div>
										<?php } 
										if(isset($shortcode_atts['title']) && isset($shortcode_atts['link'])) { 
											$link = vc_build_link($shortcode_atts['link']);?>
											<h3 class="h4 sm title tt"><a href="<?php echo esc_url($link['url']);?>" class="link-hover-2"><?php echo esc_html($shortcode_atts['title']);?></a></h3>
										<?php } 
										if(isset($shortcode_atts['short_desc'])) { ?>
											<div class="empty-sm-10 empty-xs-10"></div> 
											<div class="simple-text col-3">
												<p><?php echo wp_kses_post($shortcode_atts['short_desc']); ?></p>
											</div>
										<?php } ?>
									</div>
									<div class="empty-sm-40 empty-xs-30"></div> 

									<?php if (isset($shortcode_atts['f_date']) && $shortcode_atts['f_date']) { ?>
										<div class="countdown countdown-type-2" data-line="0.03" data-end="<?php echo esc_html($shortcode_atts['f_date']);?>" data-fgcolor="<?php echo (isset($shortcode_atts['col']) ? esc_html($shortcode_atts['col']) : '#fff');?>" data-bgcolor="<?php echo (isset($shortcode_atts['bg_col']) ? esc_html($shortcode_atts['bg_col']) : 'rgba(227,116,32,0.8)');?>">

										</div>
									<?php } ?> 
								</div>
							</div>
						</div>
					<?php $i++; } ?>
				</div>
				<div class="empty-sm-50 empty-xs-50"></div>
				<div class="pagination type-2 colo-type-3"></div>
			</div>
		</div>
		<?php 
		return  ob_get_clean();
	}

}
/* Shortvode Item */

vc_map( array(
  'name'					=> 'Left time Item',
  'base'					=> 'nrg_premium_left_time_item',
  'as_child'				=> array('only' => 'nrg_premium_left_time'),
  'content_element'			=> true,
  'show_settings_on_create'	=> true,
  'description'				=> 'Left time item',
  'params'					=> array(
		array(
			'type'			=> 'attach_image',
			'heading'		=> __( 'Image', 'nrg_premium' ),
			'param_name'	=> 'image',
			'description'	=> 'Upload your image.'
		),
		array(
			'type'			=> 'textfield',
			'heading'		=> __( 'Title', 'nrg_premium' ),
			'param_name'	=> 'title',
			'admin_label'	=> true,
			'value'			=> '',
			'description'	=> __( 'Title slider item.', 'nrg_premium' ),
		),
		array(
			'type'			=> 'vc_link',
			'heading'		=> __( 'Link', 'nrg_premium' ),
			'param_name'	=> 'link',
			'value'			=> '',
		),
		array(
			'type'			=> 'textfield',
			'heading'		=> __( 'Subtitle', 'nrg_premium' ),
			'param_name'	=> 'subtitle',
			'value'			=> '',
			'description'	=> __( 'Subtitle slider item.', 'nrg_premium' ),
		),
		array(
			'type'			=> 'textarea',
			'heading'		=> __( 'Short Description', 'nrg_premium' ),
			'param_name'	=> 'short_desc',
			'description'	=> __( 'Short description slider item.', 'nrg_premium' ),
		),
		array(
			'type'			=> 'colorpicker',
			'heading'		=> __( 'Background color', 'nrg_premium' ),
			'param_name'	=> 'bg_col',
			'value'			=> '',
		),
		array(
			'type'			=> 'colorpicker',
			'heading'		=> __( 'Color', 'nrg_premium' ),
			'param_name'	=> 'col',
			'value'			=> '',
		),
		array(
			'type'			=> 'textfield',
			'heading'		=> __( 'Final date', 'nrg_premium' ),
			'param_name'	=> 'f_date',
			'value'			=> '',
			'description'	=> __( 'Write final date like "Sep,1,2018"', 'nrg_premium' ),
		),
  ) //end params
) );


class WPBakeryShortCode_nrg_premium_left_time_item extends WPBakeryShortCode{
	protected function content( $atts, $content = null ){
		global $left_time_items;
		$left_time_items[] = array('atts' => $atts, 'content' => $content, 'css_class' => '');
		return;
	}
}