<?php 
/*
** 1/2 Banner 1/2 text
** Author: NRGTHEMES
** Author URI: http://nrgthemes.com
** Version: 1.0.0 
*/

vc_map( array(
	'name'                    => __( '1/2 Banner 1/2 text', 'nrg_premium' ),
	'base'                    => 'nrg_premium_half_banner_text',
	'category' 				  => __( 'NRGPremium', 'nrg_premium' ),
	'content_element'         => true,
	'show_settings_on_create' => true,
	'description'             => __( 'Half image half text ', 'nrg_premium'),
	'params'          => array(
		array(
			'type'			=> 'dropdown',
			'heading'		=> __( 'Image align', 'nrg_premium' ),
			'param_name'	=> 'img_align',
			'value'			=> array(
				'Left'			=> 'left',
				'Right'			=> 'right',
			),
			'description'	=> 'Default align left.',
		),
		array(
			'type'			=> 'dropdown',
			'heading'		=> __( 'Video content', 'nrg_premium' ),
			'param_name'	=> 'video_cont',
			'value'			=> array(
				'Disable'		=> 'disable',
				'Enable'		=> 'enable',
			),
			'description'	=> 'Default is disable.',
			'group'			=> 'Video',
		),
		array(
			'type'			=> 'textfield',
			'heading'		=> __( "Youtube link", "nrg_premium" ),
			'param_name'	=> 'youtube_link',
			'value'			=> '',
			'dependency'	=> array( 'element' => 'video_cont', 'value' => 'enable'),
			'group'			=> 'Video',

		),

		array(
			'type'			=> 'dropdown',
			'heading'		=> __( 'Type of content', 'nrg_premium' ),
			'param_name'	=> 'type_of_content',
			'value'			=> array(
				'Default'			=> 'default',
				'With images'		=> 'images',
				'With list'			=> 'list',
				'With counter'		=> 'counter',
				'With testemonials'	=> 'testemonials',
				'With service icon'	=> 'icons',
				'With news'			=> 'news',
				'With customers'	=> 'customers',
				'With headings'		=> 'headings',
			),
			'admin_label'	=> true,
			'description'	=> 'Default is default.',
		),
		array(
			'type'			=> 'dropdown',
			'heading'		=> __( 'Subtype service icons', 'nrg_premium' ),
			'param_name'	=> 'subtype_ic',
			'value'			=> array(
				'Subtype 1'		=> 'subtype_1',
				'Subtipe 2'		=> 'subtype_2',
			),
			'description'	=> 'Default is default.',
			'dependency'	=> array( 'element' => 'type_of_content', 'value' => 'icons'),
		),
		array(
			'type'			=> 'attach_image',
			'heading'		=> __( "Image", "nrg_premium" ),
			'param_name'	=> 'image',
			'admin_label'	=> true,
			'description'	=> 'Upload your image.',
		),
		array(
			'type'			=> 'dropdown',
			'heading'		=> __( 'Dark Layer', 'nrg_premium' ),
			'param_name'	=> 'layer_ic',
			'value'			=> array(
				'Disable'		=> 'disable',
				'Enable'		=> 'enable',
			),
			'dependency'	=> array( 'element' => 'type_of_content', 'value' => 'icons'),
			'description'	=> 'Dark image layer',
		),
		array(
			'type'			=> 'checkbox',
			'heading'		=> __( 'Heading color white', 'nrg_premium' ),
			'param_name'	=> 'lighter',
			'value'			=> false,
			'dependency'	=> array( 'element' => 'type_of_content', 'value' => 'default'),
			'group'			=> 'Heading',
		),
		array(
			'type'			=> 'textfield',
			'heading'		=> __( "Subtitle", "nrg_premium" ),
			'param_name'	=> 'subtitle',
			'admin_label'	=> true,
			'value'			=> '',
			'group'			=> 'Heading',
		),
		array(
			'type'			=> 'textfield',
			'heading'		=> __( "Title", "nrg_premium" ),
			'param_name'	=> 'title',
			'admin_label'	=> true,
			'value'			=> '',
			'group'			=> 'Heading',
		),
		array(
			'type'			=> 'textarea',
			'heading'		=> __( 'Short Description', 'nrg_premium' ),
			'param_name'	=> 'short_desc',
			'group'			=> 'Heading',
		),
		array(
			'type'			=> 'dropdown',
			'heading'		=> __( 'Heading align', 'nrg_premium' ),
			'param_name'	=> 'align_heading',
			'value'			=> array(
				'Align Left'		=> 'left',
				'Align center'		=> 'center',
				'Align right'		=> 'right',
			),
			'description'	=> 'Default is align left.',
			'group'			=> 'Heading',
		),
		array(
			'type'			=> 'dropdown',
			'heading'		=> __( 'Headings align', 'nrg_premium' ),
			'param_name'	=> 'align_headings',
			'value'			=> array(
				'Align Left'		=> 'left',
				'Align center'		=> 'center',
				'Align right'		=> 'right',
			),
			'description'	=> 'Default is align left.',
			'group'			=> 'Content',
			'dependency'	=> array( 'element' => 'type_of_content', 'value' => 'headings'),
		),

		array(
			'type'			=> 'dropdown',
			'heading'		=> __( 'Background color', 'nrg_premium' ),
			'param_name'	=> 'bg_color',
			'value'			=> array(
				'Light'	=> 'light',
				'Dark'	=> 'dark',
			),
			'group'			=> 'Content',
		),

		array(
			'type'			=> 'param_group',
			'js_view'		=> 'VcColumnView',
			'heading'		=> __( 'Content headings', 'nrg_premium' ),
			'description'	=> __( 'Enter your headings', 'nrg_premium' ),
			'param_name'	=> 'content_headings',
			'params'		=> array(
				array(
					'type'			=> 'textfield',
					'heading'		=> __( "Title", "nrg_premium" ),
					'param_name'	=> 'title',
					'value'			=> '',
				),
				array(
					'type'			=> 'textfield',
					'heading'		=> __( "Subtitle", "nrg_premium" ),
					'param_name'	=> 'subtitle',
					'value'			=> '',
				),
				array(
					'type'			=> 'textarea',
					'heading'		=> __( 'Short Description', 'nrg_premium' ),
					'param_name'	=> 'short_desc',
				),
			),
			'dependency'	=> array( 'element' => 'type_of_content', 'value' => 'headings'),
			'group'			=> 'Content',
		),

		array(
			'type'			=> 'param_group',
			'js_view'		=> 'VcColumnView',
			'heading'		=> __( 'Content images', 'nrg_premium' ),
			'description'	=> __( 'Upload content images', 'nrg_premium' ),
			'param_name'	=> 'content_images',
			'params'		=> array(
				array(
					'type'			=> 'attach_image',
					'heading'		=> __( "Content image", "nrg_premium" ),
					'param_name'	=> 'content_image',
					'description'	=> 'Upload your image.',
				),
			),
			'dependency'	=> array( 'element' => 'type_of_content', 'value' => 'images'),
			'group'			=> 'Content',
		),
		array(
			'type'			=> 'dropdown',
			'heading'		=> __( 'Title size', 'nrg_premium' ),
			'param_name'	=> 'title_size',
			'value'			=> array(
				'H2'	=> 'h2',
				'H3'	=> 'h3',
			),
			'dependency'	=> array( 'element' => 'type_of_content', 'value' => 'images'),
			'group'			=> 'Content',
		),
		array(
			'type'			=> 'param_group',
			'js_view'		=> 'VcColumnView',
			'heading'		=> __( 'Customers icons', 'nrg_premium' ),
			'description'	=> __( 'Upload customers icons', 'nrg_premium' ),
			'param_name'	=> 'customers_icons',
			'params'		=> array(
				array(
					'type'			=> 'attach_image',
					'heading'		=> __( "Customer icon", "nrg_premium" ),
					'param_name'	=> 'customer_icon',
					'description'	=> 'Upload your image.',
				),
			),
			'dependency'	=> array( 'element' => 'type_of_content', 'value' => 'customers'),
			'group'			=> 'Content',
		),


		array(
			'type'			=> 'param_group',
			'js_view'		=> 'VcColumnView',
			'heading'		=> __( 'Counters', 'nrg_premium' ),
			'description'	=> __( 'Counters', 'nrg_premium' ),
			'param_name'	=> 'counters',
			'params'		=> array(
				array(
					'type'			=> 'textfield',
					'heading'		=> __( "Counter number", "nrg_premium" ),
					'param_name'	=> 'counter_numb',
					'value'			=> '',
					'description'	=> 'Enter number from 1 to 100',
				),
				array(
					'type'			=> 'textfield',
					'heading'		=> __( "Title for counter", "nrg_premium" ),
					'param_name'	=> 'counter_title',
					'value'			=> '',
				),
				array(
					'type'			=> 'textfield',
					'heading'		=> __( "Description for counter", "nrg_premium" ),
					'param_name'	=> 'counter_desc',
					'value'			=> '',
				),
			),
			'dependency'	=> array( 'element' => 'type_of_content', 'value' => 'counter'),
			'group'			=> 'Content',
		),
		array(
			'type'			=> 'textfield',
			'heading'		=> __( "Title for content", "nrg_premium" ),
			'param_name'	=> 'content_title',
			'value'			=> '',
			'dependency'	=> array( 'element' => 'type_of_content', 'value' => 'counter'),
			'group'			=> 'Content',
		),
		array(
			'type'			=> 'textarea',
			'heading'		=> __( 'Content', 'nrg_premium' ),
			'param_name'	=> 'content_new',
			'dependency'	=> array( 'element' => 'type_of_content', 'value' => array('images', 'list', 'counter')),
			'group'			=> 'Content',
		),
		array(
			'type'			=> 'dropdown',
			'heading'		=> __( 'Border', 'nrg_premium' ),
			'param_name'	=> 'border',
			'value'			=> array(
				'Disable'		=> 'disable',
				'Enable'		=> 'enable',
			),
			'description'	=> 'Default is disable.',
			'group'			=> 'Content',
		),
		array(
			'type'			=> 'attach_image',
			'heading'		=> __( "Icon", "nrg_premium" ),
			'param_name'	=> 'icon',
			'admin_label'	=> true,
			'description'	=> 'Upload your image.',
			'dependency'	=> array( 'element' => 'type_of_content', 'value' => 'default' ),
			'group'			=> 'Content',
		),
		array(
			'type'			=> 'attach_image',
			'heading'		=> __( "Icon", "nrg_premium" ),
			'param_name'	=> 'icon_h',
			'description'	=> 'Upload your image.',
			'dependency'	=> array( 'element' => 'type_of_content', 'value' => 'headings' ),
		),
		array(
			'type'			=> 'dropdown',
			'heading'		=> __( 'Padding', 'nrg_premium' ),
			'param_name'	=> 'padd',
			'value'			=> array(
				'Standart'		=> 'standart',
				'Big'			=> 'big',
			),
			'description'	=> 'Default is disable.',
			'group'			=> 'Content',
			'dependency'	=> array( 'element' => 'type_of_content', 'value' => 'default' ),
		),
		array(
			'type'        => 'dropdown',
			'heading'     => __( 'Button type', 'nrg_premium' ),
			'param_name'  => 'btn_type',
			'value'       => array(
				'Type 1'   => 'type_1',
				'Type 2'   => 'type_2',
				'Type 3'   => 'type_3',
				'Type 4'   => 'type_4',
				'Type 5'   => 'type_5',
				'Type 6'   => 'type_6',
			),
			'dependency'	=> array( 'element' => 'type_of_content', 'value' => array('default', 'list', 'news') ),
			'group'			=> 'Button',
		),
		array(
			'type'			=> 'dropdown',
			'heading'		=> __( 'Button width', 'nrg_premium' ),
			'param_name'	=> 'b_width',
			'value'			=> array(
				'Standart'		=> 'standart',
				'Small'			=> 'small',
			),
			'dependency'  => array( 'element' => 'btn_type', 'value' => array('type_1', 'type_3')),
			'group'			=> 'Button',
		),
		array(
			'type'        => 'dropdown',
			'heading'     => __( 'Button Align', 'nrg_premium' ),
			'param_name'  => 'btn_align',
			'value'       => array(
				'Align center'	=> 'align_center',
				'Align left'	=> 'align_left',
				'Align right'	=> 'align_right',
			),
			'group'			=> 'Button',
		),
		array(
			'type'			=> 'textfield',
			'heading'		=> __( "Button title", "nrg_premium" ),
			'param_name'	=> 'button_title',
			'admin_label'	=> true,
			'value'			=> '',
			'dependency'	=> array( 'element' => 'type_of_content', 'value' => array('default', 'list', 'news') ),
			'group'			=> 'Button',
		),
		array(
			'type'			=> 'vc_link',
			'heading'		=> __( "Button url", "nrg_premium" ),
			'param_name'	=> 'button_url',
			'value'			=> '',
			'dependency'	=> array( 'element' => 'type_of_content', 'value' => array('default', 'list', 'news') ),
			'group'			=> 'Button',
		),
		array(
			'type'			=> 'colorpicker',
			'class'			=> '',
			'heading'		=> __( 'Main color', 'nrg_premium' ),
			'param_name'	=> 'm_color',
			'value'			=> '#84694e',
			'dependency'	=> array( 'element' => 'type_of_content', 'value' => array('default', 'list', 'news') ),
			'group'			=> 'Button',
		),

		array(
			'type'			=> 'textarea',
			'heading'		=> __( 'News limit', 'nrg_premium' ),
			'param_name'	=> 'limit',
			'description'	=> __( 'Limit news per block', 'nrg_premium' ),
			'dependency'	=> array( 'element' => 'type_of_content', 'value' => 'news'),
			'group'			=> 'Content',
		),
		array(
			'type'			=> 'param_group',
			'js_view'		=> 'VcColumnView',
			'heading'		=> __( 'List Items', 'nrg_premium' ),
			'description'	=> __( 'Unordered list', 'nrg_premium' ),
			'param_name'	=> 'lists',
			'params'		=> array(
				array(
					'type'			=> 'textfield',
					'heading'		=> __('Unordered list item', 'nrg_premium'),
					'param_name'	=> 'list_item',
				),
			),
			'dependency'	=> array( 'element' => 'type_of_content', 'value' => 'list'),
			'group'			=> 'Content',
		),

		array(
			'type'			=> 'param_group',
			'js_view'		=> 'VcColumnView',
			'heading'		=> __( 'Service Items', 'nrg_premium' ),
			'description'	=> __( 'Service list', 'nrg_premium' ),
			'param_name'	=> 'service_list',
			'params'		=> array(
				array(
					'type'			=> 'attach_image',
					'heading'		=> __( "Service image", "nrg_premium" ),
					'param_name'	=> 's_image',
					'admin_label'	=> true,
					'description'	=> 'Upload your image.',
				),
				array(
					'type'			=> 'textfield',
					'heading'		=> __('Title', 'nrg_premium'),
					'param_name'	=> 's_title',
				),
				array(
					'type'			=> 'textfield',
					'heading'		=> __('Subitle', 'nrg_premium'),
					'param_name'	=> 's_subtitle',
				),
				array(
					'type'			=> 'textarea',
					'heading'		=> __( 'Short description', 'nrg_premium' ),
					'param_name'	=> 's_short_desc',
				),

			),
			'dependency'	=> array( 'element' => 'type_of_content', 'value' => 'icons'),
			'group'			=> 'Content',
		),
		array(
			'type'			=> 'param_group',
			'js_view'		=> 'VcColumnView',
			'heading'		=> __( 'Testemonials', 'nrg_premium' ),
			'description'	=> __( 'Testemonials list', 'nrg_premium' ),
			'param_name'	=> 'testemonials',
			'params'		=> array(
				array(
					'type'			=> 'attach_image',
					'heading'		=> __( "Testemonial image", "nrg_premium" ),
					'param_name'	=> 'teste_image',
					'admin_label'	=> true,
					'description'	=> 'Upload your image.',
				),
				array(
					'type'			=> 'textarea',
					'heading'		=> __( 'Testemonial сontent', 'nrg_premium' ),
					'param_name'	=> 'teste_cont',
				),
				array(
					'type'			=> 'textfield',
					'heading'		=> __('Testemonial Author', 'nrg_premium'),
					'param_name'	=> 'teste_author',
				),
				array(
					'type'			=> 'textfield',
					'heading'		=> __('Testemonial Author info', 'nrg_premium'),
					'param_name'	=> 'teste_author_info',
				),

			),
			'dependency'	=> array( 'element' => 'type_of_content', 'value' => array('testemonials', 'customers')),
			'group'			=> 'Content',
		),

		array(
			'type' => 'textfield',
			'heading' => __( 'Extra class name', 'nrg_premium' ),
			'param_name' => 'el_class',
			'description' => __( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'nrg_premium' ),
			'value' => '',
		),
		array(
			'type' => 'css_editor',
			'heading' => __( 'CSS box', 'nrg_premium' ),
			'param_name' => 'css',
			'group' => __( 'Design options', 'nrg_premium' ),
		),
	) //end params
) );

class WPBakeryShortCode_nrg_premium_half_banner_text extends WPBakeryShortCode {
	protected function content( $atts, $content = null) {

		extract( shortcode_atts( array(
			'el_class'			=> '',
			'css'				=> '',
			'title'				=> '',
			'subtitle'			=> '',
			'short_desc'		=> '',
			'button_title'		=> '',
			'button_url'		=> '',
			'image'				=> '',
			'img_align'			=> 'left',
			'lighter'			=> false,
			'content_images'	=> '',
			'type_of_content'	=> 'default',
			'content_new'		=> '',
			'lists'				=> '',
			'counters'			=> '',
			'content_title'		=> '',
			'testemonials'		=> '',
			'video_cont'		=> 'disable',
			'youtube_link'		=> '',
			'align_heading'		=> 'left',
			'service_list'		=> '',
			'limit'				=> '',
			'customers_icons'	=> '',
			'border'			=> 'disable',
			'icon'				=> '',
			'padd'				=> 'stardart',
			'layer_ic'			=> 'disable',
			'subtype_ic'		=> 'subtype_1',
			'content_headings'	=> '',
			'align_headings'	=> 'left',
			'icon_h'			=> '',
			'bg_color'			=> 'light',
			'btn_type'			=> 'type_1',
			'b_width'			=> 'stardart',
			'm_color'			=> '',
			'btn_align'			=> 'align_center',
			'title_size'		=> 'h2',
			
 		), $atts ) );

		$bg_class = '';
		if ($img_align == 'right') {
			$bg_class = '-right';
		}

		$txt_al_class = '';
		if ($img_align == 'left') {
			$txt_al_class = 'col-md-offset-6';
		}

		$limit 	  = ( empty( $limit ) || ! is_numeric( $limit ) ) ? 3 : $limit;

		$sub_light = '';
		$tit_light = '';
		$desc_light = 'col-1';
		if ($lighter == true) {
			$sub_light = 'col-2';
			$tit_light = 'type-2';
			$desc_light = 'col-2';

		}

		$bg_col = '';
		$txt_col = '';
		if ($bg_color == 'light') {
			$bg_col = '#f6f6f6';
		} else {
			$bg_col = '#333';
		}


		$heading_align = '';
		if ($align_heading == 'center') {
			$heading_align = 'text-center';
		} elseif ($align_heading == 'right') {
			$heading_align = 'text-right text-center-xs';
		} elseif ($align_heading == 'left') {
			$heading_align = 'text-center-xs';
		}

 		// BUTTON LINK
 		if ($button_url) {
			$button_link = vc_build_link($button_url);
		}

		// COUNTERS
		if ($counters) {
			$values_count = vc_param_group_parse_atts( $atts['counters']);
		}

		// HEADINGS
		if ($content_headings) {
			$values_head = vc_param_group_parse_atts( $atts['content_headings']);
		}

		// UL
		if ($lists) {
			$values = vc_param_group_parse_atts( $atts['lists']);
		}

		// TESTEMONIALS
		if ($content_images) {
			$values_images = vc_param_group_parse_atts( $atts['content_images']);
		}

		// CONTENT IAMGES
		if ($testemonials) {
			$values_teste = vc_param_group_parse_atts( $atts['testemonials']);
		}

		// CUSTOMERS ICONS
		if ($customers_icons) {
			$values_customers = vc_param_group_parse_atts( $atts['customers_icons']);
		}

		// SERVICE LIST
		if ($service_list) {
			$values_service = vc_param_group_parse_atts( $atts['service_list']);
		}	

		// TWO TYPES

		$def_icons = array('default','icons');

		$ico_teste = array('testemonials','icons', 'headings');

		// TWO TYPES END

		
		$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, $this->settings['base'], $atts );
		
		// custum css
		$css_class .= vc_shortcode_custom_css_class( $css, ' ' );

		// custum class
		$css_class .= (!empty($el_class)) ? ' '.$el_class : '';

 		// output
		ob_start();
		do_shortcode( $content );
		// 1/2 Banner 1/2 text
		?>
		<div class="section <?php print esc_attr( $css_class ); ?> ">
			<?php if ($image) { ?>
				<div class="bg offset-50<?php echo esc_html($bg_class); ?> height-md-400 <?php echo ($type_of_content == 'testemonials' ? 'flex-align layer-hold type-2' : ''); ?> <?php echo ($type_of_content == 'customer' ? 'flex-align' : '');  ?> <?php echo ($type_of_content == 'headings' ? 'layer-hold type-4' : '');  ?> " style="background-image: url('<?php echo esc_url(wp_get_attachment_image_url( $image, 'full' )); ?>')">
					<?php
					//CONTENT IMAGE TESTEMONIALS AND ICONS
					if ( array_search( $type_of_content, $ico_teste ) !== false ) { 
						if ($type_of_content == 'icons') { ?>
							<div class="block-height-800 flex-align <?php echo ( $layer_ic == 'enable' ? 'layer-hold type-4' : '' );?>">
								<div class="custome-padd-100 xs-padd-15">
						<?php } 
								if ($type_of_content == 'headings') { ?>
									<div class="custome-padd-100 xs-padd-15 flex-align full-h">
										<div class="caption type-2 text-center">
											<?php if ($icon_h) { ?>
												<img src="<?php echo esc_html(wp_get_attachment_image_url( $icon_h, 'full' )); ?>" alt="">
												<div class="empty-sm-20 empty-xs-20"></div>
											<?php }
											if ($subtitle){ ?>
												<span class="sub-title col-1"><?php echo wp_kses_post($subtitle); ?></span>
												<div class="empty-sm-5 empty-xs-5"></div>
											<?php }
											if ($title){ ?>
												<h2 class="h2 title"><?php echo esc_html($title); ?></h2>
												<div class="empty-sm-50 empty-xs-30"></div>
											<?php } 
											if ($short_desc){ ?>
												<div class="simple-text col-3 md <?php echo ($type_of_content == 'icons'? 'max-500': ''); ?>">
													<p><?php echo wp_kses_post($short_desc); ?></p>
												</div>
											<?php } ?>
										</div>
									</div>
								<?php } else { ?>
									<div class="caption <?php echo esc_html($heading_align);?> type-2">
										<?php if ($subtitle){ ?>
											<span class="sub-title"><?php echo wp_kses_post($subtitle); ?></span>
											<div class="empty-sm-5 empty-xs-5"></div>
										<?php }
										if ($title){ ?>
										<h2 class="h2 <?php print ($type_of_content == 'icons' ? 'lg' : '' ); ?> title"><?php echo esc_html($title); ?></h2>
										<?php }
										if ($short_desc){ ?>
											<div class="empty-sm-15 empty-xs-15"></div>
											<div class="simple-text md col-3">
												<p><?php echo wp_kses_post($short_desc); ?></p>
											</div>
										<?php } ?>
									</div>
								<?php } ?>
									

						<?php if ($type_of_content == 'icons') { ?>
								</div>
							</div>
						<?php } ?>
					<?php } 
					//CONTENT IMAGE TESTEMONIALSAND ICONS END
					?>

					<?php
					//VIDEO CONTENT
					if (($video_cont == 'enable') && $youtube_link) { ?>
						<div class="video-open">
							<div class="play-button" data-video="<?php echo wp_kses_post($youtube_link); ?>">
								<i class="fa fa-play"></i>
							</div>
							<div class="video-item">
								<div class="video-wrapper">
									<div class="video-iframe"></div>
									<div class="close close-video"><span>+</span></div>
								</div>
							</div>
						</div>
					<?php } 
					//VIDEO CONTENT END
					?>

					<?php 
					// CUSTOMERS TESTEMONIALS
					if ($type_of_content == 'customers') { 
						if (isset($values_teste)) { ?>
						<div class="swiper-container full-h step-slider" data-mode="horizontal" data-autoplay="0" data-effect="slide" data-slides-per-view="1" data-loop="0" data-speed="800">
							<div class="swiper-wrapper">
								
								<?php foreach ($values_teste as $value_teste) { ?>
									<div class="swiper-slide">
										<div class="empty-lg-180 empty-md-100 empty-sm-60 empty-xs-60"></div>
										<div class="caption custome-padd-100 text-center">
											<div class="bg-section-3 custome-padd-60">
												<div class="empty-md-60 empty-sm-30 empty-xs-30"></div>
												<?php 
												if (isset($value_teste['teste_image'])) {
													echo '<img src="'. esc_url( wp_get_attachment_image_url( $value_teste['teste_image'], 'full' ) ).'" alt="">';
												}
												if ($value_teste['teste_cont']) { ?>
													<div class="empty-sm-30 empty-xs-30"></div>
													<div class="simple-text col-1">
														<p><?php echo wp_kses_post($value_teste['teste_cont']); ?></p>
													</div>
												<?php }
												if ($value_teste['teste_author']) { ?>
													<div class="empty-sm-30 empty-xs-20"></div>
													<h4 class="h4"><?php echo esc_html($value_teste['teste_author']); ?></h4>
												<?php }
												if ($value_teste['teste_author_info']) { ?>
												<div class="empty-sm-5 empty-xs-5"></div>
												<span class="sub-desc"><?php echo esc_html($value_teste['teste_author_info']); ?></span>
												<?php } ?>
												<div class="empty-md-60 empty-sm-30 empty-xs-30"></div>
											</div>
										</div>
									</div>
								<?php } ?>
							</div>

							<div class="pagination type-2 colo-type-1"></div>
						</div>
					<?php }
					// CUSTOMERS TESTEMONIALS END
					} ?>
				</div>
			<?php } ?>

			<div class="container-fluid no-padd">
				<?php if (array_search( $type_of_content, $def_icons ) !== false ) { ?> 
					<div class="empty-lg-140 empty-md-100 empty-sm-60 empty-xs-60"></div>
				<?php } ?>

				<div class="row <?php echo ( $subtype_ic == 'subtype_2' ? 'vertical-wrap' : ''); ?>">
					<div class="<?php echo ($image ? 'col-md-6 '.esc_html($txt_al_class).' ' : 'col-md-12' )?> ">
						<?php if (array_search( $type_of_content, $def_icons ) === false ) { ?> 
							<div class="<?php echo ($border == 'enable' ? 'frame-block' : '');?> text-center" style="<?php echo ($bg_color == 'light' ? 'background-color: #f6f6f6;' : 'background-color: #333;'); ?> ">
								<?php if ($type_of_content != 'testemonials') { ?>
									<div class="empty-lg-100 empty-md-100 empty-sm-60 empty-xs-60"></div>
								<?php } ?>
						<?php } ?>
							<div class="custome-padd-100 <?php echo ($type_of_content == 'default') ? 'xs-padd-15' : '' ?>">
								<?php ?>
								<?php 
								if( array_search( $type_of_content, $ico_teste ) === false  ){ ?>
									<div class="caption <?php echo esc_html($heading_align);?> <?php echo esc_html($tit_light); ?>">
										<?php if ($icon) { ?>
											<img src="<?php echo esc_url(wp_get_attachment_image_url( $icon, 'full' )); ?>" alt="">
											<div class="empty-sm-20 empty-xs-20"></div>
										<?php }
										if ($subtitle){ ?>
											<span class="sub-title <?php echo ($bg_color == 'dark' ? 'subt_light' : '') ?> <?php print esc_html($sub_light); ?>"><?php print wp_kses_post($subtitle) ?></span>
											<div class="empty-sm-5 empty-xs-5"></div>
										<?php }
										if ($title){ ?>
											<h2 class="title  <?php echo ($type_of_content == 'images' ? esc_html($title_size) : 'h2') ?> <?php echo ($bg_color == 'dark' ? 't_light' : '') ?> <?php echo ($type_of_content == 'default') ? 'tt-off' : ''; ?>"><?php echo esc_html($title) ?></h2>
										<?php }
										if($short_desc){ 
											if ($type_of_content == 'default') {
												if ($padd == 'standart') { ?>
													<div class="empty-sm-25 empty-xs-25"></div>
												<?php } else { ?>
													<div class="empty-sm-50 empty-xs-50"></div>
												<?php }
											}  else { ?>
													<div class="empty-sm-15 empty-xs-15"></div>
											<?php } ?>
												<div class="simple-text md <?php print esc_html($desc_light); ($type_of_content == 'default') ? 'col-1' : '' ?>">
													<p><?php print wp_kses_post($short_desc); ?></p>
												</div>
										<?php } ?>
										<?php if ($type_of_content == 'default') { ?>
											<div class="empty-sm-25 empty-xs-25"></div>
											<?php hm_get_template_part('composer/shortcodes/buttons/button-'.$btn_type, [ 'title' => $button_title, 'but_url' => $button_url, 'but_align' => $btn_align , 'main_color' => $m_color, 'but_width' => $b_width ]);
										} ?>
									</div>
								<?php } ?>

								<?php 
								//TYPE WITH IMAGES
								if ($type_of_content == 'images') {
									if (isset($values_images)) {
									 ?>	
									 	<div class="empty-md-50 empty-sm-40 empty-xs-40"></div>
										<div class="two-img">
											<?php foreach ($values_images as $value_images) { ?>
												<img src="<?php echo esc_url(wp_get_attachment_image_url( $value_images['content_image'], 'full' )); ?>" alt="">
											<?php } ?>
										</div>
									<?php } 

									if($content_new){ ?>
										<div class="empty-md-40 empty-sm-30 empty-xs-30"></div>
										<div class="simple-text col-1">
											<p><?php print wp_kses_post($content_new); ?></p>
										</div>
									<?php }
								} 
								//TYPE WITH IMAGES END
								?>

								<?php 
								//TYPE WITH LIST
								if ($type_of_content == 'list') {
									if($content_new){ ?>
										<div class="empty-md-40 empty-sm-30 empty-xs-30"></div>
										<div class="simple-text col-1">
											<p><?php print wp_kses_post($content_new); ?></p>
										</div>
									<?php }
									if (isset($values)) { ?>
										<div class="empty-sm-20 empty-xs-20"></div>
										<ul class="simple-list col-2">
											<?php foreach ($values as $value) {
												if ($value['list_item']) { ?>
													<li><?php echo wp_kses_post($value['list_item']); ?></li>
												<?php }
											} ?>
										</ul>
									<?php } 
									if ($button_title && $button_link) { ?>
										<div class="empty-sm-20 empty-xs-25"></div>
										<?php hm_get_template_part('composer/shortcodes/buttons/button-'.$btn_type, [ 'title' => $button_title, 'but_url' => $button_url, 'but_align' => 'text-center' , 'main_color' => $m_color, 'but_width' => $b_width ]); ?>
									<?php } 
								} 
								//TYPE WITH LIST END
								?>

								<?php 
								//TYPE WITH COUNTER
								if ($type_of_content == 'counter') {
									if (isset($values_count)) { ?>
										<div class="empty-md-50 empty-sm-40 empty-xs-40"></div>
										<div class="time-line skill-block-wrap">
											<?php $i = 0;
											foreach ($values_count as $value_count) {
												 $i++;
												if ($value_count['counter_numb']) { ?>
													<div class="skill-block">
														<div class="skill-circle" id="skill-circle-<?php echo $i; ?>" data-border="false" data-dimension="130" data-bgcolor="#f6f6f6" data-width="2" data-percent="<?php echo esc_html($value_count['counter_numb']);?>" data-fgcolor="#e27763" data-animationstep="1">
															<div class="skill-number vertical-align full">
																<span class="timer" data-to="<?php echo esc_html($value_count['counter_numb']);?>" data-speed="1000">0</span>%
															</div>
														</div>
														<?php if ($value_count['counter_title']) { ?>
															<div class="empty-sm-5 empty-xs-5"></div>
															<h4 class="h4"><?php echo esc_html($value_count['counter_title']); ?></h4>
														<?php }
														if ($value_count['counter_desc']) { ?>
															<div class="empty-sm-5 empty-xs-5"></div>
															<span class="sub-desc"><?php echo esc_html($value_count['counter_desc']); ?></span>
														<?php } ?>
													</div>
												<?php }
											} ?>
										</div>
									<?php }

                           			if($content_title){ ?>
										<div class="empty-sm-40 empty-xs-30"></div>
										<h4 class="h4"><?php echo esc_html($content_title); ?></h4>
									<?php }

									if($content_new){ ?>
										<div class="empty-md-30 empty-sm-30 empty-xs-30"></div>
										<div class="simple-text col-1">
											<p><?php echo wp_kses_post($content_new); ?></p>
										</div>
									<?php }
								} 
								// TYPE WITH COUNTER END
								?>

								<?php 
								//TYPE WITH TESTEMONIALS
								if ($type_of_content == 'testemonials') { 
									if (isset($values_teste)) { ?>
									<div class="swiper-container full-h step-slider" data-mode="horizontal" data-autoplay="0" data-effect="slide" data-slides-per-view="1" data-loop="0" data-speed="800">
										<div class="swiper-wrapper">
											
											<?php foreach ($values_teste as $value_teste) { ?>
												<div class="swiper-slide">
													<div class="empty-lg-200 empty-md-100 empty-sm-60 empty-xs-60"></div>
													<div class="caption text-center">
														<?php 
														if (isset($value_teste['teste_image'])) {
															echo '<img src="'. esc_url( wp_get_attachment_image_url( $value_teste['teste_image'], 'full' ) ).'" alt="">';
														}
														if ($value_teste['teste_cont']) { ?>
															<div class="empty-sm-30 empty-xs-30"></div>
															<div class="simple-text col-1">
																<p><?php echo wp_kses_post($value_teste['teste_cont']); ?></p>
															</div>
														<?php }
														if ($value_teste['teste_author']) { ?>
															<div class="empty-sm-30 empty-xs-20"></div>
															<h4 class="h4"><?php echo esc_html($value_teste['teste_author']); ?></h4>
														<?php }
														if ($value_teste['teste_author_info']) { ?>
														<div class="empty-sm-5 empty-xs-5"></div>
														<span class="sub-desc"><?php echo esc_html($value_teste['teste_author_info']); ?></span>
														<?php } ?>
													</div>
													<div class="empty-lg-200 empty-md-100 empty-sm-40 empty-xs-40"></div>
												</div>
											<?php } ?>
										</div>

											<div class="pagination type-2 colo-type-1"></div>
									</div>
									<?php } 
								} 
								//TYPE WITH TESTEMONIALS END
								?>

								<?php 
								// TYPE WITH ICONS
								if ($type_of_content == 'icons') { 
									if (isset($values_service)) { 
										foreach ($values_service as $value_service) {
											if ($subtype_ic == 'subtype_1') { ?>
												<div class="service-item-sm">
													<?php if (isset($value_service['s_image'])) { ?>
														<div class="image">
															<img src="<?php echo esc_url( wp_get_attachment_image_url( $value_service['s_image'], 'full' ) ); ?>" alt="">
														</div>
													<?php } ?>
													<div class="text">
														<?php if ($value_service['s_title']) { ?>
															<h6 class="h7 title"><?php echo esc_html($value_service['s_title']); ?></h6>
														<?php } 
														if ($value_service['s_subtitle']) { ?>
															<i class="sub-title sm ls col-7"><?php echo wp_kses_post($value_service['s_subtitle']); ?></i>
														<?php } 
														if ($value_service['s_short_desc']) { ?>
															<div class="simple-text col-1">
																<p><?php echo wp_kses_post($value_service['s_short_desc']); ?></p>
															</div>
														<?php } ?>
													</div>
												</div>
												<div class="empty-sm-50 empty-xs-30"></div>
											<?php } elseif ($subtype_ic == 'subtype_2') { ?>
												<div class="service-icon-box style-7 text-center-xs right-align border-bottom-1">
													<?php if (isset($value_service['s_image'])) { ?>
														<div class="image">
															<img src="<?php echo esc_url( wp_get_attachment_image_url( $value_service['s_image'], 'full' ) ); ?>" alt="">
														</div>
													<?php } ?>
													<div class="caption type-2">
														<?php if (isset($value_service['s_title'])) { ?>
															<h6 class="h6 title no-padd"><?php echo esc_html($value_service['s_title']); ?></h6>
														<?php } 
														if (isset($value_service['s_short_desc'])) { ?>
															<div class="simple-text col-2">
																<p><?php echo wp_kses_post($value_service['s_short_desc']); ?></p>
															</div> 
														<?php } ?>
													</div>
													<div class="empty-sm-40 empty-xs-30"></div>    
												</div>
												<div class="empty-sm-40 empty-xs-30"></div>
											<?php }
										}
									}
								} 
								//TYPE WITH ICONS END
								?>

								<?php 
								// TYPE WITH NEWS
								if ($type_of_content == 'news') { 
									$args = array( 'posts_per_page' => $limit );
									$query = new WP_Query( $args );
									while ( $query->have_posts() ) {
										$query->the_post() ?>
											<div class="empty-sm-30 empty-xs-30"></div>
											<div class="blog-item hover-block">
												<div class="text">
													<h6 class="h7"><?php echo the_time(get_option('date_format'));?></h6>
													<div class="empty-sm-15 empty-xs-15"></div>
													<h6 class="h6 title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h6>
												</div>
											</div>
											<div class="empty-sm-30 empty-xs-30"></div>   

										<?php }
									wp_reset_postdata();
									if ($button_title && $button_link) { ?>
										<div class="empty-sm-20 empty-xs-25"></div>
										<?php hm_get_template_part('composer/shortcodes/buttons/button-'.$btn_type, [ 'title' => $button_title, 'but_url' => $button_url, 'but_align' => 'text-center' , 'main_color' => $m_color, 'but_width' => $b_width ]); ?>
									<?php } 
								} 
								//TYPE WITH NEWS END
								?>

								<?php 
								// TYPE WITH CUSTOMERS
								if ($type_of_content == 'customers') { 
									if (isset($values_customers)) { ?>
										<div class="customer-wrap">
											<?php foreach ($values_customers as $value_customers) { ?>
												<div class="customer-box">
													<img src="<?php echo esc_url( wp_get_attachment_image_url( $value_customers['customer_icon'], 'full' ) ); ?>" alt="">
												</div>
											<?php } ?>
										</div>
									<?php }
								} 
								//TYPE WITH CUSTOMERS END
								?>

								<?php 
								// TYPE WITH HEADINGS
								if ($type_of_content == 'headings') {
									$al_headings = ''; 
									if ($align_headings == 'left') {
										$al_headings = 'text-left';
									} elseif ($align_headings == 'center') {
										$al_headings = 'text-center';
									} elseif ($align_headings == 'right') {
										$al_headings = 'text-right';
									}
									if (isset($values_head)) { ?>
											<?php foreach ($values_head as $value_head) { ?>
												<div class="col-md-6">
													<div class="service-icon-box text-center-xs <?php echo $al_headings ?>">
														<?php if (isset($value_head['title'])) { ?>
															<h6 class="title h5"><?php echo esc_html($value_head['title']); ?></h6>
															<div class="empty-sm-5 empty-xs-5"></div>
														<?php } 
														if (isset($value_head['subtitle'])) { ?>
															<span class="sub-desc col-4"><?php echo wp_kses_post($value_head['subtitle']); ?></span>  
															<div class="empty-sm-15 empty-xs-15"></div>
														<?php } 
														if (isset($value_head['short_desc'])) { ?>
															<div class="simple-text col-1">
																<p><?php echo wp_kses_post($value_head['short_desc']); ?></p>
															</div>
															<div class="empty-sm-25 empty-xs-25"></div>
														<?php } ?>
														<div class="title-separator-4"></div>
													</div>
													<div class="empty-lg-80 empty-md-60 empty-sm-40 empty-xs-30"></div> 
												</div>
											<?php } ?>
									<?php }
								} 
								//TYPE WITH HEADINGS END
								?>
							</div>   
						
						<? if (array_search( $type_of_content, $def_icons ) === false ) { ?>
								<div class="empty-lg-100 empty-md-100 empty-sm-60 empty-xs-60"></div> 
							</div>
						<?php } ?>

					</div>
				</div>
				<? if (array_search( $type_of_content, $def_icons ) !== false ) { ?> 
					<div class="empty-lg-140 empty-md-100 empty-sm-60 empty-xs-60"></div>  
				<?php } ?>
			</div>
		</div>
		<?php 
		return  ob_get_clean();
	}
}