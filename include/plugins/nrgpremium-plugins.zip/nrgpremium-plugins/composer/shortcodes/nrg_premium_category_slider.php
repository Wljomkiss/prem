<?php 
/*
 * Category slider
 * Author: Upqode
 * Author URI: http://upqode.com
 * Version: 1.0.0 
 */


$cats_list=array();
$product_cat = get_terms(array('taxonomy'=>'product_cat', 'orderby' => 'ID'));
 if (!empty($product_cat) && !is_wp_error($product_cat)) {
	 foreach( $product_cat as $cat ){
		 $cats_list[$cat->name]=$cat->term_id;
	}
}


vc_map( 
	array(
		'name'            => __( 'Category slider', 'nrg_premium' ),
		'base'            => 'nrg_premium_category_slider',
		'description'     => __( 'Category slider (image & title)', 'nrg_premium' ),
		'category' 				  => __( 'NRGPremium', 'nrg_premium' ),
		'params'          => array(
			array(
				'type'        => 'vc_efa_chosen',
				'heading'     => __( 'Custom Categories', 'nrg_premium' ),
				'param_name'  => 'cats',
				'placeholder' => 'Choose category (optional)',
				'value'       => $cats_list,
				'std'         => '',
				'description' => __( 'You can choose spesific categories for portfolio, default is all categories', 'nrg_premium' ),
			),
			array(
				'type' 		  => 'textfield',
				'heading' 	  => __( 'Extra class name', 'nrg_premium' ),
				'param_name'  => 'el_class',
				'description' => __( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'nrg_premium' ),
				'value' 	  => ''
			),
			/* CSS editor */
			array(
				'type' 		  => 'css_editor',
				'heading' 	  => __( 'CSS box', 'nrg_premium' ),
				'param_name'  => 'css',
				'group' 	  => __( 'Design options', 'nrg_premium' )
			),
		)
	)
);

class WPBakeryShortCode_nrg_premium_category_slider extends WPBakeryShortCode{
	protected function content( $atts, $content = null ) {
		extract( shortcode_atts( array(
			'cats' 		   => '',
			'el_class'     => '',
			'css' 		   => '',
		), $atts ) );

		$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, $this->settings['base'], $atts );
		
		// custum css
		$css_class .= vc_shortcode_custom_css_class( $css, ' ' );

		// custum class
		$css_class .= (!empty($el_class)) ? ' '.$el_class : '';
		// $category = '';

		$cats 	 = explode( ',', $cats );
		?>	
		<div class="<?php print esc_attr( $css_class ); ?>">
			<div class="empty-sm-30 empty-xs-30"></div> 
				<div class="row">
					<div class="arrow-closest mobile-pagination arrow-hover"> 
						<div class="swiper-container gutter-15" data-mode="horizontal" data-autoplay="0" data-effect="slide" data-slides-per-view="responsive" data-loop="0" data-speed="800" data-add-slides="4" data-lg-slides="4" data-md-slides="3" data-sm-slides="2" data-xs-slides="1">
							<div class="swiper-wrapper">
								<?php
									$categories = get_term( get_the_ID() , 'product_cat' );
									if( $cats ) {
										foreach ( $cats as $cat ) {
											$thumbnail_id = get_woocommerce_term_meta( $cat, 'thumbnail_id', true );
											$image = wp_get_attachment_url( $thumbnail_id );
											$catName = get_the_category_by_ID( $cat );
											$catLink = get_category_link( $cat );
											?>	
											<div class="swiper-slide">
												<div class="product-cat-item flex-align">
													<div class="bg layer-hold type-4" style="background-image: url(<?php print esc_url($image);?>)"></div>
													<div class="button-wrap">  
														<a href="<?php echo esc_url($catLink); ?>" class="main-link link-style-7 type-3"><span><?php echo $catName;?></span></a>
													</div>
												</div>
											</div>
										<?php }
									}?>
							</div>
							<div class="pagination pagination-hide"></div>
						</div>
					<div class="swiper-arrow-left slider-arrow-1 left-15"><i class="fa fa-angle-left"></i></div>
					<div class="swiper-arrow-right slider-arrow-1 right-15"><i class="fa fa-angle-right"></i></div>
				</div>
			</div>
			<div class="empty-sm-30 empty-xs-30"></div>
		</div>
		<?php wp_reset_postdata();
	}
}