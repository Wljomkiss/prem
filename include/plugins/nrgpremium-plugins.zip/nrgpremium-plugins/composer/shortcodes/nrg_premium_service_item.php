<?php 
/*
** Servise icon
** Author: NRGTHEMES
** Author URI: http://nrgthemes.com
** Version: 1.0.0 
*/

vc_map( array(
	'name'						=> __( 'Servise item', 'nrg_premium' ),
	'base'						=> 'nrg_premium_icon_box',
	'category'					=> __( 'NRGPremium', 'nrg_premium' ),
	'content_element'			=> true,
	'show_settings_on_create'	=> true,
	'params'					=> array(
		array(
			'type'        => 'dropdown',
			'heading'     => __( 'Service item type', 'nrg_premium' ),
			'param_name'  => 'service_type',
			'value'       => array(
				'Type 1'   => 'type_1',
				'Type 2'   => 'type_2',
				'Type 3'   => 'type_3',
				'Type 4'   => 'type_4',
				'Type 5'   => 'type_5',
				'Type 6'   => 'type_6',
			)
		),
		array(
			'type'        => 'dropdown',
			'heading'     => __( 'Subtype', 'nrg_premium' ),
			'param_name'  => 'subtype',
			'value'       => array(
				'Type 1'   => 'type_1',
				'Type 2'   => 'type_2',
			),
			'dependency'  => array( 'element' => 'service_type', 'value' => array('type_2', 'type_3')),
		),
		array(
			'type' 		  => 'checkbox',
			'heading'	  => __( 'Item with link', 'nrg_premium' ),
			'param_name'  => 'with_link',
			'dependency'  => array( 'element' => 'service_type', 'value' => 'type_2'),
			'value'       => false,
		),
		array(
			'type' 		  => 'checkbox',
			'heading'	  => __( 'More height', 'nrg_premium' ),
			'param_name'  => 'more_height',
			'dependency'  => array( 'element' => 'service_type', 'value' => 'type_1'),
			'value'       => false,
		),
		array(
		    'type'        => 'attach_image',
		    'heading'     => __( "Image", "nrg_premium" ),
		    'param_name'  => 'image',
		    'admin_label' => true,
		    'description' => 'Upload your image.',
		    'dependency'  => array( 'element' => 'service_type', 'value' => array('type_1', 'type_2', 'type_6')),
		  ),
		array(
			'type'        => 'dropdown',
			'heading'     => __( 'Button type', 'nrg_premium' ),
			'param_name'  => 'btn_type',
			'value'       => array(
				'Type 1'   => 'type_1',
				'Type 2'   => 'type_2',
				'Type 3'   => 'type_3',
				'Type 4'   => 'type_4',
				'Type 5'   => 'type_5',
				'Type 6'   => 'type_6',
			),
			'dependency'  => array( 'element' => 'service_type', 'value' => array('type_3', 'type_4', 'type_6')),
			'group'		  => 'Link',
		),
		array(
			'type'			=> 'dropdown',
			'heading'		=> __( 'Button width', 'nrg_premium' ),
			'param_name'	=> 'b_width',
			'value'			=> array(
				'Standart'		=> 'standart',
				'Small'			=> 'small',
			),
			'dependency'  => array( 'element' => 'service_type', 'value' => array('type_3', 'type_4', 'type_6')),
			'group'		  => 'Link',
		),
		array(
			'type'			=> 'colorpicker',
			'class'			=> '',
			'heading'		=> __( 'Main color', 'nrg_premium' ),
			'param_name'	=> 'm_color',
			'value'			=> '#84694e',
			'dependency'  => array( 'element' => 'service_type', 'value' => array('type_3', 'type_4', 'type_6')),
			'group'		  => 'Link',
		),
		array(
			'type'        => 'vc_link',
			'heading'     => 'Button url',
			'param_name'  => 'button_url',
			'admin_label' => true,
			'value'       => '',
			'dependency'  => array( 'element' => 'service_type', 'value' => array('type_1', 'type_2', 'type_3', 'type_4', 'type_6')),
			'group'		  => 'Link',
		),
		array(
			'type'        => 'textfield',
			'heading'     =>  __( "Button title", "nrg_premium" ),
			'param_name'  => 'button_title',
			'admin_label' => true,
			'value'       => '',
			'dependency'  => array( 'element' => 'service_type', 'value' => array('type_3', 'type_4', 'type_6')),
			'group'		  => 'Link',
		),
		array(
			'type'        => 'dropdown',
			'heading'     => __( 'Button Align', 'nrg_premium' ),
			'param_name'  => 'btn_align',
			'value'       => array(
				'Align left'    => 'left',
				'Align center'  => 'center',
				),
			'dependency'  => array( 'element' => 'service_type', 'value' => array('type_3', 'type_4', 'type_6')),
			'group'		  => 'Link',
		),
		array(
			'type'        => 'dropdown',
			'heading'     => __( 'Text Align', 'nrg_premium' ),
			'param_name'  => 'txt_align',
			'value'       => array(
				'Align left'    => 'left',
				'Align center'  => 'center',
				),
			'dependency'  => array( 'element' => 'service_type', 'value' => array('type_3', 'type_6')),
		),
		array(
			'type'        => 'textfield',
			'heading'     =>  __( "Title", "nrg_premium" ),
			'param_name'  => 'title',
			'admin_label' => true,
			'value'       => '',
		),
		array(
			'type'        => 'textfield',
			'heading'     =>  __( "Subtitle", "nrg_premium" ),
			'param_name'  => 'subtitle',
			'admin_label' => true,
			'value'       => '',
			'dependency'  => array( 'element' => 'service_type', 'value' => array('type_1', 'type_3', 'type_4', 'type_5', 'type_6')),
		),
		array(
			'type' => 'textarea',
			'heading' => __( 'Short Description', 'nrg_premium' ),
			'param_name' => 'short_desc',
		),
		array(
			'type' => 'textfield',
			'heading' => __( 'Extra class name', 'nrg_premium' ),
			'param_name' => 'el_class',
			'description' => __( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'nrg_premium' ),
			'value' => '',
		),
		array(
			'type' => 'css_editor',
			'heading' => __( 'CSS box', 'nrg_premium' ),
			'param_name' => 'css',
			'group' => __( 'Design options', 'nrg_premium' ),
		),
	) //end params
) );

class WPBakeryShortCode_nrg_premium_icon_box extends WPBakeryShortCode {
	protected function content( $atts, $content = null) {

		extract( shortcode_atts( array(
			'el_class'		=> '',
			'css'			=> '',
			'title'			=> '',
			'subtitle'		=> '',
			'short_desc'	=> '',
			'image'			=> '',
			'service_type'	=> 'type_1',
			'button_url'	=> '',
			'more_height'	=> false,
			'with_link'		=> false,
			'button_title'	=> '',
			'subtype'		=> 'type_1',
			'btn_align'		=> 'left',
			'btn_type'		=> 'type_1',
			'txt_align'		=> 'left',
			'm_color'		=> '',
			'b_width'		=> 'stardant',

 		), $atts ) );

		$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, $this->settings['base'], $atts );
		
		// custum css
		$css_class .= vc_shortcode_custom_css_class( $css, ' ' );

		// custum class
		$css_class .= (!empty($el_class)) ? ' '.$el_class : '';

		if (isset($button_url)) { 
			$button_link = vc_build_link($button_url);
		}

		// button align
		$btn_align_n = '';
		if ($btn_align == 'left') {
			$btn_align_n = 'text-left';
		} else {
			$btn_align_n = 'text-center';
		}

		// txt align
		$txt_align_n = '';
		if ($txt_align == 'left') {
			$txt_align_n = 'text-left';
		} else {
			$txt_align_n = 'text-center';
		}

		$href_class = '';
		if ( $more_height == true) {
			$href_class = 'lg-height';
		}

		$image_full = '';
		if (!empty($image)) {
			$image_full = wp_get_attachment_image_url( $image, 'full' );
		}

		$sub_t_class = '';
		$sub_desc_class = '';
		$sub_t3_class = '';


		if ($subtype == 'type_1') {
			$sub_t_class = 'h6';
			$sub_desc_class = 'simple-text col-1';
			$sub_t3_class = 'h3';
		} elseif ($subtype == 'type_2') {
			$sub_t_class = 'h5 sm';
			$sub_desc_class = 'sub-desc col-2';
			$sub_t3_class = 'h5 sm';
		}


 		// output
		ob_start();
		do_shortcode( $content );
		?>
		<!--Servise icon-->
		<div class="<?php print esc_attr( $css_class ); ?>">
			<?php if ($service_type == 'type_1') { ?>
				<a href="<?php if ($button_link) { print esc_html($button_link['url']);}?>" class="service-item <?php print esc_html($href_class); ?>">
					<?php if (!empty($image)) { ?>
						<div class="bg layer-hold" style="background-image: url(<?php print esc_url( $image_full );?>)"></div>
					<?php } ?>
					<div class="vertical-align full">
						<div class="description type-2">
							<?php if ($subtitle) { ?>
								<span class="sub-title col-1"><?php print esc_html($subtitle); ?></span>
								<div class="empty-sm-10 empty-xs-10"></div>
							<?php }
							if ($title) { ?>
								<h3 class="h3 title"><?php print esc_html($title);?></h3>
								<div class="empty-sm-10 empty-xs-10"></div>
							<?php }
							if( $short_desc ){ ?>
								<div class="simple-text col-3">
									<p><?php print wp_kses_post($short_desc); ?></p>
								</div> 
			    			<?php } ?>
						</div> 
					</div>
				</a>
				<div class="empty-sm-30 empty-xs-30"></div>
			<?php } elseif ($service_type == 'type_2') { ?>
				<div class="simple-item-1 <?php if ($with_link == true) {print esc_html('hover-block');} ?>">
					<?php if ($with_link == false) { ?>
						<div class="image">
							<img src="<?php print esc_url( $image_full );?>" alt="" class="resp-img">
						</div> 
					<?php } else { ?>
						<a href="<?php if (isset($button_link)) { print esc_html($button_link['url']);}?>" class="image hover-layer">
							<img src="<?php print esc_url( $image_full );?>" alt="" class="resp-img">
						</a>
					<?php } ?>
					<div class="empty-sm-25 empty-xs-25"></div>
					<?php if ($title || $short_desc) { ?>
						<div class="text">
							<?php if ($title) { ?>
								<h3 class="title no-tr <?php echo esc_html($sub_t_class); ?>"><a href="<?php if ($button_link) { print esc_html($button_link['url']);}?>"><?php print esc_html($title);?></a></h3>
							<?php }
							if( $short_desc ) { ?>
								<div class="empty-sm-15 empty-xs-15"></div> 
								<div class="<?php echo esc_html($sub_desc_class); ?>">
									<p><?php print wp_kses_post($short_desc); ?></p>
								</div>
							<?php } ?>
						</div>
					<?php } ?>
				</div>
			<?php } elseif ($service_type == 'type_3') { ?>
				<div class="service-icon-box style-6 flex-align text-center-xs <?php echo esc_html($txt_align_n); ?>">
					<div class="flex-wrap">
						<?php if ($title) { ?>
							<h6 class="title <?php echo esc_html($sub_t3_class); ?>"><?php echo esc_html($title); ?></h6>
							<div class="empty-sm-10 empty-xs-10"></div>
						<?php }
						if ($subtitle) { ?>
							<span class="sub-desc"><?php echo esc_html($subtitle); ?></span>  
							<div class="empty-sm-15 empty-xs-15"></div>
						<?php }
						if ($short_desc) { ?>
							<div class="simple-text col-1">
								<p><?php print wp_kses_post($short_desc); ?></p>
							</div>
							<div class="empty-sm-35 empty-xs-30"></div>
						<?php }
						hm_get_template_part('composer/shortcodes/buttons/button-'.$btn_type, [ 'title' => $button_title, 'but_url' => $button_url, 'but_align' =>  $btn_align_n, 'but_width' => $b_width, 'main_color' => $m_color ]); ?>
					</div>
				</div>
			<?php } elseif ($service_type == 'type_4') { ?>
				<div class="service-icon-box text-center-xs">
					<?php if ($title) { ?>
						<h6 class="title h5"><?php echo esc_html($title); ?></h6>
						<div class="empty-sm-5 empty-xs-5"></div>
					<?php }
					if ($subtitle) { ?>
						<span class="sub-desc"><?php echo esc_html($subtitle); ?></span>  
						<div class="empty-sm-15 empty-xs-15"></div>
					<?php }
					if ($short_desc) { ?>
						<div class="simple-text col-1">
							<p><?php echo wp_kses_post($short_desc); ?></p>
						</div>
						<div class="empty-sm-25 empty-xs-25"></div>
					<?php }
						hm_get_template_part('composer/shortcodes/buttons/button-'.$btn_type, [ 'title' => $button_title, 'but_url' => $button_url, 'but_align' =>  $btn_align_n, 'but_width' => $b_width, 'main_color' => $m_color ]); ?>
				</div>
			<?php } elseif ($service_type == 'type_5') { ?>
				<div class="service-icon-box style-3 flex-align text-center-xs lg">
					<div class="flex-wrap">
						<div class="title-separator-4"></div>
						<div class="empty-sm-25 empty-xs-25"></div>
						<?php if ($short_desc) { ?>
							<span class="sub-desc"><?php echo esc_html($title); ?></span>  
							<div class="empty-sm-5 empty-xs-5"></div>
						<?php }
						if ($title) { ?>
							<h6 class="title h4"><?php echo esc_html($subtitle); ?></h6>
						<?php }
						if ($short_desc) { ?>
							<div class="empty-sm-15 empty-xs-15"></div>
							<div class="simple-text col-1">
								<p><?php echo wp_kses_post($short_desc); ?></p>
							</div>
						<?php } ?>
					</div>
				</div>
			<?php } elseif ($service_type == 'type_6') { ?>
				<div class="simple-item-1">
					<?php if ($title || $subtitle) { ?>
						<div class="caption type-2">
							<?php if ($title) { ?>
								<h5 class="h5 title link-hover-1"><a href="<?php echo esc_html((isset($button_link)) ? $button_link['url'] : ''); ?>"><?php echo esc_html($title);?></a></h5>
								<div class="empty-sm-10 empty-xs-10"></div>
							<?php }
							if ($subtitle) { ?>
								<div class="sub-desc col-3"><?php echo esc_html($subtitle);?></div>
								<div class="empty-sm-30 empty-xs-30"></div>
							<?php } ?>
						</div>
					<?php } 
					if (!empty($image)) { ?>
						<a href="<?php echo esc_html((isset($button_link)) ? $button_link['url'] : ''); ?>" class="hover-block">
							<span class="hover-layer image bg-col-2">
								<img src="<?php print esc_url( $image_full );?>" alt="<?php echo esc_html($title);?>" class="full-img">
							</span>   
						</a>
						<div class="empty-sm-15 empty-xs-15"></div> 
					<?php } 
					if( $short_desc ){ ?>
						<div class="simple-text col-1">
							<p><?php echo wp_kses_post($short_desc); ?></p>
						</div>
						<div class="empty-sm-25 empty-xs-25"></div> 
					<?php }
						hm_get_template_part('composer/shortcodes/buttons/button-'.$btn_type, [ 'title' => $button_title, 'but_url' => $button_url, 'but_align' =>  $btn_align_n, 'but_width' => $b_width, 'main_color' => $m_color ]); ?>
					<div class="empty-sm-30 empty-xs-30"></div>
				</div> 	
			<?php } ?>
		</div>
		<?php 
		return  ob_get_clean();
	}
}
 