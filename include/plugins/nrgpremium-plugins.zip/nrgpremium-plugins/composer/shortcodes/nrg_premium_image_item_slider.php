<?php 
/*
** Image item slider
** Version: 1.0.0 
*/


vc_map( array(
	'name'                    => __( 'Image slider', 'nrg_premium' ),
	'base'                    => 'nrg_premium_image_item_slider',
	'as_parent'               => array('only' => 'nrg_premium_image_item_slider_item'),
	'content_element'         => true,
	'show_settings_on_create' => true,
	'category' 				  => __( 'NRGPremium', 'nrg_premium' ),
	'description'             => __( 'Image item slider', 'nrg_premium'),
	'js_view'                 => 'VcColumnView',
	'params'          => array(
		array(
			'type' => 'textfield',
			'heading' => __( 'Extra class name', 'nrg_premium' ),
			'param_name' => 'el_class',
			'description' => __( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'nrg_premium' ),
			'value' => '',
		),
		array(
			'type' => 'css_editor',
			'heading' => __( 'CSS box', 'nrg_premium' ),
			'param_name' => 'css',
			'group' => __( 'Design options', 'nrg_premium' ),
		),
	) //end params
) );

class WPBakeryShortCode_nrg_premium_image_item_slider extends WPBakeryShortCodesContainer {

	protected function content( $atts, $content = null) {

		extract( shortcode_atts( array(
			'el_class'     => '',
			'css'          => '',
		), $atts ) );

		global $_image_item_sliders_items;
		$_image_item_sliders_items = array();

		$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, $this->settings['base'], $atts );

		// custum css
		$css_class .= vc_shortcode_custom_css_class( $css, ' ' );

		// custum class
		$css_class .= (!empty($el_class)) ? ' '.$el_class : '';
		
		// output
		ob_start();
		do_shortcode( $content );
		?>
        <div class="arrow-closest <?php print esc_attr( $css_class ); ?>">
			<div class="swiper-container full-h" data-mode="horizontal" data-autoplay="0" data-effect="slide" data-slides-per-view="1" data-loop="0" data-speed="800">
			    <div class="swiper-wrapper">
			    <?php 
					foreach ($_image_item_sliders_items as $key => $shortcode):
					$shortcode_atts = $shortcode['atts'];
					$image_html = '';
					if (isset($shortcode_atts['image'])) {
						$image_full = wp_get_attachment_image_url( $shortcode_atts['image'], 'full' );
						$image_html = '<img src="'. esc_url( $image_full ).'" alt="" class="resp-img"><div class="empty-sm-50 empty-xs-30"></div>';
					} ?>
						<div class="swiper-slide">
							<div class="styled-block style-1">  
								<div class="caption text-center">
									<?php print $image_html ?>
									<?php if (isset($shortcode_atts['subtitle'])) { ?>
										<span class="sub-title col-7 sm"><?php print esc_html($shortcode_atts['subtitle']) ?></span>
										<div class="empty-sm-5 empty-xs-5"></div>
									<?php }
									if (isset($shortcode_atts['title'])) { ?>
										<h4 class="h4 title"><?php print esc_html($shortcode_atts['title']) ?></h4>
										<div class="empty-sm-25 empty-xs-25"></div>
									<?php } ?>
									<div class="title-separator-1"><span></span></div>
									<div class="empty-sm-30 empty-xs-30"></div>
									<?php if (isset($shortcode_atts['short_desc'])) { ?>
										<div class="simple-text col-1">
											<p><?php print wp_kses_post($shortcode_atts['short_desc']); ?></p>
										</div>
										<div class="empty-sm-35 empty-xs-30"></div>
									<?php } ?>
									<?php if (isset($shortcode_atts['button_title']) && isset($shortcode_atts['button_url'])) { 
									 	$button_link = vc_build_link($shortcode_atts['button_url']);
										$btn_type 		= $shortcode_atts['btn_type'];
										$button_title	= $shortcode_atts['button_title'];
										$button_url		= $shortcode_atts['button_url']; 
										$main_color		= $shortcode_atts['m_color']; ?>
										<?php hm_get_template_part('composer/shortcodes/buttons/button-'.$btn_type, [ 'title' => $button_title, 'but_url' => $button_url, 'but_align' =>  'text-center', 'main_color' => $main_color, 'but_width' => 'standart' ] ); ?>
										<div class="empty-sm-40 empty-xs-20"></div>
									<?php } ?>
								</div> 
							</div>
						</div>
					<?php endforeach; ?>
			    </div>
			    <div class="empty-lg-90 empty-md-90 empty-sm-80 empty-xs-100"></div>
			    <div class="pagination color-black"></div>
			</div>
		</div>
		<?php 
		return  ob_get_clean();
	}

}
/* Shortvode Item */

vc_map( array(
  'name'            => 'Image slider item',
  'base'            => 'nrg_premium_image_item_slider_item',
  'as_child' 		=> array('only' => 'nrg_premium_image_item_slider'),
  'content_element' => true,
  'show_settings_on_create' => true,
  'description'     => 'Image, title and text',
  'params'          => array(
		array(
			'type'        => 'attach_image',
			'heading'     => __( "Image", "nrg_premium" ),
			'param_name'  => 'image',
			'admin_label' => true,
			'description' => 'Upload your image.'
		),
		array(
			'type'        => 'textfield',
			'heading'     =>  __( "Title", "nrg_premium" ),
			'param_name'  => 'title',
			'admin_label' => true,
			'value'       => '',
		),
		array(
			'type'        => 'textfield',
			'heading'     =>  __( "Subtitle", "nrg_premium" ),
			'param_name'  => 'subtitle',
			'admin_label' => true,
			'value'       => '',
		),
		array(
			'type' 		  => 'textarea',
			'heading'	  => __( 'Short Description', 'nrg_premium' ),
			'param_name'  => 'short_desc',
		),
		array(
			'type'			=> 'dropdown',
			'heading'		=> __( 'Button type', 'nrg_premium' ),
			'param_name'	=> 'btn_type',
			'value'			=> array(
				'Type 1'		=> 'type_1',
				'Type 2'		=> 'type_2',
				'Type 3'		=> 'type_3',
				'Type 4'		=> 'type_4',
				'Type 5'		=> 'type_5',
				'Type 6'		=> 'type_6',
			)
		),
		array(
			'type'			=> 'textfield',
			'heading'		=> 'Button title',
			'param_name'	=> 'button_title',
			'admin_label'	=> true,
			'value'			=> '',
		),
		array(
			'type'			=> 'vc_link',
			'heading'		=> 'Button url',
			'param_name'	=> 'button_url',
			'admin_label'	=> true,
			'value'			=> '#',
		),
		array(
			'type'			=> 'colorpicker',
			'class'			=> '',
			'heading'		=> __( 'Main color', 'nrg_premium' ),
			'param_name'	=> 'm_color',
			'value'			=> '#84694e',
		),
	) //end params
) );


class WPBakeryShortCode_nrg_premium_image_item_slider_item extends WPBakeryShortCode{
	protected function content( $atts, $content = null ) {

		global $_image_item_sliders_items;
		$atts['m_color'] = ( isset($atts['m_color']) ? $atts['m_color'] : '#84694e' );
		$atts['btn_type'] = ( isset($atts['btn_type']) ? $atts['btn_type'] : 'type_1' );
		$_image_item_sliders_items[] = array( 'atts' => $atts, 'content' => $content, 'css_class' => '');
		return;
	}
}