<?php 
/*
** Top rated
** Author: NRGTHEMES
** Author URI: http://nrgthemes.com
** Version: 1.0.0 
*/

vc_map( array(
	'name'                    => __( 'Top rated', 'nrg_premium' ),
	'base'                    => 'nrg_premium_top_rated',
	'category' 				  => __( 'NRGPremium', 'nrg_premium' ),
	'content_element'         => true,
	'show_settings_on_create' => true,
	'description' 		      => __( 'Pricing for restaurant', 'nrg_premium' ),
	'params'          => array(
		array(
			'type'        => 'textfield',
			'heading'     => __( 'Count items', 'nrg_premium' ),
			'param_name'  => 'number',
			'value'       => '',
			'description' => __( 'Default 10 items.', 'nrg_premium' )
		),
		array(
			'type' => 'textfield',
			'heading' => __( 'Extra class name', 'nrg_premium' ),
			'param_name' => 'el_class',
			'description' => __( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'nrg_premium' ),
			'value' => '',
		),
		array(
			'type' => 'css_editor',
			'heading' => __( 'CSS box', 'nrg_premium' ),
			'param_name' => 'css',
			'group' => __( 'Design options', 'nrg_premium' ),
		),
	) //end params
) );

class WPBakeryShortCode_nrg_premium_top_rated extends WPBakeryShortCode {
	protected function content( $atts, $content = null) {

		extract( shortcode_atts( array(
			'el_class'      => '',
			'css'           => '',
			'number'		=> '',

 		), $atts ) );

		$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, $this->settings['base'], $atts );
		
		// custum css
		$css_class .= vc_shortcode_custom_css_class( $css, ' ' );

		// custum class
		$css_class .= (!empty($el_class)) ? ' '.$el_class : '';

		$number 	  = ( empty( $number ) || ! is_numeric( $number ) ) ? 10 : $number;

		// output
		ob_start();
			do_shortcode( $content );
			$number = 5;
			$args = array(
				'post_type' 	 => 'product',
				'posts_per_page' => $number,
				'no_found_rows'  => 1,
				'post_status' 	 => 'publish',
				'meta_key' 		 => 'total_sales',
				'meta_value'	 => '1',
				'meta_compare' 	 => '>='
			);
			$query = new WP_Query( $args );
		if( $query->have_posts() ){
		?>
		<div class="<?php print esc_attr( $css_class ); ?>">
			<div class="arrow-closest arrow-hover align-arrow"> 
				<div class="row">   
					<div class="swiper-container gutter-15 padd-xs-off" data-mode="horizontal" data-autoplay="0" data-effect="slide" data-slides-per-view="responsive" data-loop="0" data-speed="800" data-add-slides="4" data-lg-slides="4" data-md-slides="3" data-sm-slides="2" data-xs-slides="1">
						<div class="swiper-wrapper">
							<?php while ( $query->have_posts() ) { $query->the_post();
								global $product; ?>
								<div class="swiper-slide">
									<div class="product-item <?php if ($product->is_on_sale()){ echo esc_html('hot');}?>">
										<div class="image">
											<?php if ($product->is_on_sale()) { ?>
												<div class="category"><?php print esc_html__('Hot', 'nrg_premium'); ?></div>
											<?php } ?>
											<div class="prod-view"><a href="#" class="open-popup" data-popup="index-popup-1">quick view</a></div>
											<img src="<?php echo get_the_post_thumbnail_url();?>" alt="" class="resp-img">
											<div class="product-button">
												<a href="<?php echo get_the_permalink(); ?>" class="prod-more"><?php echo esc_html__('view more', 'nrg_premium'); ?></a>    
												<div class="prod-icon-link add-to-wish"><i class="fa fa-heart-o"></i><i class="fa fa-heart"></i><?php echo do_shortcode('[yith_wcwl_add_to_wishlist]'); ?></div>    
												<a href="#" class="prod-icon-link add-to-cart" data-quantity="1" data-postid="<?php echo wp_kses_post( $product->id ); ?>"><i class="fa fa-shopping-basket"></i><i class="fa fa-spinner"></i><i class="fa fa-check-circle-o"></i></a>    
											</div>
										</div> 
										<div class="text">
											<div class="empty-sm-20 empty-xs-20"></div>    
											<h6 class="h6 title"><a href="<?php echo get_the_permalink(); ?>"><?php echo the_title(); ?></a></h6>
											<i class="prod-subtitle"><?php echo the_excerpt(); ?></i>
											<span class="prod-price"><?php echo $product->get_price_html(); ?></span>
										</div>
									</div>
								</div>
							<?php } ?>
						</div>
						<div class="pagination pagination-hide"></div>
					</div>
					<div class="swiper-arrow-left slider-arrow-1"><i class="fa fa-angle-left"></i></div>
					<div class="swiper-arrow-right slider-arrow-1"><i class="fa fa-angle-right"></i></div> 
				</div>
			</div>
		</div>
		<?php }




			wp_reset_postdata();
		return ob_get_clean();
	}
}