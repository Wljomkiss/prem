<?php 
/*
** NRG Button
** Author: NRGTHEMES
** Author URI: http://nrgthemes.com
** Version: 1.0.0 
*/

vc_map( array(
	'name'                    => __( 'Button', 'nrg_premium' ),
	'base'                    => 'nrg_premium_button',
	'category' 				  => __( 'NRGPremium', 'nrg_premium' ),
	'content_element'         => true,
	'show_settings_on_create' => true,
	'description' 		      => __( 'Simple button', 'nrg_premium' ),
	'params'          => array(
		array(
			'type'        => 'dropdown',
			'heading'     => __( 'Button type', 'nrg_premium' ),
			'param_name'  => 'btn_type',
			'value'       => array(
				'Type 1'   => 'type_1',
				'Type 2'   => 'type_2',
				'Type 3'   => 'type_3',
				'Type 4'   => 'type_4',
				'Type 5'   => 'type_5',
				'Type 6'   => 'type_6',
			)
		),
		array(
			'type'			=> 'dropdown',
			'heading'		=> __( 'Button width', 'nrg_premium' ),
			'param_name'	=> 'b_width',
			'value'			=> array(
				'Standart'		=> 'standart',
				'Small'			=> 'small',
			),
			'dependency'  => array( 'element' => 'btn_type', 'value' => array('type_1', 'type_3')),
		),
		array(
			'type'        => 'textfield',
			'heading'     => 'Button title',
			'param_name'  => 'button_title',
			'admin_label' => true,
			'value'       => '',
		),
		array(
			'type'        => 'vc_link',
			'heading'     => 'Button url',
			'param_name'  => 'button_url',
			'admin_label' => true,
			'value'       => '',
		),
		array(
			'type'			=> 'colorpicker',
			'class'			=> '',
			'heading'		=> __( 'Main color', 'nrg_premium' ),
			'param_name'	=> 'm_color',
			'value'			=> '#84694e',
		),
		array(
			'type'        => 'dropdown',
			'heading'     => __( 'Button Align', 'nrg_premium' ),
			'param_name'  => 'btn_align',
			'value'       => array(
				'Align left'    => 'align_left',
				'Align center'  => 'align_center',
				)
		),
		array(
			'type' => 'textfield',
			'heading' => __( 'Extra class name', 'nrg_premium' ),
			'param_name' => 'el_class',
			'description' => __( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'nrg_premium' ),
			'value' => '',
		),
		array(
			'type' => 'css_editor',
			'heading' => __( 'CSS box', 'nrg_premium' ),
			'param_name' => 'css',
			'group' => __( 'Design options', 'nrg_premium' ),
		),
	) //end params
) );

class WPBakeryShortCode_nrg_premium_button extends WPBakeryShortCode {
	protected function content( $atts, $content = null) {

		extract( shortcode_atts( array(
			'el_class'      => '',
			'css'           => '',
			'button_title'  => '',
			'button_url'    => '',
			'btn_type'		=> 'type_1',
			'btn_align'  	=> 'align_left',
			'm_color'		=> '',
			'b_width'		=> 'standart',

 		), $atts ) );

		$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, $this->settings['base'], $atts );
		
		// custum css
		$css_class .= vc_shortcode_custom_css_class( $css, ' ' );

		// custum class
		$css_class .= (!empty($el_class)) ? ' '.$el_class : '';

		// button align
		$btn_align_n = '';
		if ($btn_align == 'align_left') {
			$btn_align_n = 'text-left';
		} else {
			$btn_align_n = 'text-center';
		}

 		// output
		ob_start();
		do_shortcode( $content ); 
		//--Button--//
		?>
		<div class="<?php print esc_attr( $css_class ); ?>">	
			<?php hm_get_template_part('composer/shortcodes/buttons/button-'.$btn_type, [ 'title' => $button_title, 'but_url' => $button_url, 'but_align' =>  $btn_align_n, 'main_color' => $m_color, 'but_width' => $b_width ]); ?>
		</div>
		<?php 
		return  ob_get_clean();
	}
}
