<?php 
/*
** Testemonials
** Version: 1.0.0 
*/


vc_map( array(
	'name'                    => __( 'Testimonials', 'nrg_premium' ),
	'base'                    => 'nrg_premium_testemonials',
	'as_parent'               => array('only' => 'nrg_premium_testemonials_item'),
	'content_element'         => true,
	'show_settings_on_create' => true,
	'category' 				  => __( 'NRGPremium', 'nrg_premium' ),
	'description'             => __( 'Testimonials', 'nrg_premium'),
	'js_view'                 => 'VcColumnView',
	'params'          => array(
		array(
			'type'        => 'dropdown',
			'heading'     => __( 'Testimonials type', 'nrg_premium' ),
			'param_name'  => 'teste_type',
			'value'       => array(
				'Type 1'   => 'type_1',
				'Type 2'   => 'type_2',
				'Type 3'   => 'type_3',
				'Type 4'   => 'type_4',
				'Type 5'   => 'type_5',
				'Type 6'   => 'type_6',
			)
		),
		array(
			'type'        => 'dropdown',
			'heading'     => __( 'Color type', 'nrg_premium' ),
			'param_name'  => 'color_type',
			'value'       => array(
				'White'   => 'white',
				'Black'   => 'black',
			),
			'dependency'  => array( 'element' => 'teste_type', 'value' => array('type_3', 'type_2')),
		),
		array(
			'type'        => 'attach_image',
			'heading'     => __( 'Image', 'nrg_premium' ),
			'param_name'  => 'image',
			'admin_label' => true,
			'description' => 'Upload your image.',
			'dependency'  => array( 'element' => 'teste_type', 'value' => 'type_1'),
		),
		array(
			'type' => 'textfield',
			'heading' => __( 'Extra class name', 'nrg_premium' ),
			'param_name' => 'el_class',
			'description' => __( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'nrg_premium' ),
			'value' => '',
		),
		array(
			'type' => 'css_editor',
			'heading' => __( 'CSS box', 'nrg_premium' ),
			'param_name' => 'css',
			'group' => __( 'Design options', 'nrg_premium' ),
		),
	) //end params
) );

class WPBakeryShortCode_nrg_premium_testemonials extends WPBakeryShortCodesContainer {

	protected function content( $atts, $content = null) {

		extract( shortcode_atts( array(
			'el_class'		=> '',
			'css'			=> '',
			'image'			=> '',
			'teste_type'	=> 'type_1',
			'color_type'	=> 'white',

		), $atts ) );

		global $_testemonials_items;
		$_testemonials_items = array();

		$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, $this->settings['base'], $atts );

		// custum css
		$css_class .= vc_shortcode_custom_css_class( $css, ' ' );

		// custum class
		$css_class .= (!empty($el_class)) ? ' '.$el_class : '';
		
		$image_html = '';
			if (!empty($image)) {
			$image_full = wp_get_attachment_image_url( $image, 'full' );
			$image_html = '<div class="bg layer-hold type-5" style="background-image: url('.esc_url( $image_full ).')"></div>';
		}

		// simple-text class

		$main_class = $color_title = $color_subtitle = $color_desc = '';
		if ($color_type == 'white') {
			$main_class = 'type-2';
			$color_subtitle = 'col-1';
			$color_desc = 'col-2';
		} else {
			$color_subtitle = 'col-2';
			$color_desc = 'col-1';
		}


		// output
		ob_start();
		do_shortcode( $content );
		?>
		
		<div class="<?php echo esc_attr( $css_class ); ?>">
			<?php if ($teste_type == 'type_1') {  ?>
				<div class="item-h-600 custome-padd-100 flex-align">
					<?php echo $image_html ?>
					<div class="swiper-container item-h-600-align" data-mode="horizontal" data-autoplay="0" data-effect="slide" data-slides-per-view="1" data-loop="0" data-speed="800">
						<div class="swiper-wrapper">
							<?php foreach ($_testemonials_items as $key => $shortcode):
								$shortcode_atts = $shortcode['atts'];
								$icon_html = '';
								if (isset($shortcode_atts['icon'])) {
									$icon_full = wp_get_attachment_image_url( $shortcode_atts['icon'], 'full' );
									$icon_html = '<img src="'.esc_url( $icon_full ).'" alt=""><div class="empty-sm-25 empty-xs-25"></div>';
								} 
								if (isset($shortcode_atts['comment'])) { ?>
									<div class="swiper-slide">
										<div class="tesimonials-item">
											<?php echo $icon_html ?>
											<div class="simple-text col-4">
												<p><?php echo wp_kses_post($shortcode_atts['comment']);?></p>
											</div>
											<?php if (isset($shortcode_atts['name'])) { ?>
												<div class="empty-sm-25 empty-xs-25"></div>
												<h4 class="h4"><?php echo esc_html($shortcode_atts['name']); ?></h4>
											<?php }
											if (isset($shortcode_atts['position'])) { ?>
												<div class="empty-sm-5 empty-xs-5"></div>
												<span class="sub-desc"><?php echo esc_html($shortcode_atts['position']); ?></span>
											<?php } ?>
										</div>
									</div>
								<?php }
							endforeach; ?>
						</div>
						<div class="pagination color-black type-col-2"></div>
					</div>
				</div>
			<?php }
			elseif ($teste_type == 'type_2') { ?>
				<div class="swiper-container" data-mode="horizontal" data-autoplay="0" data-effect="slide" data-slides-per-view="1" data-loop="0" data-speed="800">
					<div class="swiper-wrapper">
						<?php foreach ($_testemonials_items as $key => $shortcode):
							$shortcode_atts = $shortcode['atts'];
							$icon_html = '';
							if (isset($shortcode_atts['icon'])) {
								$icon_full = wp_get_attachment_image_url( $shortcode_atts['icon'], 'full' );
								$icon_html = '<img src="'.esc_url( $icon_full ).'" alt=""><div class="empty-sm-25 empty-xs-25"></div>';
							} 
							if (isset($shortcode_atts['comment'])) { ?>
								<div class="swiper-slide">
									<div class="container-fluid">
										<div class="row">
											<div class="col-md-8 col-md-offset-2">
												<div class="tesimonials-item text-center <?php echo esc_html($main_class); ?>">
													<?php echo $icon_html ?>
													<div class="empty-sm-25 empty-xs-25"></div>
													<div class="simple-text <?php echo esc_html($color_desc); ?> lgx">
														<p><?php echo wp_kses_post($shortcode_atts['comment']);?></p>
													</div>
													<?php if (isset($shortcode_atts['name'])) { ?>
														<div class="empty-sm-25 empty-xs-25"></div>
														<h4 class="h4 title"><?php echo esc_html($shortcode_atts['name']); ?></h4>
													<?php }
													if (isset($shortcode_atts['position'])) { ?>	
														<div class="empty-sm-5 empty-xs-5"></div>
														<span class="sub-desc <?php echo esc_html($color_subtitle); ?>"><?php echo esc_html($shortcode_atts['position']); ?></span>
													<?php } ?>
												</div>
											</div>
										</div>
									</div>
								</div>
							<?php }
						endforeach; ?>
					</div>
					<div class="empty-lg-180 empty-md-100 empty-sm-60 empty-xs-60"></div>
					<div class="pagination type-col-3"></div>
				</div> 
			<?php }
			elseif ($teste_type == 'type_3') { ?>
				<div class="arrow-closest mobile-pagination">
					<div class="swiper-container" data-mode="horizontal" data-autoplay="0" data-effect="slide" data-slides-per-view="1" data-loop="0" data-speed="800">
						<div class="swiper-wrapper">
							<?php foreach ($_testemonials_items as $key => $shortcode):
								$shortcode_atts = $shortcode['atts'];
								$icon_html = '';
								if (isset($shortcode_atts['icon'])) {
									$icon_full = wp_get_attachment_image_url( $shortcode_atts['icon'], 'full' );
									$icon_html = '<img src="'.esc_url( $icon_full ).'" alt=""><div class="empty-sm-25 empty-xs-25"></div>';
								} 
								if (isset($shortcode_atts['comment'])) { ?>
									<div class="swiper-slide">
										<div class="container">
											<div class="row">
												<div class="col-md-8 col-md-offset-2">
													<div class="tesimonials-item text-center">
														<?php echo $icon_html ?>
														<div class="empty-sm-20 empty-xs-20"></div>
														<div class="simple-text <?php echo esc_html($color_desc); ?> lgx">
															<p><?php echo wp_kses_post($shortcode_atts['comment']);?></p>
														</div>
														<?php if (isset($shortcode_atts['name'])) { ?>
															<div class="empty-sm-15 empty-xs-15"></div>
															<h4 class="h4 title"><?php echo esc_html($shortcode_atts['name']); ?></h4>
														<?php }
														if (isset($shortcode_atts['position'])) { ?>
														<div class="empty-sm-5 empty-xs-5"></div>
														<span class="sub-desc <?php echo esc_html($color_desc); ?>"><?php echo esc_html($shortcode_atts['position']); ?></span>
														<?php } ?>
													</div>
												</div>
											</div>
										</div>
									</div>
								<?php }
							endforeach; ?>
						</div>
						<div class="empty-lg-0 empty-md-0 empty-sm-100 empty-xs-60"></div> 
						<div class="pagination pagination-hide type-2 colo-type-1"></div>
					</div>
					<div class="swiper-arrow-left slider-arrow-1"><i class="fa fa-angle-left"></i></div>
					<div class="swiper-arrow-right slider-arrow-1"><i class="fa fa-angle-right"></i></div>
				</div>
			<?php }
			elseif ($teste_type == 'type_4') { ?>
				<div class="arrow-closest padd-20 clear-xs-padd mobile-pagination">
					<div class="swiper-container full-h step-slider" data-mode="horizontal" data-autoplay="0" data-effect="slide" data-slides-per-view="1" data-loop="0" data-speed="800">
						<div class="swiper-wrapper">
							<?php foreach ($_testemonials_items as $key => $shortcode):
							$shortcode_atts = $shortcode['atts'];
							$icon_html = '';
							if (isset($shortcode_atts['icon'])) {
								$icon_full = wp_get_attachment_image_url( $shortcode_atts['icon'], 'full' );
								$icon_html = '<img src="'.esc_url( $icon_full ).'" alt=""><div class="empty-sm-25 empty-xs-25"></div>';
							} 
							if (isset($shortcode_atts['comment'])) { ?>
								<div class="swiper-slide">
									<div class="tesimonials-dark-bg">
										<div class="caption text-center">
											<?php echo $icon_html ?>
											<div class="empty-sm-30 empty-xs-30"></div>
											<div class="simple-text col-2">
												<p><?php echo wp_kses_post($shortcode_atts['comment']);?></p>
											</div>
											<div class="empty-sm-25 empty-xs-20"></div>
											<?php if (isset($shortcode_atts['name'])) { ?>
												<h4 class="h4"><?php echo esc_html($shortcode_atts['name']); ?></h4>
											<?php }
											if (isset($shortcode_atts['position'])) { ?>
												<div class="empty-sm-5 empty-xs-5"></div>
												<span class="sub-title sm tt ls col-6"><?php echo esc_html($shortcode_atts['position']); ?></span>
											<?php } ?>
										</div>
									</div>
								</div>
							<?php }
							endforeach; ?>
						</div>
						<div class="pagination pagination-hide color-revers"></div>
					</div>
					<div class="swiper-arrow-left slider-arrow-1 type-4 sm"><i class="fa fa-angle-left"></i></div>
					<div class="swiper-arrow-right slider-arrow-1 type-4 sm"><i class="fa fa-angle-right"></i></div>
				</div>
			<?php }
			elseif ($teste_type == 'type_5') { ?>
				<div class="swiper-container full-h step-slider" data-mode="horizontal" data-autoplay="0" data-effect="slide" data-slides-per-view="1" data-loop="0" data-speed="800">
					<div class="swiper-wrapper">
						<?php foreach ($_testemonials_items as $key => $shortcode):
							$shortcode_atts = $shortcode['atts'];
							$icon_html = '';
							if (isset($shortcode_atts['icon'])) {
								$icon_full = wp_get_attachment_image_url( $shortcode_atts['icon'], 'full' );
								$icon_html = '<img src="'.esc_url( $icon_full ).'" alt=""><div class="empty-sm-25 empty-xs-25"></div>';
							} 
							if (isset($shortcode_atts['comment'])) { ?>
								<div class="swiper-slide">
									<div class="custome-padd-100">
										<div class="caption text-center">
											<?php echo $icon_html ?>
											<div class="empty-sm-30 empty-xs-30"></div>
											<div class="simple-text col-1">
												<p><?php echo wp_kses_post($shortcode_atts['comment']);?></p>
											</div>
											<?php if (isset($shortcode_atts['name'])) { ?>
												<div class="empty-sm-30 empty-xs-20"></div>
												<h4 class="h4"><?php echo esc_html($shortcode_atts['name']); ?></h4>
											<?php } 
											if (isset($shortcode_atts['position'])) { ?>
												<div class="empty-sm-5 empty-xs-5"></div>
												<span class="sub-title sm tt ls col-3"><?php echo esc_html($shortcode_atts['position']); ?></span>
											<?php } ?>
										</div>
									</div>
								</div>
							<?php }
						endforeach; ?>
					</div>
					<div class="empty-lg-190 empty-md-100 empty-sm-40 empty-xs-40"></div> 
					<div class="pagination type-2 colo-type-4"></div>
				</div>
			<?php }
			elseif ($teste_type == 'type_6') { ?>
				<div class="swiper-container gutter-15 pagination-bottom" data-mode="horizontal" data-autoplay="0" data-effect="slide" data-slides-per-view="responsive" data-loop="0" data-speed="800" data-add-slides="2" data-lg-slides="2" data-md-slides="1" data-sm-slides="1" data-xs-slides="1">
					<div class="swiper-wrapper">
						<?php foreach ($_testemonials_items as $key => $shortcode):
							$shortcode_atts = $shortcode['atts'];
							$icon_html = '';
							if (isset($shortcode_atts['icon'])) {
								$icon_full = wp_get_attachment_image_url( $shortcode_atts['icon'], 'full' );
								$icon_html = '<img src="'.esc_url( $icon_full ).'" alt=""><div class="empty-sm-30 empty-xs-30"></div>';
							} 
							if (isset($shortcode_atts['comment'])) { ?>
							<div class="swiper-slide">
								<div class="frame-block sm-frame">
									<div class="empty-sm-50 empty-xs-40"></div>
									<div class="custome-padd-80">
										<div class="caption text-center">
											<?php echo $icon_html ?>
											<div class="empty-sm-30 empty-xs-30"></div>
											<div class="simple-text col-1">
												<p><?php echo wp_kses_post($shortcode_atts['comment']);?></p>
											</div>
											<?php if (isset($shortcode_atts['name'])) { ?>
												<div class="empty-sm-25 empty-xs-20"></div>
												<h4 class="h4 title bold"><?php echo esc_html($shortcode_atts['name']); ?></h4>
											<?php } 
											if (isset($shortcode_atts['position'])) { ?>
												<div class="empty-sm-10 empty-xs-10"></div>
												<span class="sub-title tt col-9"><?php echo esc_html($shortcode_atts['position']); ?></span>
											<?php } ?>
										</div>
									</div>
									<div class="empty-sm-50 empty-xs-40"></div>
								</div>
							</div>
						<?php }
						endforeach; ?>
					</div>
					<div class="empty-sm-50 empty-xs-40"></div>
					<div class="pagination type-col-4 color-black"></div>
				</div>
			<?php } ?>
		</div>

		<?php 
		return  ob_get_clean();
	}

}
/* Shortvode Item */

vc_map( array(
  'name'            => 'Testimonials item',
  'base'            => 'nrg_premium_testemonials_item',
  'as_child' 		=> array('only' => 'nrg_premium_testemonials'),
  'content_element' => true,
  'show_settings_on_create' => true,
  'description'     => 'Image, title and text',
  'params'          => array(
		array(
			'type'        => 'attach_image',
			'heading'     => __( 'Icon', 'nrg_premium' ),
			'param_name'  => 'icon',
			'admin_label' => true,
			'description' => 'Upload your image.'
		),
		array(
			'type'        => 'textfield',
			'heading'     => __( 'Name', 'nrg_premium' ),
			'param_name'  => 'name',
			'admin_label' => true,
			'value'       => '',
		),
		array(
			'type'        => 'textfield',
			'heading'     => __( 'Position', 'nrg_premium' ),
			'param_name'  => 'position',
			'admin_label' => true,
			'value'       => '',
		),
		array(
			'type'        => 'textarea',
			'heading'     => __( 'Comment', 'nrg_premium' ),
			'param_name'  => 'comment',
		),
	) //end params
) );


class WPBakeryShortCode_nrg_premium_testemonials_item extends WPBakeryShortCode{
	protected function content( $atts, $content = null ) {

		global $_testemonials_items;
		$_testemonials_items[] = array( 'atts' => $atts, 'content' => $content, 'css_class' => '');
		return;
	}
}