<?php 
/*
** Banner
** Author: NRGTHEMES
** Author URI: http://nrgthemes.com
** Version: 1.0.0 
*/

vc_map( array(
	'name'                    => __( 'Banner', 'nrg_premium' ),
	'base'                    => 'nrg_premium_banner',
	'description' 		      => __( 'Banner', 'nrg_premium' ),
	'category' 				  => __( 'NRGPremium', 'nrg_premium' ),
	'content_element'         => true,
	'show_settings_on_create' => true,
	'params'          => array(
		array(
			'type'        => 'dropdown',
			'heading'     => __( 'Banner type', 'nrg_premium' ),
			'param_name'  => 'banner_type',
			'value'       => array(
				'Type 1'   => 'type_1',
				'Type 2'   => 'type_2',
				)
		),
		array(
			'type'        => 'attach_image',
			'heading'     => __( "Background Image", "nrg_premium" ),
			'param_name'  => 'image',
			'admin_label' => true,
			'description' => 'Upload your image.'
		),
		array(
			'type'			=> 'dropdown',
			'heading'		=> __( 'Button width', 'nrg_premium' ),
			'param_name'	=> 'b_width',
			'value'			=> array(
				'Standart'		=> 'standart',
				'Small'			=> 'small',
			),
			'group'		  => 'Button',
		),
		array(
			'type'			=> 'colorpicker',
			'class'			=> '',
			'heading'		=> __( 'Main color', 'nrg_premium' ),
			'param_name'	=> 'm_color',
			'value'			=> '#84694e',
			'group'		  => 'Button',
		),
		array(
			'type'        => 'textfield',
			'heading'     => __( "Title", "nrg_premium" ),
			'param_name'  => 'title',
			'admin_label' => true,
			'value'       => '',
		),
		array(
			'type'        => 'textfield',
			'heading'     => __( "Subtitle", "nrg_premium" ),
			'param_name'  => 'subtitle',
			'admin_label' => true,
			'value'       => '',
		),
		array(
			'type'        => 'attach_image',
			'heading'     => __( "Icon", "nrg_premium" ),
			'param_name'  => 'icon',
			'admin_label' => true,
			'description' => 'Upload your image.',
			'dependency'  => array( 'element' => 'banner_type', 'value' => 'type_2'),
		),
		array(
			'type'        => 'textarea',
			'heading'     => __( 'Short Description', 'nrg_premium' ),
			'param_name'  => 'short_desc',
		),
		array(
			'type'        => 'dropdown',
			'heading'     => __( 'Button type', 'nrg_premium' ),
			'param_name'  => 'btn_type',
			'value'       => array(
				'Type 1'   => 'type_1',
				'Type 2'   => 'type_2',
				'Type 3'   => 'type_3',
				'Type 4'   => 'type_4',
				'Type 5'   => 'type_5',
				'Type 6'   => 'type_6',
			),
			'group'		  => 'Button',

		),
		array(
			'type'        => 'textfield',
			'heading'     => 'Button title',
			'param_name'  => 'button_title',
			'admin_label' => true,
			'value'       => '',
			'group'		  => 'Button',
		),
		array(
			'type'        => 'vc_link',
			'heading'     => 'Button url',
			'param_name'  => 'button_url',
			'admin_label' => true,
			'value'       => '',
			'group'		  => 'Button',
		),
		array(
			'type'        => 'dropdown',
			'heading'     => __( 'Button Align', 'nrg_premium' ),
			'param_name'  => 'btn_align',
			'value'       => array(
				'Align left'    => 'align_left',
				'Align center'  => 'align_center',
			),
			'group'		  => 'Button',
		),
		array(
			'type' => 'textfield',
			'heading' => __( 'Extra class name', 'nrg_premium' ),
			'param_name' => 'el_class',
			'description' => __( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'nrg_premium' ),
			'value' => '',
		),
		array(
			'type' => 'css_editor',
			'heading' => __( 'CSS box', 'nrg_premium' ),
			'param_name' => 'css',
			'group' => __( 'Design options', 'nrg_premium' ),
		),
	) //end params
) );

class WPBakeryShortCode_nrg_premium_banner extends WPBakeryShortCode {
	protected function content( $atts, $content = null) {

		extract( shortcode_atts( array(
			'el_class'			=> '',
			'css'				=> '',
			'title'				=> '',
			'subtitle'			=> '',
			'short_desc'		=> '',
			'image'				=> '',
			'button_title'		=> '',
			'button_url'		=> '',
			'icon'				=> '',
			'banner_type'		=> 'type_1',
			'btn_type'			=> 'type_1',
			'btn_align'			=> 'align_left',
			'm_color'			=> '',
			'b_width'			=> 'standart',

 		), $atts ) );

		$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, $this->settings['base'], $atts );
		
		// custum css
		$css_class .= vc_shortcode_custom_css_class( $css, ' ' );

		// custum class
		$css_class .= (!empty($el_class)) ? ' '.$el_class : '';

		// button align
		$btn_align_n = '';
		if ($btn_align == 'align_left') {
			$btn_align_n = 'text-left';
		} else {
			$btn_align_n = 'text-center';
		}

		$img_class= '';
		if ($banner_type == 'type_1') {
			$img_class = 'fix type-11';
		} elseif ($banner_type == 'type_2') {
			$img_class = 'type-2';
		}


		$image_html = '';
		if ($image) {
			$image_full = wp_get_attachment_image_url( $image, 'full' );
			$image_html = '<div class="bg layer-hold '.$img_class.' '.$css_class.'" style="background-image: url('. esc_url( $image_full ).')"></div>';
		}


		$icon_html = '';
		if ($icon) {
			$icon_full = wp_get_attachment_image_url( $icon, 'full' );
			$icon_html = '<div class="empty-sm-10 empty-xs-10"></div><img src="'.esc_url( $icon_full ).'" alt="">';
		}

		$button_link = vc_build_link($button_url);

 		// output
		ob_start();
		do_shortcode( $content );
		?>
		<!--Banner-->
		<div class="main-top-slider no-offset <?php print esc_attr( $css_class ); ?>">
			<?php print $image_html; ?>
			<div class="vertical-align full">
				<div class="container">
					<div class="row">
						<?php if ($banner_type == 'type_1') { ?>
							<div class="col-md-8 col-md-offset-2">
								<?php if ($subtitle) { ?>
									<div class="empty-lg-0 empty-md-0 empty-sm-40 empty-xs-40"></div> 
								<?php } else { ?>
									<div class="empty-lg-50 empty-md-60 empty-sm-60 empty-xs-60"></div>
								<?php } ?>
								<div class="text-center caption type-2">
									<?php if ($subtitle) { ?>
										<span class="sub-title col-1 tt"><?php print esc_html($subtitle) ?></span>
										<div class="empty-sm-10 empty-xs-10"></div>
									<?php }
									if ($title){ ?>	
										<h1 class="h1 title title_spec"><?php print wp_kses_post($title) ?></h1>
									<?php } 
									if(isset($short_desc)) { ?>
										<div class="empty-sm-10 empty-xs-10"></div>
										<div class="simple-text lg col-3">
											<p><?php print wp_kses_post($short_desc); ?></p>
										</div>
									<?php }
									if (isset($button_url) && $button_title){ ?>	
										<div class="empty-sm-30 empty-xs-30"></div>
										<?php hm_get_template_part('composer/shortcodes/buttons/button-'.$btn_type, [ 'title' => $button_title, 'but_url' => $button_url, 'but_align' =>  $btn_align_n, 'but_width' => $b_width, 'main_color' => $m_color ]); ?>
									<?php } ?>
								</div> 
							</div>
						<?php } elseif ($banner_type == 'type_2') { ?>
							<div class="col-md-10 col-md-offset-1">
								<div class="main-caption type-2 text-center">
									<div class="empty-sm-80 empty-xs-60"></div>
									<?php if ($subtitle){ ?>
										<span class="sub-title lg"><?php print esc_html($subtitle) ?></span>
										<div class="empty-sm-10 empty-xs-10"></div>
									<?php }
									if ($title){ ?>	
										<h1 class="h1 title"><?php print esc_html($title) ?></h1>
									<?php } ?>
									
									<?php print $icon_html; ?>
									<?php if(isset($short_desc)) { ?>
										<div class="empty-sm-15 empty-xs-15"></div>
										<div class="simple-text col-3 lg">
											<p><?php print wp_kses_post($short_desc); ?></p>
										</div>
									<?php } ?>
									<?php if ($button_title && isset($button_link)) { ?>
										<div class="empty-sm-35 empty-xs-30"></div>
										<div class="button-wrap">
											<?php hm_get_template_part('composer/shortcodes/buttons/button-'.$btn_type, [ 'title' => $button_title, 'but_url' => $button_url, 'but_align' =>  $btn_align_n, 'but_width' => $b_width, 'main_color' => $m_color]); ?>
										</div>
									<?php } ?>
								</div>
							</div>
						<?php } ?>
					</div>
				</div>
			</div>
		</div> 

		<?php 
		return  ob_get_clean();
	}

}