<?php 
/*
** Image Box
** Author: NRGTHEMES
** Author URI: http://nrgthemes.com
** Version: 1.0.0 
*/

vc_map( array(
	'name'                    => __( 'Image Box', 'nrg_premium' ),
	'base'                    => 'nrg_premium_image_box',
	'category' 				  => __( 'NRGPremium', 'nrg_premium' ),
	'content_element'         => true,
	'show_settings_on_create' => true,
	'params'          => array(
		array(
			'type'        => 'dropdown',
			'heading'     => __( 'Type', 'nrg_premium' ),
			'param_name'  => 'type',
			'value'       => array(
				'Type 1'   => 'type_1',
				'Type 2'   => 'type_2',
			),
		),
		array(
			'type'        => 'attach_image',
			'heading'     => __( "Image", "nrg_premium" ),
			'param_name'  => 'image',
			'description' => 'Upload your image.'
		),
		array(
			'type'        => 'textfield',
			'heading'     =>  __( "Title", "nrg_premium" ),
			'param_name'  => 'title',
			'admin_label' => true,
			'value'       => '',
		),
		array(
			'type'        => 'textfield',
			'heading'     =>  __( "Subtitle", "nrg_premium" ),
			'param_name'  => 'subtitle',
			'admin_label' => true,
			'value'       => '',
		),
		array(
			'type'        => 'vc_link',
			'heading'     => 'Link',
			'param_name'  => 'link',
			'admin_label' => true,
			'value'       => '',
			'dependency'  => array( 'element' => 'type', 'value' => 'type_2'),
		),
		array(
			'type' 		  => 'textarea',
			'heading'	  => __( 'Short Description', 'nrg_premium' ),
			'param_name'  => 'short_desc',
			'dependency'  => array( 'element' => 'type', 'value' => 'type_1'),
		),
		array(
			'type' 		  => 'checkbox',
			'heading'	  => __( 'Darker background', 'nrg_premium' ),
			'param_name'  => 'bg',
			'dependency'  => array( 'element' => 'type', 'value' => 'type_1'),
		),
		array(
			'type' => 'textfield',
			'heading' => __( 'Extra class name', 'nrg_premium' ),
			'param_name' => 'el_class',
			'description' => __( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'nrg_premium' ),
			'value' => '',
		),
		array(
			'type' => 'css_editor',
			'heading' => __( 'CSS box', 'nrg_premium' ),
			'param_name' => 'css',
			'group' => __( 'Design options', 'nrg_premium' ),
		),
	) //end params
) );

class WPBakeryShortCode_nrg_premium_image_box extends WPBakeryShortCode {
	protected function content( $atts, $content = null) {

		extract( shortcode_atts( array(
			'el_class'     => '',
			'css'          => '',
			'title'        => '',
			'subtitle'     => '',
			'short_desc'   => '',
			'image'        => '',
			'bg'		   => '',
			'type'			=> 'type_1',
			'link'			=> ''
 		), $atts ) );

		$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, $this->settings['base'], $atts );
		
		// custum css
		$css_class .= vc_shortcode_custom_css_class( $css, ' ' );

		// custum class
		$css_class .= (!empty($el_class)) ? ' '.$el_class : '';

		$image_html = '';
			if ($image) {
			$image_full = wp_get_attachment_image_url( $image, 'full' );
			$image_html = '<div class="image"><img src="'. esc_url( $image_full ). '" alt="image"></div>';
			}
 		// output
		ob_start();
		do_shortcode( $content );
		?>
		<!--ICON BOX-->
		<div class="<?php print esc_attr( $css_class ); ?>">
			<?php if ($type == 'type_1') { ?>
				<div class="image-item-box <?php if ($bg == true) {print 'bg-2';} else {print 'bg-1';} ?> ">
					<?php print $image_html ?>
					<div class="text">
						<div class="empty-md-80 empty-sm-60 empty-xs-40"></div>  
						<?php if ($title || $subtitle) { ?>
							<div class="caption type-2 text-center">
								<?php if ($title) { ?>
									<h5 class="h5 title"><?php print esc_html($title) ?></h5>
								<?php }
								if ($subtitle) { ?>
									<div class="empty-sm-5 empty-xs-5"></div>
									<span class="sub-title tt col-4 sm"><?php print esc_html($subtitle) ?></span>
								<?php } ?>
								<div class="empty-sm-15 empty-xs-15"></div>
								<div class="title-separator-1"><span></span></div>
								<?php if ($short_desc) { ?>
									<div class="empty-sm-20 empty-xs-20"></div>
									<div class="simple-text col-2">
										<p><?php print wp_kses_post($short_desc); ?></p>
									</div>
								<?php }?>
								<div class="empty-md-80 empty-sm-60 empty-xs-40"></div> 
							</div>
						<?php }?>
					</div>
				</div>
			<?php } elseif ($type == 'type_2') { ?>
				<a href="<?php echo esc_html($link ? vc_build_link($link)['url'] : '#'); ?>" class="service-item-3 flex-align">
					<?php if ($image) { ?>
						<div class="bg layer-hold" style="background-image: url(<?php echo esc_url(wp_get_attachment_image_url( $image, 'full' ));?>)"></div>
					<?php } ?>
					<div class="caption type-2">
						<?php if ($title) { ?>
							<h6 class="h6 title"><?php echo esc_html($title); ?></h6>
						<?php }
						if ($subtitle) { ?>
							<div class="empty-sm-10 empty-xs-10"></div>
							<div class="sub-title tt ls sm col-10"><?php echo esc_html($subtitle);?></div>
						<?php } ?>
					</div>
				</a>
			<?php } ?>

		</div>
		<?php 
		return  ob_get_clean();
	}
}