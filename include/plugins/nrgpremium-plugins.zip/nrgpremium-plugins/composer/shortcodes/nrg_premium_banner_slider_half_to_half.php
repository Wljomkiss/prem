<?php 
/*
** Banner Slider half to half
** Version: 1.0.0 
*/


vc_map( array(
	'name'                    => __( 'Banner slider half to half', 'nrg_premium' ),
	'base'                    => 'nrg_premium_banner_slider_half_to_half',
	'as_parent'               => array('only' => 'nrg_premium_banner_slider_half_to_half_item'),
	'content_element'         => true,
	'show_settings_on_create' => true,
	'category' 				  => __( 'NRGPremium', 'nrg_premium' ),
	'description'             => __( 'Banner slider half to half', 'nrg_premium'),
	'js_view'                 => 'VcColumnView',
	'params'          => array(
		array(
			'type' => 'textfield',
			'heading' => __( 'Extra class name', 'nrg_premium' ),
			'param_name' => 'el_class',
			'description' => __( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'nrg_premium' ),
			'value' => '',
		),
		array(
			'type' => 'css_editor',
			'heading' => __( 'CSS box', 'nrg_premium' ),
			'param_name' => 'css',
			'group' => __( 'Design options', 'nrg_premium' ),
		),
	) //end params
) );

class WPBakeryShortCode_nrg_premium_banner_slider_half_to_half extends WPBakeryShortCodesContainer {

	protected function content( $atts, $content = null) {

		extract( shortcode_atts( array(
			'el_class'     => '',
			'css'          => '',
		), $atts ) );


		global $_banner_slider_half_to_half_items;
		$_banner_slider_half_to_half_items = array();

		$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, $this->settings['base'], $atts );

		// custum css
		$css_class .= vc_shortcode_custom_css_class( $css, ' ' );

		// custum class
		$css_class .= (!empty($el_class)) ? ' '.$el_class : '';
		
		// output
		ob_start();
		do_shortcode( $content );
		?>

		<section class="section <?php print esc_attr( $css_class ); ?>">
			<div class="empty-lg-130 empty-md-100 empty-sm-60 empty-xs-60"></div>
			<div class="arrow-closest mobile-pagination">
				<div class="swiper-container full-h" data-mode="horizontal" data-autoplay="0" data-effect="slide" data-slides-per-view="1" data-loop="0" data-speed="800">
					<div class="swiper-wrapper">
						<?php foreach ($_banner_slider_half_to_half_items as $key => $shortcode) {
							$shortcode_atts = $shortcode['atts'];
							?>
							<div class="swiper-slide">
								<div class="container">
									<div class="row vertical-wrap">
										<div class="col-lg-7 col-md-12 col-sm-12">
											<?php if ($shortcode_atts['image'] && $shortcode_atts['title']) { ?>
												<div class="clip-text" style="background-image: url(<?php echo esc_url(wp_get_attachment_image_url( $shortcode_atts['image'], 'full' )); ?>)">
													<span class="h1"><?php print esc_html($shortcode_atts['title']); ?></span>
												</div>
												<div class="empty-lg-0 empty-md-0 empty-sm-40 empty-xs-40"></div>
											<?php } ?>
										</div>
										<div class="col-lg-5 col-md-12 col-sm-12">
											<div class="caption text-center">
												<?php if ($shortcode_atts['title_i']) { ?>
													<h2 class="h4 title lg tt"><?php echo esc_html($shortcode_atts['title_i']);?></h2>
												<?php }
												if ($shortcode_atts['subtitle_i']) { ?>
													<div class="empty-sm-15 empty-xs-15"></div>
													<div class="simple-text md col-1">
														<p><?php echo esc_html($shortcode_atts['subtitle_i']);?></p>
													</div>
												<?php } ?>
												<?php if (is_numeric($shortcode_atts['number'])) { ?>
													<div class="empty-md-50 empty-sm-40 empty-xs-40"></div>
													<div class="skill-block-wrap">
													<div class="skill-block">
														<?php if ($shortcode_atts['number']) { ?>
															<div class="skill-circle" data-border="false" data-dimension="130" data-bgcolor="#f6f6f6" data-width="2" data-percent="<?php echo esc_html($shortcode_atts['number']); ?>" data-fgcolor="#819859" data-animationstep="1">
																<div class="skill-number vertical-align full txt-normal">
																	<span class="timer" data-to="<?php echo esc_html($shortcode_atts['number']); ?>" data-speed="1000">0</span>%
																</div>
															</div>
														<?php }
														if ($shortcode_atts['title_count']) { ?>
															<div class="empty-sm-15 empty-xs-15"></div>
															<h4 class="h6"><?php echo esc_html($shortcode_atts['title_count']); ?></h4>
														<?php }
														if ($shortcode_atts['subtitle_count']) { ?>
															<div class="empty-sm-5 empty-xs-5"></div>
															<span class="sub-desc"><?php echo esc_html($shortcode_atts['subtitle_count']); ?></span>
														<?php }
														if ($shortcode_atts['short_desc']) { ?>
															<div class="empty-sm-20 empty-xs-20"></div>
															<div class="simple-text col-1">
																<p><?php echo wp_kses_post($shortcode_atts['short_desc']); ?></p>
															</div>
														<?php } ?>
													</div>
													</div>
												<?php } ?>
											</div>
										</div>
									</div>
								</div>
							</div>
						<?php } ?>
					</div>
					<div class="pagination pagination-hide"></div>
				</div>
				<div class="swiper-arrow-left slider-arrow-1 type-3"><i class="fa fa-angle-left"></i></div>
				<div class="swiper-arrow-right slider-arrow-1 type-3"><i class="fa fa-angle-right"></i></div> 
			</div>
			<div class="empty-lg-130 empty-md-100 empty-sm-60 empty-xs-60"></div>
		</section>

		<?php 
		return  ob_get_clean();
	}

}
/* Shortvode Item */

vc_map( array(
  'name'            => 'Banner slider half to half item',
  'base'            => 'nrg_premium_banner_slider_half_to_half_item',
  'as_child' 		=> array('only' => 'nrg_premium_banner_slider_half_to_half'),
  'content_element' => true,
  'show_settings_on_create' => true,
  'description'     => 'Image, title and text',
  'params'          => array(
		array(
			'type'			=> 'attach_image',
			'heading'		=> __( 'Image', 'nrg_premium' ),
			'param_name'	=> 'image',
			'admin_label'	=> true,
			'description'	=> 'Upload your image.',
			'group'			=> 'Main part',
		),
		array(
			'type'			=> 'textfield',
			'heading'		=> __( 'Title', 'nrg_premium' ),
			'param_name'	=> 'title',
			'admin_label'	=> true,
			'value'			=> '',
			'group'			=> 'Main part',
		),
		array(
			'type'			=> 'textfield',
			'heading'		=> __( 'Title info part', 'nrg_premium' ),
			'param_name'	=> 'title_i',
			'admin_label'	=> true,
			'value'			=> '',
			'group'			=> 'Info part',
		),
		array(
			'type'			=> 'textfield',
			'heading'		=> __( 'Subtitle info part', 'nrg_premium' ),
			'param_name'	=> 'subtitle_i',
			'admin_label'	=> true,
			'value'			=> '',
			'group'			=> 'Info part',
		),
		array(
			'type'			=> 'textfield',
			'heading'		=> __( 'Counter number', 'nrg_premium' ),
			'param_name'	=> 'number',
			'admin_label'	=> true,
			'value'			=> '',
			'description'	=> 'Only for integer numbers from 1 to 100',
			'group'			=> 'Info part',
		),
		array(
			'type'			=> 'textfield',
			'heading'		=> __( 'Title Counter', 'nrg_premium' ),
			'param_name'	=> 'title_count',
			'admin_label'	=> true,
			'value'			=> '',
			'group'			=> 'Info part',
		),
		array(
			'type'			=> 'textfield',
			'heading'		=> __( 'Subtitle Counter', 'nrg_premium' ),
			'param_name'	=> 'subtitle_count',
			'admin_label'	=> true,
			'value'			=> '',
			'group'			=> 'Info part',
		),
		array(
			'type'			=> 'textarea',
			'heading'		=> __( 'Short Description', 'nrg_premium' ),
			'param_name'	=> 'short_desc',
			'group'			=> 'Info part',
		),
	) //end params
) );


class WPBakeryShortCode_nrg_premium_banner_slider_half_to_half_item extends WPBakeryShortCode{
	protected function content( $atts, $content = null ) {

		global $_banner_slider_half_to_half_items;
		$_banner_slider_half_to_half_items[] = array( 'atts' => $atts, 'content' => $content, 'css_class' => '');
		return;
	}
}