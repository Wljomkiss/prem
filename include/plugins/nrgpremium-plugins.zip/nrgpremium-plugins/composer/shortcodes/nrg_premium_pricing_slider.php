<?php 
/*
** Pricing slider
** Version: 1.0.0 
*/


vc_map( array(
	'name'						=> __( 'Pricing slider', 'nrg_premium' ),
	'base'						=> 'nrg_premium_pricing_slider',
	'as_parent'					=> array('only' => 'nrg_premium_pricing_slider_item'),
	'content_element'			=> true,
	'show_settings_on_create'	=> false,
	'category'					=> __( 'NRGPremium', 'nrg_premium' ),
	'description'				=> __( 'Pricing slider', 'nrg_premium'),
	'js_view'					=> 'VcColumnView',
	'params'					=> array(
		array(
			'type'			=> 'textfield',
			'heading'		=> __( 'Extra class name', 'nrg_premium' ),
			'param_name'	=> 'el_class',
			'description'	=> __( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'nrg_premium' ),
			'value'			=> '',
		),
		array(
			'type'			=> 'css_editor',
			'heading'		=> __( 'CSS box', 'nrg_premium' ),
			'param_name'	=> 'css',
			'group'			=> __( 'Design options', 'nrg_premium' ),
		),
	) //end params
) );

class WPBakeryShortCode_nrg_premium_pricing_slider extends WPBakeryShortCodesContainer {

	protected function content( $atts, $content = null) {

		extract( shortcode_atts( array(
			'el_class'		=> '',
			'css'			=> '',
		
		), $atts ) );

		global $_pricing_sliders_items;
		$_pricing_sliders_items = array();

		$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, $this->settings['base'], $atts );

		// custum css
		$css_class .= vc_shortcode_custom_css_class( $css, ' ' );

		// custum class
		$css_class .= (!empty($el_class)) ? ' '.$el_class : '';
		
		// output
		ob_start();
		do_shortcode( $content );
		?>
		<div class="<?php print esc_attr( $css_class ); ?> ">
			<div class="swiper-container gutter-15 pagination-bottom" data-mode="horizontal" data-autoplay="0" data-effect="slide" data-slides-per-view="responsive" data-loop="0" data-speed="800" data-add-slides="4" data-lg-slides="4" data-md-slides="2" data-sm-slides="2" data-xs-slides="1">
				<div class="swiper-wrapper">
					<?php foreach ($_pricing_sliders_items as $key => $shortcode) {
						$shortcode_atts = $shortcode['atts'];
						if (isset($shortcode_atts['list'])) {
							$values = vc_param_group_parse_atts( $shortcode_atts['list']); 
						} ?>
						<div class="swiper-slide">
							<div class="price-item sm <?php echo (isset($shortcode_atts['best']) && $shortcode_atts['best']== true ? 'special' : ''); ?>">
								<?php if (isset($shortcode_atts['best']) && $shortcode_atts['best']== true) { ?>	
									<div class="best-stiker">
										<span><?php echo esc_html__('best', 'nrg_premium'); ?></span>
									</div>
								<?php }
								if (isset($shortcode_atts['title']) || isset($shortcode_atts['subtitle'])) { ?>
									<div class="price-header">
										<div class="empty-sm-50 empty-xs-40"></div>
										<?php if (isset($shortcode_atts['subtitle'])) { ?> 
											<div class="sub-desc"><?php echo esc_html($shortcode_atts['subtitle']); ?></div>
											<div class="empty-sm-10 empty-xs-10"></div>  
										<?php } 
										if (isset($shortcode_atts['title'])) { ?>
											<h4 class="h4 title"><?php echo esc_html($shortcode_atts['title']); ?></h4>
										<?php } ?>
										<div class="empty-sm-50 empty-xs-40"></div>    
									</div>
								<?php } ?>
								<div class="price-list">
									<div class="price-number">
										<span>$</span>
										<b><?php echo esc_html($shortcode_atts['price']); ?></b>
										<p>/<?php echo esc_html($shortcode_atts['period']); ?></p>
									</div>
									<?php if (isset($values)) { ?>
										<div class="empty-sm-40 empty-xs-40"></div>
										<ul>
										<?php foreach ($values as $value) { ?>
											<li><?php echo esc_html($value['list_item']); ?></li>
										<?php } ?>
										</ul>
									<?php } 
									if (isset($shortcode_atts['link'])) { ?>
										<div class="empty-sm-15 empty-xs-15"></div>
										<a href="<?php echo esc_url($shortcode_atts['link']['url']); ?>" class="main-link wh-sm link-style-5" data-text="learn more"><span><?php echo esc_html__('order now', 'nrg_premium'); ?></span></a>
									<?php } ?>
								</div>
							</div>
						</div>
					<?php } ?>
				</div>
				<div class="pagination colo-type-2 type-2 dark"></div>
				<div class="empty-lg-60 empty-md-60 empty-sm-60 empty-xs-60"></div>  
			</div>
		</div>

		<?php 
		return  ob_get_clean();
	}

}
/* Shorctcode Item */

vc_map( array(
  'name'            => 'Pricing slider item',
  'base'            => 'nrg_premium_pricing_slider_item',
  'as_child' 		=> array('only' => 'nrg_premium_pricing_slider'),
  'content_element' => true,
  'show_settings_on_create' => true,
  'description'     => 'Image, title and text',
  'params'          => array(
  		array(
			'type'			=> 'checkbox',
			'heading'		=> __( "Best", "nrg_premium" ),
			'param_name'	=> 'best',
			'description'	=> 'Choose this price as the best?',
			'value'			=> false,
		),
		array(
			'type'			=> 'textfield',
			'heading'		=> 'Title',
			'param_name'	=> 'title',
			'admin_label'	=> true,
			'value'			=> '',
		),
		array(
			'type'			=> 'textfield',
			'heading'		=> 'Subtitle',
			'param_name'	=> 'subtitle',
			'admin_label'	=> true,
			'value'			=> '',
		),
  		array(
			'type'			=> 'textfield',
			'heading'		=> 'Price',
			'param_name'	=> 'price',
			'value'			=> '',
			'description'	=> 'Only for numbers',
		),
		array(
			'type'			=> 'textfield',
			'heading'		=> 'Period',
			'param_name'	=> 'period',
			'value'			=> '',
		),
  		array(
			'type'			=> 'param_group',
			'js_view'		=> 'VcColumnView',
			'heading'		=> __( 'List', 'nrg_premium' ),
			'param_name'	=> 'list',
			'params'		=> array(
				array(
					'type'			=> 'textfield',
					'heading'		=> __( "List item", "nrg_premium" ),
					'param_name'	=> 'list_item',
					'value'			=> '',
				),
			),
		),
  		array(
			'type'			=> 'vc_link',
			'heading'		=> 'Link',
			'param_name'	=> 'url',
			'value'			=> '',
		),
	) //end params
) );


class WPBakeryShortCode_nrg_premium_pricing_slider_item extends WPBakeryShortCode{
	protected function content( $atts, $content = null ) {

		global $_pricing_sliders_items;
		$_pricing_sliders_items[] = array( 'atts' => $atts, 'content' => $content, 'css_class' => '');
		return;
	}
}