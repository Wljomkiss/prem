<?php 
/*
** Dish Slider
** Version: 1.0.0 
*/


vc_map( array(
	'name'                    => __( 'Dish slider', 'nrg_premium' ),
	'base'                    => 'nrg_premium_dish_slider',
	'as_parent'               => array('only' => 'nrg_premium_dish_slider_item'),
	'content_element'         => true,
	'show_settings_on_create' => false,
	'category' 				  => __( 'NRGPremium', 'nrg_premium' ),
	'description'             => __( 'Dish slider', 'nrg_premium'),
	'js_view'                 => 'VcColumnView',
	'params'          => array(
		array(
			'type' => 'textfield',
			'heading' => __( 'Extra class name', 'nrg_premium' ),
			'param_name' => 'el_class',
			'description' => __( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'nrg_premium' ),
			'value' => '',
		),
		array(
			'type' => 'css_editor',
			'heading' => __( 'CSS box', 'nrg_premium' ),
			'param_name' => 'css',
			'group' => __( 'Design options', 'nrg_premium' ),
		),
	) //end params
) );

class WPBakeryShortCode_nrg_premium_dish_slider extends WPBakeryShortCodesContainer {

	protected function content( $atts, $content = null) {

		extract( shortcode_atts( array(
			'el_class'     => '',
			'css'          => '',
			'image'        => '',
		), $atts ) );

		global $_dish_sliders_items;
		$_dish_sliders_items = array();

		$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, $this->settings['base'], $atts );

		// custum css
		$css_class .= vc_shortcode_custom_css_class( $css, ' ' );

		// custum class
		$css_class .= (!empty($el_class)) ? ' '.$el_class : '';
		
		// output
		ob_start();
		do_shortcode( $content );
		?>
		<div class="<?php print esc_attr( $css_class ); ?>">
			<div class="swiper-container" data-mode="horizontal" data-autoplay="0" data-effect="slide" data-slides-per-view="1" data-loop="0" data-speed="800">
				<div class="swiper-wrapper">
				<?php foreach ($_dish_sliders_items as $key => $shortcode):
					$shortcode_atts = $shortcode['atts'];
					$image_html = '';
					if (isset($shortcode_atts['image'])) {
						$image_full = wp_get_attachment_image_url( $shortcode_atts['image'], 'full' );
						$image_html = '<div class="image"><img src="'.esc_url( $image_full ).'" alt=""></div>';
					} ?>
						<div class="swiper-slide">
							<div class="dish-slider">
								<div class="row vertical-wrap">
									<div class="col-md-7">
										<?php print $image_html; ?>
									</div>
									<div class="col-md-5">
										<div class="caption type-2">
											<?php if ($shortcode_atts['subtitle']) { ?>
												<span class="sub-title"><?php print esc_html($shortcode_atts['subtitle']); ?></span>
												<div class="empty-sm-5 empty-xs-5"></div>
											<?php } 
											if ($shortcode_atts['title']) { ?>
												<h2 class="h4 lg title no-tr"><?php print esc_html($shortcode_atts['title']); ?></h2>
											<?php } 
											if ($shortcode_atts['short_desc']) { ?>
												<div class="empty-sm-25 empty-xs-25"></div>
												<div class="simple-text col-2">
													<p><?php print wp_kses_post($shortcode_atts['short_desc']); ?></p>
												</div>
											<?php } 
											if(isset($shortcode_atts['button_title']) && isset($shortcode_atts['button_url'])) { 
												$button_link = vc_build_link($shortcode_atts['button_url']); ?>
												<div class="empty-sm-30 empty-xs-30"></div>
												<div class="button-wrap"> 
													<a href="<?php print esc_html($button_link['url']); ?>" class="main-link link-style-1 type-5"><span><?php print esc_html($shortcode_atts['button_title']); ?></span></a>
												</div>
											<?php } ?>
										</div>  
									</div>
								</div>
							</div>   
						</div>
					<?php endforeach; ?>
				</div>
				<div class="pagination color-revers type-col-2 vertical-left"></div>
			</div> 
		</div>  
		<?php 
		return  ob_get_clean();
	}

}
/* Shortvode Item */

vc_map( array(
  'name'            => 'Dish slider item',
  'base'            => 'nrg_premium_dish_slider_item',
  'as_child' 		=> array('only' => 'nrg_premium_dish_slider'),
  'content_element' => true,
  'show_settings_on_create' => true,
  'description'     => 'Image, title and text',
  'params'          => array(
		array(
			'type'        => 'attach_image',
			'heading'     => __( 'Image', 'nrg_premium' ),
			'param_name'  => 'image',
			'admin_label' => true,
			'description' => 'Upload your image.'
		),
		array(
			'type'        => 'textfield',
			'heading'     => __( 'Title', 'nrg_premium' ),
			'param_name'  => 'title',
			'admin_label' => true,
			'value'       => '',
		),
		array(
			'type'        => 'textfield',
			'heading'     => __( 'Subtitle', 'nrg_premium' ),
			'param_name'  => 'subtitle',
			'admin_label' => true,
			'value'       => '',
		),
		array(
			'type'        => 'textarea',
			'heading'     => __( 'Short Description', 'nrg_premium' ),
			'param_name'  => 'short_desc',
		),
		array(
			'type'        => 'textfield',
			'heading'     => __( "Button title", "nrg_premium" ),
			'param_name'  => 'button_title',
			'admin_label' => true,
			'value'       => '',
		),
		array(
			'type'        => 'vc_link',
			'heading'     => __( "Button url", "nrg_premium" ),
			'param_name'  => 'button_url',
			'admin_label' => true,
			'value'       => '#',
		),
	) //end params
) );


class WPBakeryShortCode_nrg_premium_dish_slider_item extends WPBakeryShortCode{
	protected function content( $atts, $content = null ) {

		global $_dish_sliders_items;
		$_dish_sliders_items[] = array( 'atts' => $atts, 'content' => $content, 'css_class' => '');
		return;
	}
}