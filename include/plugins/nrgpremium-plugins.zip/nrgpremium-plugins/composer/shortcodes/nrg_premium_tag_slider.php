<?php 
/*
** Tag slider
** Author: NRGTHEMES
** Author URI: http://nrgthemes.com
** Version: 1.0.0 
*/


vc_map( array(
	'name'                    => __( 'Tag slider', 'nrg_premium' ),
	'base'                    => 'nrg_premium_tag_slider',
	'category' 				  => __( 'NRGPremium', 'nrg_premium' ),
	'content_element'         => true,
	'show_settings_on_create' => true,
	'description' 		      => __( 'Tag slider', 'nrg_premium' ),
	'params'          => array(
		array(
			'type'        => 'dropdown',
			'heading'     => __( 'Choose Tag', 'nrg_premium' ),
			'param_name'  => 'tag',
			'value'       =>  nrg_premium_param_values( 'terms', array(
				'taxonomies' => 'product_tag',
			) ),
		),
		array(
			'type'        => 'textfield',
			'heading'     => __( 'Count items', 'nrg_premium' ),
			'param_name'  => 'limit',
			'value'       => '',
			'description' => __( 'Default 3 items.', 'nrg_premium' )
		),
		array(
			'type' => 'textfield',
			'heading' => __( 'Extra class name', 'nrg_premium' ),
			'param_name' => 'el_class',
			'description' => __( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'nrg_premium' ),
			'value' => '',
		),
		array(
			'type' => 'css_editor',
			'heading' => __( 'CSS box', 'nrg_premium' ),
			'param_name' => 'css',
			'group' => __( 'Design options', 'nrg_premium' ),
		),
	) //end params
) );

class WPBakeryShortCode_nrg_premium_tag_slider extends WPBakeryShortCode {
	protected function content( $atts, $content = null) {
		extract( shortcode_atts( array(
			'el_class'      => '',
			'css'           => '',
			'tag'			=> '',
			'limit'			=> '',
 		), $atts ) );

		//limit
		$limit 	  = ( empty( $limit ) || ! is_numeric( $limit ) ) ?  : $limit;

		$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, $this->settings['base'], $atts );

		// custum css
		$css_class .= vc_shortcode_custom_css_class( $css, ' ' );

		// custum class
		$css_class .= (!empty($el_class)) ? ' '.$el_class : '';

		$args = array(
			'post_type'      => 'product',
			'posts_per_page' => $limit,
			'order'			 => 'DESC',
			'tax_query'      => array(
				array(
					'taxonomy' => 'product_tag',
					'field'    => 'term_id',
					'terms'    => $tag,
				),
			)
		);

		$query = new WP_Query( $args );


 		// output
		ob_start();
		do_shortcode( $content );
		?>
		<!--Popular products-->
		<div class="<?php print esc_attr( $css_class ); ?>"> 
			<div class="promo-item-2">
				<div class="category"><?php echo esc_html(get_the_category_by_ID( $tag )); ?></div>
				<div class="swiper-container full-width full-h" data-mode="horizontal" data-autoplay="0" data-effect="slide" data-slides-per-view="1" data-loop="0" data-speed="800">
					<div class="swiper-wrapper">
							
						<?php if ( $query->have_posts() ) { ?>
							<?php while ( $query->have_posts() ) : $query->the_post(); 
							global $product;
							?>
								<div class="swiper-slide">
									<div class="flex-align">
										<div class="caption">
											<span class="sub-title col-2"><?php echo $product->get_price_html();?></span>
											<div class="empty-sm-10 empty-xs-10"></div> 
											<h2 class="h2 title"><?php echo get_the_title(); ?></h2>
											<div class="empty-sm-15 empty-xs-15"></div>
											<div class="simple-text md col-1">
												<p><i><?php echo get_the_excerpt(); ?></i></p>
											</div>
											<div class="empty-sm-30 empty-xs-30"></div>
											<a href="<?php echo get_the_permalink();?>" class="main-link link-style-7 type-4"><span><?php echo esc_html__('shop now', 'nrg_premium'); ?></span></a>
										</div>
										<div class="image">
											<img src="<?php echo get_the_post_thumbnail_url()?>" alt="<?php get_the_title(); ?>">
										</div>
									</div>
								</div>

							<?php endwhile;
							wp_reset_postdata();
						} ?>


					</div>
					<div class="pagination color-black"></div>
				</div>
			</div>
		</div>
		<?php return  ob_get_clean();
	}
}
