<?php 
/*
** Service
** Author: NRGTHEMES
** Author URI: http://nrgthemes.com
** Version: 1.0.0 
*/

vc_map( array(
	'name'                    => __( 'Service', 'nrg_premium' ),
	'base'                    => 'nrg_premium_service',
	'category' 				  => __( 'NRGPremium', 'nrg_premium' ),
	'content_element'         => true,
	'show_settings_on_create' => true,
	'description' 		      => __( 'Universal shortcode with 2 images', 'nrg_premium' ),
	'params'          => array(
		
		array(
			'type'        => 'attach_image',
			'heading'     => __( "Title image", "nrg_premium" ),
			'param_name'  => 'title_image',
			'admin_label' => true,
			'description' => 'Upload your image.',
		),
		array(
			'type'        => 'textfield',
			'heading'     => __( 'Title', "nrg_premium" ),
			'param_name'  => 'title',
			'admin_label' => true,
			'value'       => '',
		),
		array(
			'type'        => 'textfield',
			'heading'     => __( 'Subtitle', "nrg_premium" ),
			'param_name'  => 'subtitle',
			'admin_label' => true,
			'value'       => '',
		),
		array(
			'type'        => 'attach_image',
			'heading'     => __( "Right image", "nrg_premium" ),
			'param_name'  => 'right_image',
			'admin_label' => true,
			'description' => 'Upload your image.',
		),

		array(
			'type'        => 'textfield',
			'heading'     => __( "Title fo description", "nrg_premium" ),
			'param_name'  => 'title_desc',
			'admin_label' => true,
			'value'       => '',
			'group'		  => __( "Description", "nrg_premium" ),
		),
		array(
			'type'			=> 'textarea',
			'heading'		=> __( 'Description', 'nrg_premium' ),
			'param_name'	=> 'short_desc',
			'group'		  => __( "Description", "nrg_premium" ),
		),
		array(
			'type'        => 'dropdown',
			'heading'     => __( 'Button type', 'nrg_premium' ),
			'param_name'  => 'btn_type',
			'value'       => array(
				'Type 1'   => 'type_1',
				'Type 2'   => 'type_2',
				'Type 3'   => 'type_3',
				'Type 4'   => 'type_4',
				'Type 5'   => 'type_5',
				'Type 6'   => 'type_6',
			),
			'group'		 => 'Button',
		),
		array(
			'type'        => 'vc_link',
			'heading'     => __( 'Button link', "nrg_premium" ),
			'param_name'  => 'button_url',
			'admin_label' => true,
			'value'       => '#',
			'group'		  => __( "Description", "nrg_premium" ),
			'group'		  => 'Button',
		),
		array(
			'type'        => 'textfield',
			'heading'     => __( "Button title", "nrg_premium" ),
			'param_name'  => 'button_title',
			'admin_label' => true,
			'value'       => '',
			'group'		  => __( "Description", "nrg_premium" ),
			'group'		  => 'Button',
		),
		array(
			'type'			=> 'colorpicker',
			'class'			=> '',
			'heading'		=> __( 'Main color', 'nrg_premium' ),
			'param_name'	=> 'm_color',
			'value'			=> '#84694e',
			'group'			=> 'Button',
		),
		array(
			'type' => 'textfield',
			'heading' => __( 'Extra class name', 'nrg_premium' ),
			'param_name' => 'el_class',
			'description' => __( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'nrg_premium' ),
			'value' => '',
		),
		array(
			'type' => 'css_editor',
			'heading' => __( 'CSS box', 'nrg_premium' ),
			'param_name' => 'css',
			'group' => __( 'Design options', 'nrg_premium' ),
		),
	) //end params
) );

class WPBakeryShortCode_nrg_premium_service extends WPBakeryShortCode {
	protected function content( $atts, $content = null) {

		extract( shortcode_atts( array(
			'el_class'			=> '',
			'css'				=> '',
			'title_image'		=> '',
			'title'				=> '',
			'subtitle'			=> '',
			'right_image'		=> '',
			'short_desc'		=> '',
			'title_desc'		=> '',
			'button_url'		=> '',
			'button_title'		=> '',
			'btn_type'			=> 'type_1',
			'm_color'			=> '',

 		), $atts ) );

		$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, $this->settings['base'], $atts );
		
		// custum css
		$css_class .= vc_shortcode_custom_css_class( $css, ' ' );

		// custum class
		$css_class .= (!empty($el_class)) ? ' '.$el_class : '';


		// IMAGES
		// proposal image 1
		$title_image_html = '';
		if (!empty($title_image)) {
			$title_image_full = wp_get_attachment_image_url( $title_image, 'full' );
			$title_image_html = '<div class="bg type-6 layer-hold" style="background-image: url('.esc_url( $title_image_full ).')"></div>';
		}
		// proposal image 2
		$right_image_html = '';
		if (!empty($right_image)) {
			$right_image_full = wp_get_attachment_image_url( $right_image, 'full' );
			$right_image_html = '<div class="bg" style="background-image: url('.esc_url( $right_image_full ).')"></div>';
		}

		// LINKS
		$button_link = vc_build_link($button_url); 

		// output
		ob_start();
		do_shortcode( $content );
		?>
		<!--CONTACT INFO-->
		<div class="<?php echo esc_attr( $css_class ); ?>">
			<div class="row">
				<div class="col-md-5 col-sm-12 col-xs-12">
					<div class="item-h-600 custome-padd-100 flex-align">
						<?php echo $title_image_html ?>
						<?php if ($title || $subtitle) { ?>
							<div class="caption text-center type-2">
								<?php if ($subtitle) { ?>
									<span class="sub-title"><?php echo $subtitle ?></span>
									<div class="empty-sm-5 empty-xs-5"></div>
								<?php } 
								if ($title) { ?>
									<h2 class="h2 title"><?php echo $title ?></h2>
								<?php } ?>
							</div>  
						<?php } ?>
					</div>
				</div>
				<div class="col-md-5 col-sm-12 col-xs-12">
					<div class="item-h-600 custome-padd-100 flex-align bg-section-6">
						<?php if ($title_desc || $short_desc) { ?>
							<div class="caption type-2">
								<?php if ($title_desc) { ?>
									<h2 class="h4 lg title no-tr"><?php echo esc_html($title_desc); ?></h2>
									<div class="empty-sm-20 empty-xs-20"></div>
								<?php } 
								if ($short_desc) { ?>
									<div class="simple-text col-2">
										<p><?php echo wp_kses_post($short_desc);?></p>
									</div>
									<div class="empty-sm-30 empty-xs-30"></div>
								<?php } 
								if (isset($button_url) && $button_title) { ?>
									<?php hm_get_template_part('composer/shortcodes/buttons/button-'.$btn_type, [ 'title' => $button_title, 'but_url' => $button_url, 'but_align' =>  '', 'main_color' => $m_color, 'but_width' => 'standart' ]); ?>
								<?php } ?>
							</div> 
						<?php } ?>
					</div>
				</div>
				<div class="col-md-2 col-sm-12 col-xs-12">
					<div class="item-h-600 custome-padd-100 flex-align hide-mobile">
						<?php echo $right_image_html ?>
					</div>
				</div>
			</div>
		</div>
		<?php 
		return  ob_get_clean();
	}
}